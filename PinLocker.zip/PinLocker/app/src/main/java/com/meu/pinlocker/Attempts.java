package com.meu.pinlocker;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Bloqueio por tentativas erradas, em até 3 níveis: cada nível tem seu número de erros e seu tempo de bloqueio.
 * Depois do 3º bloqueio o 3º nível se repete até acertar (acertar zera tudo).
 */
final class Attempts {
    static final int[] COUNTS = {2, 3, 4, 5, 6, 8, 10};
    static final int[] SECS = {10, 30, 60, 120, 300, 600, 1800, 3600};
    static final int[] AUTO_OFF = {0, 10, 15, 20, 30, 60};
    private static final int[] DEF_N = {5, 3, 3};
    private static final int[] DEF_T = {30, 60, 300};

    private Attempts() { }

    private static SharedPreferences p(Context c) { return Store.sp(c); }

    static boolean on(Context c) { return p(c).getBoolean("atOn", true); }

    static void setOn(Context c, boolean v) { p(c).edit().putBoolean("atOn", v).apply(); if (!v) ok(c); }

    /** Erros seguidos que causam o bloqueio de número lvl (0, 1, 2). */
    static int n(Context c, int lvl) { return p(c).getInt("atN" + (lvl + 1), DEF_N[lvl]); }

    /** Segundos de bloqueio do nível lvl (0, 1, 2). */
    static int t(Context c, int lvl) { return p(c).getInt("atT" + (lvl + 1), DEF_T[lvl]); }

    static void setN(Context c, int lvl, int v) { p(c).edit().putInt("atN" + (lvl + 1), v).apply(); }

    static void setT(Context c, int lvl, int v) { p(c).edit().putInt("atT" + (lvl + 1), v).apply(); }

    static void defaults(Context c) {
        SharedPreferences.Editor e = p(c).edit();
        for (int i = 0; i < 3; i++) e.remove("atN" + (i + 1)).remove("atT" + (i + 1));
        e.apply();
    }

    static long remainingMs(Context c) {
        if (!on(c)) return 0;
        return Math.max(0, p(c).getLong("atUntil", 0) - System.currentTimeMillis());
    }

    /** Registra um erro. Devolve true se isso acabou de bloquear. */
    static boolean fail(Context c) {
        if (!on(c)) return false;
        SharedPreferences sp = p(c);
        int lvl = sp.getInt("atLvl", 0), f = sp.getInt("atFail", 0) + 1, idx = Math.min(lvl, 2);
        if (f >= n(c, idx)) {
            sp.edit().putInt("atFail", 0).putInt("atLvl", lvl + 1).putLong("atUntil", System.currentTimeMillis() + t(c, idx) * 1000L).apply();
            return true;
        }
        sp.edit().putInt("atFail", f).apply();
        return false;
    }

    /** Acertou: zera os erros e os níveis. */
    static void ok(Context c) { p(c).edit().putInt("atFail", 0).putInt("atLvl", 0).putLong("atUntil", 0).apply(); }

    /** "30 s", "5 min", "1 h". */
    static String secs(int s) { return s < 60 ? s + " s" : s < 3600 ? (s / 60) + " min" : (s / 3600) + " h"; }

    /** Tempo restante: "28 s", "4 min 05 s". */
    static String left(long ms) {
        long s = (ms + 999) / 1000;
        if (s < 60) return s + " s";
        if (s < 3600) return (s / 60) + " min " + String.format("%02d", s % 60) + " s";
        return (s / 3600) + " h " + String.format("%02d", (s % 3600) / 60) + " min";
    }

    static String summary(Context c) {
        if (!on(c)) return L.t("at_off");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 3; i++) b.append(i > 0 ? "  \u00B7  " : "").append(n(c, i)).append("\u2192").append(secs(t(c, i)));
        return b.toString();
    }
}
