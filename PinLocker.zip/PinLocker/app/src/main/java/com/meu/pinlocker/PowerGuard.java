package com.meu.pinlocker;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/** Serviço vazio: serve só para a tela de bloqueio poder ficar numa camada ACIMA do menu de desligar (Android 8+). */
public class PowerGuard extends AccessibilityService {
    static volatile PowerGuard inst;

    @Override protected void onServiceConnected() { inst = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }
    @Override public boolean onUnbind(android.content.Intent i) { inst = null; return super.onUnbind(i); }
}
