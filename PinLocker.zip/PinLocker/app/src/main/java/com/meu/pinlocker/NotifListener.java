package com.meu.pinlocker;

import android.app.NotificationManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Lê as notificações ativas só para mostrar os ícones delas na status bar Holo da tela de bloqueio.
 * Precisa da permissão "Acesso às notificações" (botão 5 na tela principal). Nada é guardado nem enviado.
 */
public class NotifListener extends NotificationListenerService {
    private static volatile List<Drawable> icons = Collections.emptyList();
    private static final CopyOnWriteArrayList<Runnable> listeners = new CopyOnWriteArrayList<>();

    static List<Drawable> icons() { return icons; }
    static void addListener(Runnable r) { listeners.addIfAbsent(r); }
    static void removeListener(Runnable r) { listeners.remove(r); }

    @Override public void onListenerConnected() { rebuild(); }

    @Override public void onListenerDisconnected() { publish(Collections.<Drawable>emptyList()); }

    @Override public void onNotificationPosted(StatusBarNotification sbn) { rebuild(); }

    @Override public void onNotificationRemoved(StatusBarNotification sbn) { rebuild(); }

    @Override public void onNotificationRankingUpdate(RankingMap rankingMap) { rebuild(); }

    private void rebuild() {
        ArrayList<Drawable> out = new ArrayList<>();
        try {
            StatusBarNotification[] all = getActiveNotifications();
            RankingMap rm = getCurrentRanking();
            Ranking rk = new Ranking();
            HashSet<String> seen = new HashSet<>();
            if (all != null) for (StatusBarNotification s : all) {
                if (s.getPackageName().equals(getPackageName())) continue;
                // como a barra de verdade: notificações silenciosas (importância mínima) não ganham ícone
                if (rm != null && rm.getRanking(s.getKey(), rk) && rk.getImportance() < NotificationManager.IMPORTANCE_LOW) continue;
                if (!seen.add(s.getPackageName())) continue; // um ícone por app
                Icon ic = s.getNotification().getSmallIcon();
                if (ic == null) continue;
                Drawable d = ic.loadDrawable(this);
                if (d == null) continue;
                d = d.mutate();
                d.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN); // ícones de status são monocromáticos
                out.add(d);
            }
        } catch (Throwable ignored) { }
        publish(out);
    }

    private static void publish(List<Drawable> l) {
        icons = l;
        for (Runnable r : listeners) r.run();
    }
}
