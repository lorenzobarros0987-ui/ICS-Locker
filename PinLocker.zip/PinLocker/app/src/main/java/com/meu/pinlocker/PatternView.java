package com.meu.pinlocker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Padrão de desbloqueio do Android 4.0.4 (LockPatternView Holo do keyguard): usa os bitmaps originais do sistema,
 * linha branca a 50%, anel verde enquanto desenha e anel vermelho quando erra. Sem fundo próprio (o papel de parede,
 * inclusive o animado, aparece por trás).
 */
final class PatternView extends View {
    interface Listener { void onDone(String seq); }

    private static final float HIT = 0.6f, DIAM = 0.10f; // mesmos fatores do AOSP
    private final Paint bmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Bitmap dot, touched, circle, green, red;
    private final ArrayList<Integer> cells = new ArrayList<>();
    private final boolean[] used = new boolean[9];
    private boolean inProgress, wrong, blocked;
    private float cx, cy;
    private Listener listener;
    private final Runnable clear = this::reset;

    PatternView(Context c) {
        super(c);
        android.content.res.Resources r = c.getResources();
        dot = BitmapFactory.decodeResource(r, R.drawable.ics_btn_code_lock_default_holo);
        touched = BitmapFactory.decodeResource(r, R.drawable.ics_btn_code_lock_touched_holo);
        circle = BitmapFactory.decodeResource(r, R.drawable.ics_indicator_code_lock_point_area_default_holo);
        green = BitmapFactory.decodeResource(r, R.drawable.ics_indicator_code_lock_point_area_green_holo);
        red = BitmapFactory.decodeResource(r, R.drawable.ics_indicator_code_lock_point_area_red_holo);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(0xFFFFFFFF);
        line.setAlpha(128);
        setClickable(true);
    }

    void setListener(Listener l) { listener = l; }

    void setBlocked(boolean b) { blocked = b; if (b) reset(); }

    boolean isBlocked() { return blocked; }

    void reset() {
        removeCallbacks(clear);
        cells.clear();
        Arrays.fill(used, false);
        inProgress = false;
        wrong = false;
        invalidate();
    }

    /** Anéis vermelhos; limpa sozinho depois de 2 s (como no keyguard). */
    void showWrong() {
        wrong = true;
        invalidate();
        removeCallbacks(clear);
        postDelayed(clear, 2000);
    }

    void clearAfter(long ms) { removeCallbacks(clear); postDelayed(clear, ms); }

    private String seq() {
        StringBuilder s = new StringBuilder();
        for (int k : cells) s.append(k);
        return s.toString();
    }

    @Override protected void onDetachedFromWindow() { removeCallbacks(clear); super.onDetachedFromWindow(); }

    @Override protected void onDraw(Canvas canvas) {
        float sw = getWidth() / 3f, sh = getHeight() / 3f;
        if (!cells.isEmpty()) {
            line.setStrokeWidth(sw * DIAM * 0.5f);
            Path p = new Path();
            for (int i = 0; i < cells.size(); i++) {
                int k = cells.get(i);
                float x = (k % 3 + 0.5f) * sw, y = (k / 3 + 0.5f) * sh;
                if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
            }
            if (inProgress) p.lineTo(cx, cy);
            canvas.drawPath(p, line);
        }
        for (int k = 0; k < 9; k++) drawDot(canvas, (k % 3 + 0.5f) * sw, (k / 3 + 0.5f) * sh, sw, sh, used[k]);
    }

    private void drawDot(Canvas c, float x, float y, float sw, float sh, boolean part) {
        Bitmap outer = circle, inner = dot;
        if (part) {
            if (wrong) outer = red;
            else if (inProgress) { outer = green; inner = touched; }
            else outer = green;
        }
        int w = Math.max(outer.getWidth(), inner.getWidth()), h = Math.max(outer.getHeight(), inner.getHeight());
        float s = Math.min(Math.min(sw / w, sh / h), 1.2f);
        c.save();
        c.translate(x, y);
        c.scale(s, s);
        c.drawBitmap(outer, -outer.getWidth() / 2f, -outer.getHeight() / 2f, bmp);
        c.drawBitmap(inner, -inner.getWidth() / 2f, -inner.getHeight() / 2f, bmp);
        c.restore();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (blocked) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                reset();
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                inProgress = true;
                hit(e.getX(), e.getY());
                cx = e.getX(); cy = e.getY();
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!inProgress) return true;
                for (int i = 0; i < e.getHistorySize(); i++) hit(e.getHistoricalX(i), e.getHistoricalY(i));
                hit(e.getX(), e.getY());
                cx = e.getX(); cy = e.getY();
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                if (!inProgress) return true;
                inProgress = false;
                invalidate();
                if (!cells.isEmpty() && listener != null) listener.onDone(seq());
                return true;
            case MotionEvent.ACTION_CANCEL:
                reset();
                return true;
        }
        return false;
    }

    private void hit(float x, float y) {
        float sw = getWidth() / 3f, sh = getHeight() / 3f;
        int c = (int) (x / sw), r = (int) (y / sh);
        if (x < 0 || y < 0 || c > 2 || r > 2) return;
        float off = (1 - HIT) / 2, fx = x - c * sw, fy = y - r * sh;
        if (fx < sw * off || fx > sw * (1 - off) || fy < sh * off || fy > sh * (1 - off)) return;
        int k = r * 3 + c;
        if (used[k]) return;
        if (!cells.isEmpty()) { // ponto do meio de um salto (ex.: 1 -> 3 passa pelo 2)
            int last = cells.get(cells.size() - 1), lr = last / 3, lc = last % 3, dr = r - lr, dc = c - lc, fr = lr, fc = lc;
            if (Math.abs(dr) == 2 && Math.abs(dc) != 1) fr = lr + (dr > 0 ? 1 : -1);
            if (Math.abs(dc) == 2 && Math.abs(dr) != 1) fc = lc + (dc > 0 ? 1 : -1);
            int fk = fr * 3 + fc;
            if (!used[fk]) add(fk);
        }
        add(k);
    }

    private void add(int k) {
        used[k] = true;
        cells.add(k);
        if (Look.b(getContext(), "pinHaptic", true))
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING | HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
    }
}
