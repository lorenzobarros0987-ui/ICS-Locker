package com.meu.pinlocker;

import android.content.Context;
import java.util.Locale;

/** Textos em português e inglês. Idioma: automático (pelo sistema), PT-BR ou EN. */
final class L {
    static final String[] LANG_N = {"Automático / Automatic", "Português (Brasil)", "English"};
    private static boolean en = false;

    private static final String[][] T = {
        {"pin_enter", "Digite o PIN", "Enter PIN"},
        {"pin_wrong", "PIN incorreto", "Wrong PIN"},
        {"cancel", "Cancelar", "Cancel"},
        {"delete", "Apagar", "Delete"},
        {"ok", "OK", "OK"},
        {"kb_hint", "Digite o PIN", "Type your PIN"},
        {"hint", "PIN Locker\n\nAntes de ativar: em Configurações > Tela de bloqueio, deixe \"Nenhum\" ou \"Deslizar\" (o bloqueio do sistema não pode ficar com PIN junto). Se der problema, reinicie em modo de segurança e desinstale o app.",
                 "PIN Locker\n\nBefore enabling: in Settings > Lock screen, choose \"None\" or \"Swipe\" (the system lock cannot use a PIN at the same time). If anything goes wrong, reboot in safe mode and uninstall the app."},
        {"set_pin", "Definir / trocar PIN", "Set / change PIN"},
        {"remove_pin", "Remover PIN (tela sem PIN)", "Remove PIN (lock screen without PIN)"},
        {"remove_pin_q", "Remover o PIN? A tela vai desbloquear só deslizando.", "Remove the PIN? The screen will unlock by just sliding."},
        {"yes", "Sim", "Yes"},
        {"no", "Não", "No"},
        {"pin_removed", "PIN removido", "PIN removed"},
        {"sc_left", "Atalho da esquerda", "Left shortcut"},
        {"sc_right", "Atalho da direita", "Right shortcut"},
        {"sc_left_s", "Atalho esquerda", "Left shortcut"},
        {"sc_right_s", "Atalho direita", "Right shortcut"},
        {"appearance", "Aparência (fundo, cores, relógio, teclado)", "Appearance (background, colors, clock, keypad)"},
        {"perm1", "1. Permitir sobrepor outros apps", "1. Allow display over other apps"},
        {"perm2", "2. Permitir acesso ao uso", "2. Allow usage access"},
        {"perm3", "3. Administrador do dispositivo", "3. Device administrator"},
        {"perm4", "4. Permitir ler o fundo de tela (para usar o fundo do celular)", "4. Allow reading the wallpaper (to use the phone wallpaper)"},
        {"admin_expl", "Dificulta desinstalar o PIN Locker sem o PIN.", "Makes it harder to uninstall PIN Locker without the PIN."},
        {"enable", "ATIVAR bloqueio", "ENABLE lock"},
        {"disable", "DESATIVAR bloqueio", "DISABLE lock"},
        {"enabled_toast", "Ativo. Apague a tela para testar.", "Enabled. Turn the screen off to test."},
        {"no_pin_warn", "Sem PIN: a tela desbloqueia só deslizando.", "No PIN: the screen unlocks by just sliding."},
        {"language", "Idioma", "Language"},
        {"shortcut_presets", "Atalhos prontos (como no Holo Locker)", "Preset shortcuts (like the original Holo Locker)"},
        {"shortcut_photo", "Foto do atalho", "Shortcut photo"},
        {"photo_left", "Foto do atalho da esquerda", "Left shortcut photo"},
        {"photo_right", "Foto do atalho da direita", "Right shortcut photo"},
        {"change_photo_short", "Escolher foto da galeria", "Choose a photo from gallery"},
        {"photo_remove", "Voltar ao ícone do app", "Back to the app icon"},
        {"none", "(nenhum)", "(none)"},
        {"choose_app", "Escolha o app", "Choose the app"},
        {"p_status", "PIN: ", "PIN: "},
        {"defined", "definido", "set"},
        {"notdefined", "NÃO definido (sem PIN)", "NOT set (no PIN)"},
        {"overlay", "Sobrepor apps: ", "Display over apps: "},
        {"usage", "Acesso ao uso: ", "Usage access: "},
        {"admin", "Administrador: ", "Administrator: "},
        {"active", "ativo", "active"},
        {"inactive", "inativo", "inactive"},
        {"okk", "ok", "ok"},
        {"missing", "falta", "missing"},
        {"clock_font", "Fonte do relógio: ", "Clock font: "},
        {"lock", "Bloqueio: ", "Lock: "},
        {"on", "ATIVADO", "ENABLED"},
        {"off", "desativado", "disabled"},
        {"pin_invalid", "PIN inválido ou diferente", "Invalid or mismatching PIN"},
        {"new_pin", "Novo PIN (4 a 8 números)", "New PIN (4 to 8 digits)"},
        {"repeat_pin", "Repita o PIN", "Repeat the PIN"},
        {"save", "Salvar", "Save"},
        {"set_pin_first_no", "PIN", "PIN"},
        {"wp_perm", "Sem permissão para ler o fundo de tela. Use \"4.\" na tela principal.", "No permission to read the wallpaper. Use \"4.\" on the main screen."},
        {"active_notif", "PIN Locker ativo", "PIN Locker active"},
        {"app_title_appearance", "Aparência", "Appearance"},
        {"preview", "VER PRÉVIA", "PREVIEW"},
        {"h_bg", "Fundo", "Background"},
        {"h_clock", "Relógio e data", "Clock and date"},
        {"h_pin", "Teclado de PIN", "PIN keypad"},
        {"h_lang", "Idioma", "Language"},
        {"h_shortcuts", "Atalhos", "Shortcuts"},
        {"bg", "Fundo", "Background"},
        {"change_photo", "Trocar foto", "Change photo"},
        {"dim", "Escurecer foto (%)", "Darken photo (%)"},
        {"accent", "Cor de destaque", "Accent color"},
        {"ringtint", "Pintar os anéis com a cor de destaque", "Tint the rings with the accent color"},
        {"cfont", "Fonte do relógio", "Clock font"},
        {"ccolor", "Cor do relógio", "Clock color"},
        {"csize", "Tamanho do relógio (sp)", "Clock size (sp)"},
        {"cpos", "Posição do relógio", "Clock position"},
        {"hmode", "Formato da hora", "Time format"},
        {"showdate", "Mostrar data", "Show date"},
        {"dfmt", "Formato da data", "Date format"},
        {"pinstyle", "Tela do PIN", "PIN screen"},
        {"pinletters", "Mostrar letras (ABC, DEF...)", "Show letters (ABC, DEF...)"},
        {"pinshuffle", "Embaralhar as teclas", "Shuffle keys"},
        {"pinhaptic", "Vibrar ao tocar", "Vibrate on touch"},
        {"pinshow", "Mostrar os números digitados", "Show typed digits"},
        {"reset", "Restaurar padrão", "Restore defaults"},
        {"photo_fail", "Não consegui usar essa foto", "Couldn't use that photo"},
    };

    static void init(Context c) {
        int v = Look.i(c, "lang", 0);
        if (v == 1) en = false;
        else if (v == 2) en = true;
        else en = !"pt".equalsIgnoreCase(Locale.getDefault().getLanguage());
    }

    static String t(String key) {
        for (String[] r : T) if (r[0].equals(key)) return en ? r[2] : r[1];
        return key;
    }

    static String[] list(String... pt_en) { // não usado: listas ficam em Look
        return pt_en;
    }

    static boolean isEn() { return en; }
}
