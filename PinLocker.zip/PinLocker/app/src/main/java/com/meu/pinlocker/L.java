package com.meu.pinlocker;

import android.content.Context;
import java.util.Locale;

/** Textos em português e inglês. Idioma: automático (pelo sistema), PT-BR ou EN. */
final class L {
    static final String[] LANG_N = {"Automático / Automatic", "Português (Brasil)", "English"};
    private static boolean en = false;

    private static final String[][] T = {
        {"pincircles", "Círculos nos números do PIN", "Circles on PIN keys"},
        {"block_power", "Bloquear menu de desligar (pede o PIN atual para ativar)", "Block the power menu (asks for the current PIN to enable)"},
        {"pin_current", "Digite o PIN atual", "Enter the current PIN"},
        {"pin_set_first", "Defina um PIN antes de ativar esta opção", "Set a PIN before enabling this option"},
        {"perm6", "6. Serviço de acessibilidade (tela de bloqueio acima do menu de desligar)", "6. Accessibility service (lock screen above the power menu)"},
        {"kb_title", "Digite seu PIN", "Enter your PIN"},
        {"kb_for_app", "Para abrir %s", "To open %s"},
        {"kb_unlock_phone", "Para desbloquear o celular", "To unlock your phone"},
        {"kb_tries", "Tentativas erradas: %d", "Wrong attempts: %d"},
        {"kb_help", "Use o teclado do celular. Ao completar %d dígitos o PIN é conferido sozinho; você também pode tocar em OK. Cancelar volta para a tela de bloqueio.",
                    "Use the phone keyboard. The PIN is checked automatically after %d digits; you can also tap OK. Cancel returns to the lock screen."},
        {"h_lock", "Bloqueio", "Lock"},
        {"m_pin", "PIN", "PIN"},
        {"m_shortcuts", "Atalhos (opcionais)", "Shortcuts (optional)"},
        {"m_perms", "Permissões (toque para ajustar)", "Permissions (tap to adjust)"},
        {"m_general", "Geral", "General"},
        {"m_howto", "Antes de ativar", "Before enabling"},
        {"photo_btn", "Foto", "Photo"},
        {"pin_enter", "Digite o PIN", "Enter PIN"},
        {"sc_need_unlock", "Exigir PIN para usar os atalhos", "Require PIN to use shortcuts"},
        {"calign", "Alinhamento do relógio", "Clock alignment"},
        {"holobar", "Mostrar status bar Holo (ícones, sinal, bateria e hora)", "Show Holo status bar (icons, signal, battery and clock)"},
        {"sc_ul", "Atalho diagonal esquerda (opcional)", "Upper-left shortcut (optional)"},
        {"sc_ur", "Atalho diagonal direita (opcional)", "Upper-right shortcut (optional)"},
        {"sc_ul_s", "Atalho diag. esquerda", "Upper-left shortcut"},
        {"sc_ur_s", "Atalho diag. direita", "Upper-right shortcut"},
        {"photo_ul", "Foto do atalho diagonal esquerda", "Upper-left shortcut photo"},
        {"photo_ur", "Foto do atalho diagonal direita", "Upper-right shortcut photo"},
        {"perm5", "5. Acesso às notificações (ícones na status bar Holo)", "5. Notification access (icons in the Holo status bar)"},
        {"notif", "Acesso às notificações: ", "Notification access: "},
        {"charged", "Carregado", "Charged"},
        {"charging", "Carregando", "Charging"},
        {"btm", "Texto inferior", "Bottom text"},
        {"edit_label", "Editar etiqueta personalizada", "Edit custom label"},
        {"wp_touch", "Papel de parede animado reage ao toque", "Live wallpaper reacts to touch"},
        {"wp_live_hint", "O papel de parede animado vale na próxima vez que a tela bloquear.", "The live wallpaper applies the next time the screen locks."},
        {"visual", "Visual do anel", "Ring visuals"},
        {"scshape", "Formato da foto do atalho", "Shortcut photo shape"},
        {"credits", "Sobre / Créditos", "About / Credits"},
        {"credits_text",
            "PIN Locker\n\nInterface inspirada no Holo Locker (Mobint), cujo visual de tela de bloqueio serviu de base para este projeto.\n\nO anel de desbloqueio (GlowPad), os chevrons, os pontos brilhantes e a fonte do relógio (AndroidClock) vêm do Android Open Source Project (AOSP), licenciado sob Apache License 2.0.\n\nEste app é um projeto independente e não é afiliado nem endossado pelos autores do Holo Locker.",
            "PIN Locker\n\nInterface inspired by Holo Locker (Mobint), whose lock screen look was the basis for this project.\n\nThe unlock ring (GlowPad), the chevrons, the glow dots and the clock font (AndroidClock) come from the Android Open Source Project (AOSP), licensed under the Apache License 2.0.\n\nThis is an independent project and is not affiliated with or endorsed by the authors of Holo Locker."},
        {"pin_wrong", "PIN incorreto", "Wrong PIN"},
        {"cancel", "Cancelar", "Cancel"},
        {"delete", "Apagar", "Delete"},
        {"ok", "OK", "OK"},
        {"kb_hint", "Digite o PIN", "Type your PIN"},
        {"hint", "Antes de ativar: em Configurações > Tela de bloqueio, deixe \"Nenhum\" ou \"Deslizar\" (o bloqueio do sistema não pode ficar com PIN junto). Se der problema, reinicie em modo de segurança e desinstale o app.",
                 "Before enabling: in Settings > Lock screen, choose \"None\" or \"Swipe\" (the system lock cannot use a PIN at the same time). If anything goes wrong, reboot in safe mode and uninstall the app."},
        {"set_pin", "Definir / trocar PIN", "Set / change PIN"},
        {"remove_pin", "Remover PIN (tela sem PIN)", "Remove PIN (lock screen without PIN)"},
        {"remove_pin_q", "Remover o PIN? A tela vai desbloquear só deslizando.", "Remove the PIN? The screen will unlock by just sliding."},
        {"yes", "Sim", "Yes"},
        {"no", "Não", "No"},
        {"pin_removed", "PIN removido", "PIN removed"},
        {"sc_left", "Atalho da esquerda", "Left shortcut"},
        {"sc_right", "Atalho de cima", "Top shortcut"},
        {"sc_left_s", "Atalho esquerda", "Left shortcut"},
        {"sc_right_s", "Atalho cima", "Top shortcut"},
        {"appearance", "Aparência (fundo, cores, relógio, teclado)", "Appearance (background, colors, clock, keypad)"},
        {"perm1", "1. Permitir sobrepor outros apps", "1. Allow display over other apps"},
        {"perm2", "2. Permitir acesso ao uso", "2. Allow usage access"},
        {"perm3", "3. Administrador do dispositivo", "3. Device administrator"},
        {"perm4", "4. Permitir ler o fundo de tela (para usar o fundo do celular)", "4. Allow reading the wallpaper (to use the phone wallpaper)"},
        {"admin_expl", "Dificulta desinstalar o PIN Locker sem o PIN.", "Makes it harder to uninstall PIN Locker without the PIN."},
        {"enable", "ATIVAR bloqueio", "ENABLE lock"},
        {"disable", "DESATIVAR bloqueio", "DISABLE lock"},
        {"enabled_toast", "Ativo. Apague a tela para testar.", "Enabled. Turn the screen off to test."},
        {"no_pin_warn", "Sem PIN: a tela desbloqueia só deslizando.", "No PIN: the screen unlocks by just sliding."},
        {"language", "Idioma", "Language"},
        {"shortcut_presets", "Atalhos prontos (como no Holo Locker)", "Preset shortcuts (like the original Holo Locker)"},
        {"shortcut_photo", "Foto do atalho", "Shortcut photo"},
        {"photo_left", "Foto do atalho da esquerda", "Left shortcut photo"},
        {"photo_right", "Foto do atalho de cima", "Top shortcut photo"},
        {"change_photo_short", "Escolher foto da galeria", "Choose a photo from gallery"},
        {"photo_remove", "Voltar ao ícone do app", "Back to the app icon"},
        {"none", "(nenhum)", "(none)"},
        {"choose_app", "Escolha o app", "Choose the app"},
        {"p_status", "PIN: ", "PIN: "},
        {"defined", "definido", "set"},
        {"notdefined", "NÃO definido (sem PIN)", "NOT set (no PIN)"},
        {"overlay", "Sobrepor apps: ", "Display over apps: "},
        {"usage", "Acesso ao uso: ", "Usage access: "},
        {"admin", "Administrador: ", "Administrator: "},
        {"active", "ativo", "active"},
        {"inactive", "inativo", "inactive"},
        {"okk", "ok", "ok"},
        {"missing", "falta", "missing"},
        {"clock_font", "Fonte do relógio: ", "Clock font: "},
        {"lock", "Bloqueio: ", "Lock: "},
        {"on", "ATIVADO", "ENABLED"},
        {"off", "desativado", "disabled"},
        {"pin_invalid", "PIN inválido ou diferente", "Invalid or mismatching PIN"},
        {"new_pin", "Novo PIN (4 a 8 números)", "New PIN (4 to 8 digits)"},
        {"repeat_pin", "Repita o PIN", "Repeat the PIN"},
        {"save", "Salvar", "Save"},
        {"set_pin_first_no", "PIN", "PIN"},
        {"wp_perm", "Sem permissão para ler o fundo de tela. Use \"4.\" na tela principal.", "No permission to read the wallpaper. Use \"4.\" on the main screen."},
        {"active_notif", "PIN Locker ativo", "PIN Locker active"},
        {"app_title_appearance", "Aparência", "Appearance"},
        {"preview", "VER PRÉVIA", "PREVIEW"},
        {"h_bg", "Fundo", "Background"},
        {"h_clock", "Relógio e data", "Clock and date"},
        {"h_pin", "Teclado de PIN", "PIN keypad"},
        {"h_lang", "Idioma", "Language"},
        {"h_shortcuts", "Atalhos", "Shortcuts"},
        {"bg", "Fundo", "Background"},
        {"change_photo", "Trocar foto", "Change photo"},
        {"dim", "Escurecer foto (%)", "Darken photo (%)"},
        {"accent", "Cor de destaque", "Accent color"},
        {"ringtint", "Pintar os anéis com a cor de destaque", "Tint the rings with the accent color"},
        {"cfont", "Fonte do relógio", "Clock font"},
        {"ccolor", "Cor do relógio", "Clock color"},
        {"csize", "Tamanho do relógio (sp)", "Clock size (sp)"},
        {"cpos", "Posição do relógio", "Clock position"},
        {"hmode", "Formato da hora", "Time format"},
        {"showdate", "Mostrar data", "Show date"},
        {"dfmt", "Formato da data", "Date format"},
        {"pinstyle", "Tela do PIN", "PIN screen"},
        {"pinletters", "Mostrar letras (ABC, DEF...)", "Show letters (ABC, DEF...)"},
        {"pinshuffle", "Embaralhar as teclas", "Shuffle keys"},
        {"pinhaptic", "Vibrar ao tocar", "Vibrate on touch"},
        {"pinshow", "Mostrar os números digitados", "Show typed digits"},
        {"reset", "Restaurar padrão", "Restore defaults"},
        {"photo_fail", "Não consegui usar essa foto", "Couldn't use that photo"},
    };

    static void init(Context c) {
        int v = Look.i(c, "lang", 0);
        if (v == 1) en = false;
        else if (v == 2) en = true;
        else en = !"pt".equalsIgnoreCase(Locale.getDefault().getLanguage());
    }

    static String t(String key) {
        for (String[] r : T) if (r[0].equals(key)) return en ? r[2] : r[1];
        return key;
    }

    static String[] list(String... pt_en) { // não usado: listas ficam em Look
        return pt_en;
    }

    static boolean isEn() { return en; }
}
