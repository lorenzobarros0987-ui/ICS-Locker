package com.meu.pinlocker;

import android.app.WallpaperManager;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.telephony.TelephonyManager;
import android.text.format.DateFormat;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** A tela de bloqueio inteira (relógio, anéis, teclado de PIN). Fica numa janela por cima de tudo (LockService) ou na prévia. */
public class LockScreen extends FrameLayout {
    interface Host { void unlock(); void launch(int slot); void keyboardPin(int slot); void unlockAndLaunch(int slot); void emergency(); }
    interface FocusListener { void onFocus(boolean focused); }
    private FocusListener focusListener;
    void setFocusListener(FocusListener l) { focusListener = l; }

    private static final String[] LETTERS = {"+", "", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ"};

    private final Host host;
    private final FrameLayout lockPane;
    private final ImageView photo;
    private final View dim;
    private final LinearLayout pinPane, pad, clock, hmRow;
    private final FrameLayout.LayoutParams clockLp;
    private final LockView lockView;
    private final HoloStatusBar sbar;
    private final TextView msg, dots, batt, carrier;
    private final FrameLayout.LayoutParams carrierLp;
    private final TextClock time, ampm, date;
    private final StringBuilder pin = new StringBuilder();
    private LinearLayout icsPane, icsPad, icsField;
    private View icsSpacer;
    private TextView icarrier;
    private PatternView pat;
    private boolean liveReady = true; // false = papel de parede animado ainda não está atrás (fica opaca)
    private TextView imsg, idots;
    private TextClock itime, idate;
    private static final int[] ICS_NUM = {R.drawable.ics_sym_keyboard_num0_no_plus, R.drawable.ics_sym_keyboard_num1, R.drawable.ics_sym_keyboard_num2,
            R.drawable.ics_sym_keyboard_num3, R.drawable.ics_sym_keyboard_num4, R.drawable.ics_sym_keyboard_num5, R.drawable.ics_sym_keyboard_num6,
            R.drawable.ics_sym_keyboard_num7, R.drawable.ics_sym_keyboard_num8, R.drawable.ics_sym_keyboard_num9};
    private int pendingSlot = -1; // atalho esperando o PIN (opção "exigir PIN para atalhos")

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    LockScreen(Context c, Host h) {
        super(c);
        host = h;
        photo = new ImageView(c);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        dim = new View(c);
        addView(photo, new FrameLayout.LayoutParams(-1, -1));
        addView(dim, new FrameLayout.LayoutParams(-1, -1));

        lockPane = new FrameLayout(c);
        lockView = new LockView(c, new LockView.Listener() {
            @Override public void onUnlock() {
                if (!Look.hasAuth(getContext()) || Look.lockMode(getContext()) == 1) host.unlock(); // modo 1 (só deslizar): sem PIN
                else if (!Look.patternOn(getContext()) && Look.pinUi(getContext()) == 2) host.keyboardPin(-1);
                else showPin();
            }
            @Override public void onShortcut(int slot) {
                if (Look.b(getContext(), "scNeedUnlock", false) && Look.hasAuth(getContext()) && Look.lockMode(getContext()) != 1) {
                    if (!Look.patternOn(getContext()) && Look.pinUi(getContext()) == 2) host.keyboardPin(slot); // página cheia também para atalhos
                    else { pendingSlot = slot; showPin(); }
                }
                else host.launch(slot);
            }
        });
        lockPane.addView(lockView, new FrameLayout.LayoutParams(-1, -1));

        clock = new LinearLayout(c);
        clock.setOrientation(LinearLayout.VERTICAL);
        clock.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout hm = new LinearLayout(c);
        hm.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hmRow = hm;
        time = new TextClock(c);
        time.setIncludeFontPadding(true);
        time.setPadding(0, dp(10), 0, dp(4));
        ampm = new TextClock(c);
        ampm.setFormat12Hour("a");
        ampm.setFormat24Hour("a");
        ampm.setTextSize(20);
        ampm.setTextColor(0xFFB0B0B0);
        ampm.setPadding(dp(6), 0, 0, dp(14));
        hm.addView(time);
        hm.addView(ampm);
        date = new TextClock(c);
        date.setTextSize(18);
        date.setTextColor(0xFFB0B0B0);
        date.setGravity(Gravity.CENTER_HORIZONTAL);
        batt = new TextView(c); // "Carregado" / "Carregando" (como o "Charged" do original)
        batt.setTextSize(18);
        batt.setTextColor(0xFFB0B0B0);
        batt.setGravity(Gravity.CENTER_HORIZONTAL);
        clock.addView(hm);
        clock.addView(date);
        clock.addView(batt);
        carrier = new TextView(c); // operadora ou etiqueta, embaixo
        carrier.setTextSize(14);
        carrier.setTextColor(0xFFB0B0B0);
        carrierLp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lockPane.addView(carrier, carrierLp);
        clockLp = new FrameLayout.LayoutParams(-1, -2);
        lockPane.addView(clock, clockLp);

        msg = new TextView(c);
        dots = new TextView(c);
        pad = new LinearLayout(c);
        pinPane = buildPin(c);
        pinPane.setVisibility(View.GONE);

        addView(lockPane, new FrameLayout.LayoutParams(-1, -1));
        addView(pinPane, new FrameLayout.LayoutParams(-1, -1));
        icsPane = buildIcsPin(c);
        icsPane.setVisibility(View.GONE);
        addView(icsPane, new FrameLayout.LayoutParams(-1, -1));
        sbar = new HoloStatusBar(c); // status bar própria (a do sistema fica escondida)
        addView(sbar, new FrameLayout.LayoutParams(-1, sbar.barHeight(), Gravity.TOP));
        // se a barra de baixo aparecer por qualquer motivo, esconde de novo na hora
        setOnSystemUiVisibilityChangeListener(v -> { if ((v & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0 || (v & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) hideBars(); });
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_APP_SWITCH) return true;
        return super.dispatchKeyEvent(e);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideBars();
        if (focusListener != null) focusListener.onFocus(f);
    }

    /** Chamado ao mostrar a tela: aplica o visual escolhido e volta para o relógio. */
    void refresh() {
        applyLook();
        lockView.setIcons(icon(0), icon(1), icon(2), icon(3));
        sbar.setVisibility(Look.b(getContext(), "holoBar", true) ? View.VISIBLE : View.GONE);
        lockView.setStyle(Look.idxd(getContext(), "visual", 2, 0));
        lockView.setRingPct(Look.i(getContext(), "ringPct", 110));
        lockView.setSkin(Look.ics(getContext()), isAsset(0), isAsset(1), isAsset(2), isAsset(3));
        startPage();
        hideBars();
    }

    /** Página inicial: deslizar (normal) ou, no modo 2, o teclado do PIN logo ao ligar a tela. */
    void startPage() {
        if (Look.lockMode(getContext()) == 2 && Look.hasAuth(getContext())) showPin(); else showLock();
    }

    void hideBars() {
        // esconde SEMPRE a barra de status e a de navegação do sistema (a status bar Holo própria é desenhada por nós)
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        setSystemUiVisibility(f);
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                WindowInsetsController wc = getWindowInsetsController();
                if (wc != null) {
                    wc.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    wc.hide(WindowInsets.Type.systemBars());
                }
            } catch (Throwable ignored) { }
        }
    }

    private void applyLook() {
        Context c = getContext();
        int bgIdx = Look.idxd(c, "bg", Look.BG.length, Look.BG_WALL);
        Drawable wp = null;
        Bitmap bmp = null;
        boolean live = Look.isLive(c); // papel de parede ao vivo: o sistema desenha atrás desta janela (transparente)
        boolean wpMode = !live && (bgIdx == Look.BG_WALL || bgIdx == Look.BG_LOCKWP);
        if (bgIdx == Look.BG_WALL && !live) wp = wallpaper(c);
        if (bgIdx == Look.BG_LOCKWP) wp = lockWallpaper(c);
        if (bgIdx == Look.BG_PHOTO) bmp = Look.photo(c);
        int[] cols = Look.BG[wpMode && wp == null ? 0 : bgIdx];
        setBackground(live && liveReady ? null : new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, cols));
        if (wp != null) photo.setImageDrawable(wp); else photo.setImageBitmap(bmp);
        boolean hasPic = wp != null || bmp != null || live;
        photo.setVisibility((wp != null || bmp != null) ? View.VISIBLE : View.GONE);
        liveTouch = live && Look.b(c, "wpTouch", true);
        int dimPct = Look.i(c, "dim", 40);
        dim.setBackgroundColor(Color.argb(hasPic ? dimPct * 255 / 100 : 0, 0, 0, 0));

        int acc = Look.accent(c);
        msg.setTextColor(acc);
        lockView.setTint(Look.b(c, "ringTint", false) ? acc : 0);

        time.setTypeface(Fonts.time(c));
        date.setTypeface(Fonts.date(c));
        ampm.setTypeface(Fonts.date(c));
        final boolean ics = true; // medidas do Holo Locker (iguais ao keyguard do 4.0), valem para as duas aparências
        int cs = Look.i(c, "csize", -1);
        if (cs < 0) cs = ics ? 80 : 84; // 4.0: relógio de 80sp
        final int tcol = new int[]{Color.WHITE, acc, 0xFFCCCCCC, 0xFFFFEB3B}[Look.idxd(c, "ccol", 4, 0)];
        time.setTextSize(cs);
        time.setTextColor(tcol);
        date.setTextSize(ics ? 14 : 18); // 4.0: linha de status de 14sp
        batt.setTextSize(ics ? 14 : 18);

        int hm = Look.idxd(c, "hmode", 3, 0);
        boolean is24 = hm == 1 || (hm == 0 && DateFormat.is24HourFormat(c));
        String tf = is24 ? "HH:mm" : "h:mm";
        time.setFormat12Hour(tf);
        time.setFormat24Hour(tf);
        ampm.setVisibility(is24 ? View.GONE : View.VISIBLE);

        String df = Look.dfmt(c);
        date.setFormat12Hour(df);
        date.setFormat24Hour(df);
        date.setVisibility(Look.b(c, "showDate", true) ? View.VISIBLE : View.GONE);

        float hpx = ph();
        int pos = Look.idxd(c, "cpos", 3, 0); // padrão: no topo, como no original
        clockLp.topMargin = (int) (hpx * (pos == 0 ? 0.06f : pos == 1 ? 0.12f : 0.19f)) + dp(16);
        if (ics && Look.i(c, "cpos", -1) < 0) clockLp.topMargin = (Look.b(c, "holoBar", true) ? sbar.barHeight() : 0) + dp(22); // 4.0: 22dp abaixo da barra de status
        clock.setLayoutParams(clockLp);

        // alinhamento do relógio (padrão: direita, como no original)
        int al = Look.idxd(c, "calign", 3, 0);
        int g = al == 0 ? Gravity.RIGHT : al == 1 ? Gravity.CENTER_HORIZONTAL : Gravity.LEFT;
        clock.setGravity(g);
        hmRow.setGravity(Gravity.BOTTOM | g);
        date.setGravity(g);
        batt.setGravity(g);
        clock.setPadding(dp(28), 0, g == Gravity.RIGHT ? dp(ics ? 42 : 46) : dp(28), 0); // Holo Locker: ~47dp de margem à direita

        // status da bateria (só aparece carregando)
        String bs = "";
        android.content.Intent bi = c.registerReceiver(null, new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
        if (bi != null && bi.getIntExtra("plugged", 0) != 0) {
            int sc = bi.getIntExtra("scale", 100), pct = sc > 0 ? bi.getIntExtra("level", 0) * 100 / sc : 0;
            bs = pct >= 100 ? L.t("charged") : L.t("charging") + " (" + pct + "%)";
        }
        batt.setTypeface(Fonts.date(c));
        batt.setText(bs);
        batt.setVisibility(bs.isEmpty() ? View.GONE : View.VISIBLE);

        // texto de baixo: operadora, etiqueta ou nada
        int bm = Look.idxd(c, "btm", 3, 0);
        String bt = "";
        if (bm == 0) {
            try {
                TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
                if (tm != null) { bt = tm.getNetworkOperatorName(); if (bt == null || bt.isEmpty()) bt = tm.getSimOperatorName(); }
            } catch (Throwable ignored) { }
        } else if (bm == 1) bt = Look.s(c, "label", "");
        if (bt == null) bt = "";
        carrier.setTypeface(Fonts.date(c));
        carrier.setText(bt);
        carrier.setVisibility(bt.isEmpty() ? View.GONE : View.VISIBLE);
        icarrier.setText(bt);
        icarrier.setVisibility(bt.isEmpty() ? View.GONE : View.VISIBLE);
        carrierLp.bottomMargin = (int) (hpx * 0.06f) + dp(8);
        carrier.setLayoutParams(carrierLp);

        // página do PIN no estilo do 4.0: relógio, data e campo de senha
        itime.setTypeface(Fonts.time(c));
        itime.setTextSize(cs);
        itime.setTextColor(tcol);
        itime.setFormat12Hour(tf);
        itime.setFormat24Hour(tf);
        idate.setTypeface(Fonts.date(c));
        idate.setTextSize(14);
        idate.setFormat12Hour(df);
        idate.setFormat24Hour(df);
        idate.setVisibility(Look.b(c, "showDate", true) ? View.VISIBLE : View.GONE);
        icsPane.setPadding(0, (Look.b(c, "holoBar", true) ? sbar.barHeight() : 0) + dp(22), 0, 0);
    }

    /** O pano de fundo (WallBackdrop) ficou pronto/sumiu: a tela fica transparente (mostra o papel de parede animado) ou opaca. */
    void setLiveReady(boolean r) {
        liveReady = r;
        if (Look.isLive(getContext())) setBackground(r ? null : new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, Look.BG[Look.BG_LIVE]));
    }

    private boolean liveTouch;      // repassa toques ao papel de parede ao vivo
    private long lastWpTap;
    private static Drawable lockCache;
    private static int lockCacheId = -2;

    /** Papel de parede próprio da tela de bloqueio (Android 7+); sem ele, usa o da tela inicial. */
    private Drawable lockWallpaper(Context c) {
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                WallpaperManager wm = WallpaperManager.getInstance(c.getApplicationContext());
                int id = wm.getWallpaperId(WallpaperManager.FLAG_LOCK);
                if (id > 0 && lockCache != null && id == lockCacheId) return lockCache;
                if (id > 0) {
                    try (ParcelFileDescriptor pfd = wm.getWallpaperFile(WallpaperManager.FLAG_LOCK)) {
                        if (pfd != null) {
                            Bitmap b = BitmapFactory.decodeFileDescriptor(pfd.getFileDescriptor());
                            if (b != null) { lockCache = fit(c, new BitmapDrawable(c.getResources(), b)); lockCacheId = id; return lockCache; }
                        }
                    }
                }
            } catch (Throwable ignored) { }
        }
        return wallpaper(c);
    }

    /** Papel de parede ao vivo "interativo": cada toque/arrasto vira um comando de toque para o papel de parede. */
    @Override public boolean dispatchTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) LockService.poke(); // reinicia a contagem de "desligar a tela sozinha"
        if (liveTouch) {
            int a = e.getActionMasked();
            long now = SystemClock.uptimeMillis();
            if (a == MotionEvent.ACTION_DOWN || (a == MotionEvent.ACTION_MOVE && now - lastWpTap > 70)) {
                lastWpTap = now;
                try {
                    WallpaperManager.getInstance(getContext().getApplicationContext())
                            .sendWallpaperCommand(getWindowToken(), WallpaperManager.COMMAND_TAP, (int) e.getX(), (int) e.getY(), 0, null);
                } catch (Throwable ignored) { }
            }
        }
        return super.dispatchTouchEvent(e);
    }

    private static Drawable wallpaperCache;

    /** Fundo de tela do celular (precisa da permissão de leitura; sem ela cai para o fundo Holo). */
    /** Papel de parede da tela inicial: carregado uma vez e reduzido ao tamanho da tela (antes decodificava a cada bloqueio). */
    private Drawable wallpaper(Context c) {
        if (wallpaperCache == null) {
            try {
                Drawable d = WallpaperManager.getInstance(c.getApplicationContext()).getDrawable();
                if (d != null) wallpaperCache = fit(c, d);
            } catch (Throwable ignored) { }
        }
        return wallpaperCache;
    }

    /** Chamado quando o usuário troca o papel de parede do sistema. */
    static void dropWallpaperCache() { wallpaperCache = null; lockCache = null; lockCacheId = -2; }

    /** Reduz bitmaps muito maiores que a tela (menos memória e envio à GPU). */
    private static Drawable fit(Context c, Drawable d) {
        if (!(d instanceof BitmapDrawable)) return d;
        Bitmap b = ((BitmapDrawable) d).getBitmap();
        if (b == null || b.getWidth() <= 0 || b.getHeight() <= 0) return d;
        android.util.DisplayMetrics m = c.getResources().getDisplayMetrics();
        float k = Math.max((float) Math.min(m.widthPixels, m.heightPixels) / b.getWidth(), (float) Math.max(m.widthPixels, m.heightPixels) / b.getHeight());
        if (k >= 0.85f) return d;
        try {
            Bitmap s = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * k)), Math.max(1, Math.round(b.getHeight() * k)), true);
            return new BitmapDrawable(c.getResources(), s);
        } catch (Throwable t) { return d; }
    }

    private LinearLayout buildPin(Context c) {
        LinearLayout p = new LinearLayout(c);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setGravity(Gravity.CENTER);
        p.setBackgroundColor(0xB3000000);
        msg.setTextSize(18);
        msg.setGravity(Gravity.CENTER);
        dots.setTextColor(Color.WHITE);
        dots.setTextSize(28);
        dots.setGravity(Gravity.CENTER);
        TypedValue tv = new TypedValue();
        if (c.getTheme().resolveAttribute(android.R.attr.editTextBackground, tv, true) && tv.resourceId != 0)
            dots.setBackgroundResource(tv.resourceId); // sublinhado Holo do tema do sistema
        dots.setMinWidth(dp(240));
        p.addView(msg);
        p.addView(dots, new LinearLayout.LayoutParams(-2, -2));
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setPadding(0, dp(16), 0, 0);
        p.addView(pad);
        Button cancel = new Button(c, null, android.R.attr.borderlessButtonStyle);
        cancel.setText(L.t("cancel"));
        cancel.setTextColor(0xFFCCCCCC);
        cancel.setOnClickListener(v -> showLock());
        p.addView(cancel);
        return p;
    }

    private void setMsg(String s) { msg.setText(s); if (imsg != null) imsg.setText(s); }

    private TranslateAnimation shake() {
        TranslateAnimation a = new TranslateAnimation(0, dp(14), 0, 0);
        a.setDuration(300);
        a.setInterpolator(new CycleInterpolator(3));
        return a;
    }

    /** Página do PIN no estilo do Android 4.0 (keyguard_screen_password_portrait): relógio à direita, campo escuro com apagar, teclado numérico. */
    private LinearLayout buildIcsPin(Context c) {
        android.content.res.Resources rs = c.getResources();
        final float sw = pw();
        LinearLayout p = new LinearLayout(c);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setGravity(Gravity.CENTER_HORIZONTAL);

        int rm = (int) (sw * 0.075f);
        itime = new TextClock(c);
        itime.setIncludeFontPadding(true);
        itime.setPadding(0, 0, 0, dp(6));
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.gravity = Gravity.RIGHT;
        tl.rightMargin = rm;
        p.addView(itime, tl);
        idate = new TextClock(c);
        idate.setTextColor(0xFFFFFFFF);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-2, -2);
        dl.gravity = Gravity.RIGHT;
        dl.rightMargin = rm;
        p.addView(idate, dl);

        // tudo abaixo desce até o fim da tela: mensagem + campo/teclado (ou grade do padrão), operadora e chamada de emergência
        icsSpacer = new View(c);
        p.addView(icsSpacer, new LinearLayout.LayoutParams(-1, 0, 1f));

        imsg = new TextView(c);
        imsg.setTextSize(16);
        imsg.setTextColor(Color.WHITE);
        imsg.setGravity(Gravity.CENTER);
        imsg.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        p.addView(imsg, new LinearLayout.LayoutParams(-1, -2));

        // campo de senha: pontos no centro, apagar à direita e fio azul embaixo
        LinearLayout field = new LinearLayout(c);
        field.setGravity(Gravity.CENTER_VERTICAL);
        field.setBackgroundResource(R.drawable.ics_lockscreen_password_field_dark);
        idots = new TextView(c);
        idots.setTextSize(36);
        idots.setTextColor(Color.WHITE);
        idots.setGravity(Gravity.CENTER);
        idots.setSingleLine(true);
        idots.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(0, -2, 1f);
        il.leftMargin = (int) rs.getDimension(R.dimen.ics_pin_margin_left);
        field.addView(idots, il);
        ImageButton del = new ImageButton(c);
        del.setImageResource(R.drawable.ics_ic_input_delete);
        del.setBackgroundColor(Color.TRANSPARENT);
        del.setPadding(dp(8), dp(8), dp(8), dp(8));
        del.setOnClickListener(v -> press("DEL"));
        del.setOnLongClickListener(v -> { pin.setLength(0); dots(); return true; });
        field.addView(del, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(-1, -2);
        fl.setMargins((int) (sw * 0.078f), dp(6), (int) (sw * 0.078f), dp(10));
        p.addView(field, fl);
        icsField = field;

        // teclado numérico: de ponta a ponta, teclas escuras (a do toque fica azul)
        icsPad = new LinearLayout(c);
        icsPad.setOrientation(LinearLayout.VERTICAL);
        icsPad.setBackgroundColor(rs.getColor(R.color.ics_kbd_background));
        int ep = (int) (sw * 0.0125f);
        icsPad.setPadding(ep, ep, ep, ep);
        p.addView(icsPad, new LinearLayout.LayoutParams(-1, -2));

        // padrão (4.0.4): grade 3x3 grande, logo acima da operadora
        pat = new PatternView(c);
        pat.setVisibility(View.GONE);
        int ps = (int) (sw * 0.88f);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(ps, ps);
        pl.topMargin = dp(6);
        pl.bottomMargin = dp(2);
        p.addView(pat, pl);
        pat.setListener(seq -> patternDone(seq));

        icarrier = new TextView(c);
        icarrier.setTextSize(15);
        icarrier.setTextColor(Color.WHITE);
        icarrier.setGravity(Gravity.CENTER);
        icarrier.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        icarrier.setPadding(0, dp(10), 0, dp(8));
        p.addView(icarrier, new LinearLayout.LayoutParams(-1, -2));

        // barra "Emergency call"
        View div = new View(c);
        div.setBackgroundColor(0x33FFFFFF);
        p.addView(div, new LinearLayout.LayoutParams(-1, 1));
        LinearLayout em = new LinearLayout(c);
        em.setGravity(Gravity.CENTER);
        em.setBackgroundColor(0x80000000);
        ImageView ei = new ImageView(c);
        ei.setImageResource(R.drawable.ics_ic_lockscreen_emergencycall_normal);
        em.addView(ei, new LinearLayout.LayoutParams(-2, -2));
        TextView et = new TextView(c);
        et.setText(L.t("emergency"));
        et.setTextSize(17);
        et.setTextColor(Color.WHITE);
        et.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        et.setPadding(dp(12), 0, 0, 0);
        em.addView(et, new LinearLayout.LayoutParams(-2, -2));
        em.setOnClickListener(v -> host.emergency());
        p.addView(em, new LinearLayout.LayoutParams(-1, (int) (sw * 0.125f)));
        return p;
    }

    private void fillIcsPad() {
        Context c = getContext();
        float sw = pw();
        int keyH = (int) (sw * 0.121f), hg = (int) (sw * 0.0125f), vg = (int) (sw * 0.0167f);
        icsPad.removeAllViews();
        List<Integer> d = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 0));
        if (Look.b(c, "pinShuffle", false)) Collections.shuffle(d);
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(c);
            if (r < 3) for (int k = 0; k < 3; k++) row.addView(icsKey(c, String.valueOf(d.get(r * 3 + k)), ICS_NUM[d.get(r * 3 + k)], 1f, hg, keyH));
            else {
                row.addView(icsKey(c, String.valueOf(d.get(9)), ICS_NUM[d.get(9)], 2f, hg, keyH)); // o 0 ocupa 2/3 da linha, como no original
                row.addView(icsKey(c, "OK", R.drawable.ics_sym_keyboard_ok, 1f, hg, keyH));
            }
            LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
            if (r > 0) rl.topMargin = vg;
            icsPad.addView(row, rl);
        }
    }

    private ImageButton icsKey(Context c, final String k, int icon, float weight, int gap, int h) {
        ImageButton b = new ImageButton(c);
        b.setBackgroundResource(R.drawable.ics_btn_keyboard_key_ics);
        b.setImageResource(icon);
        b.setScaleType(ImageView.ScaleType.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, h, weight);
        lp.setMargins(gap / 2, 0, gap / 2, 0);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> {
            if (Look.b(getContext(), "pinHaptic", true))
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
            press(k);
        });
        return b;
    }

    private void fillPad() {
        Context c = getContext();
        pad.removeAllViews();
        List<String> d = new ArrayList<>(Arrays.asList("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"));
        if (Look.b(c, "pinShuffle", false)) Collections.shuffle(d);
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER);
            for (int k = 0; k < 3; k++) {
                String key = r < 3 ? d.get(r * 3 + k) : (k == 0 ? "DEL" : k == 1 ? d.get(9) : "OK");
                LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(dp(72), dp(72));
                klp.setMargins(dp(8), dp(5), dp(8), dp(5));
                row.addView(key(key), klp);
            }
            pad.addView(row);
        }
    }

    /** Fundo redondo e translúcido das teclas, com a cor de destaque ao pressionar. */
    private Drawable keyBg() {
        int acc = Look.accent(getContext());
        GradientDrawable n = new GradientDrawable();
        n.setShape(GradientDrawable.OVAL);
        n.setColor(0x14FFFFFF);
        n.setStroke(dp(1), 0x55FFFFFF);
        GradientDrawable pr = new GradientDrawable();
        pr.setShape(GradientDrawable.OVAL);
        pr.setColor((acc & 0x00FFFFFF) | 0x66000000);
        pr.setStroke(dp(2), acc);
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, pr);
        s.addState(new int[]{}, n);
        return s;
    }

    private Button key(final String k) {
        Context c = getContext();
        Button b = new Button(c, null, android.R.attr.borderlessButtonStyle);
        b.setTransformationMethod(null);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        b.setPadding(0, 0, 0, 0);
        if (!k.equals("DEL") && !k.equals("OK") && Look.b(c, "pinCircles", true)) b.setBackground(keyBg()); // teclas numéricas: círculo translúcido que acende ao tocar
        if (k.equals("DEL")) { b.setText(L.t("delete")); b.setTextSize(15); }
        else if (k.equals("OK")) { b.setText(L.t("ok")); b.setTextSize(20); }
        else {
            SpannableStringBuilder s = new SpannableStringBuilder(k);
            s.setSpan(new AbsoluteSizeSpan(30, true), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            String lt = LETTERS[Integer.parseInt(k)];
            if (Look.b(c, "pinLetters", true) && !lt.isEmpty()) {
                int st = s.length() + 1;
                s.append("\n").append(lt);
                s.setSpan(new AbsoluteSizeSpan(10, true), st, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                s.setSpan(new ForegroundColorSpan(0xFFAAAAAA), st, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            b.setText(s);
        }
        b.setOnClickListener(v -> {
            if (Look.b(getContext(), "pinHaptic", true))
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
            press(k);
        });
        return b;
    }

    private void press(String k) {
        if (Store.sealed(getContext())) { setMsg(L.t("sealed")); return; }
        if (Attempts.remainingMs(getContext()) > 0) { lockoutUi(); return; }
        if (k.equals("DEL")) { if (pin.length() > 0) pin.setLength(pin.length() - 1); dots(); return; }
        if (k.equals("OK")) { submit(); return; }
        if (pin.length() >= 8) return;
        pin.append(k);
        dots();
        if (pin.length() >= Prefs.pinLen(getContext())) submit();
    }

    private void submit() {
        if (pin.length() == 0) return;
        if (Prefs.check(getContext(), pin.toString())) {
            Attempts.ok(getContext());
            int s = pendingSlot;
            pendingSlot = -1;
            if (s >= 0) host.unlockAndLaunch(s); else host.unlock();
            return;
        }
        pin.setLength(0);
        dots();
        setMsg(L.t("pin_wrong"));
        dots.startAnimation(shake());
        idots.startAnimation(shake());
        Attempts.fail(getContext());
        lockoutUi();
    }

    private void dots() {
        StringBuilder s = new StringBuilder();
        boolean show = Look.b(getContext(), "pinShow", false);
        for (int i = 0; i < pin.length(); i++) s.append(show ? pin.charAt(i) + " " : "\u25CF ");
        dots.setText(s.length() == 0 ? " " : s.toString());
        if (idots != null) idots.setText(s.length() == 0 ? " " : s.toString().trim());
    }

    /** Largura/altura em RETRATO: a tela de bloqueio é sempre em pé, mesmo ligando o aparelho vindo de um app na horizontal. */
    private int pw() { android.util.DisplayMetrics m = getResources().getDisplayMetrics(); return Math.min(m.widthPixels, m.heightPixels); }

    private int ph() { android.util.DisplayMetrics m = getResources().getDisplayMetrics(); return Math.max(m.widthPixels, m.heightPixels); }

    private boolean lockedUi;
    private final Runnable lockTick = this::lockoutUi;

    /** Mostra a contagem do bloqueio por tentativas e trava a entrada; quando acaba, volta ao normal. */
    private void lockoutUi() {
        removeCallbacks(lockTick);
        Context c = getContext();
        long r = Attempts.remainingMs(c);
        if (r > 0) {
            lockedUi = true;
            pat.setBlocked(true);
            pin.setLength(0);
            dots();
            setMsg(String.format(L.t("at_wait"), Attempts.left(r)));
            postDelayed(lockTick, 500);
        } else if (lockedUi) {
            lockedUi = false;
            pat.setBlocked(false);
            setMsg(L.t(Look.patternOn(c) ? "pat_draw" : "pin_enter"));
        }
    }

    private void patternDone(String seq) {
        if (Store.sealed(getContext())) { pat.reset(); setMsg(L.t("sealed")); return; }
        if (Attempts.remainingMs(getContext()) > 0) { pat.reset(); lockoutUi(); return; }
        if (seq.length() >= 4 && Prefs.checkPattern(getContext(), seq)) {
            Attempts.ok(getContext());
            int s = pendingSlot;
            pendingSlot = -1;
            if (s >= 0) host.unlockAndLaunch(s); else host.unlock();
            return;
        }
        setMsg(L.t("pat_wrong"));
        pat.showWrong();
        if (seq.length() >= 4) Attempts.fail(getContext());
        if (Attempts.remainingMs(getContext()) > 0) { lockoutUi(); return; }
        postDelayed(() -> { if (pat.getVisibility() == View.VISIBLE && Attempts.remainingMs(getContext()) == 0) setMsg(L.t("pat_draw")); }, 2000);
    }

    private void showPin() {
        pin.setLength(0);
        Context c = getContext();
        boolean pt = Look.patternOn(c), ics = pt || Look.pinUi(c) != 1;
        setMsg(L.t(pt ? "pat_draw" : "pin_enter"));
        dots();
        lockPane.setVisibility(View.GONE);
        if (ics) { // página do 4.0.4 (transparente: o papel de parede aparece por trás)
            pat.reset();
            pat.setVisibility(pt ? View.VISIBLE : View.GONE);
            icsField.setVisibility(pt ? View.GONE : View.VISIBLE);
            icsPad.setVisibility(pt ? View.GONE : View.VISIBLE);
            if (!pt) fillIcsPad();
            pinPane.setVisibility(View.GONE);
            icsPane.setVisibility(View.VISIBLE);
        } else { // teclado Holo antigo (opcional)
            fillPad();
            icsPane.setVisibility(View.GONE);
            pinPane.setVisibility(View.VISIBLE);
        }
        if (Store.sealed(c)) setMsg(L.t("sealed"));
        lockoutUi();
    }

    void showLock() {
        pendingSlot = -1;
        pin.setLength(0);
        pinPane.setVisibility(View.GONE);
        icsPane.setVisibility(View.GONE);
        lockPane.setVisibility(View.VISIBLE);
    }

    /** Ícone do atalho: foto escolhida (recortada em círculo) ou o ícone do app. */
    private static final java.util.HashMap<String, Drawable> iconCache = new java.util.HashMap<>();

    /** Ícone do atalho em cache (foto, câmera redesenhada ou ícone do app): só reconstrói se algo mudou. */
    private Drawable icon(int slot) {
        Context c = getContext();
        java.io.File pf = Prefs.scPhoto(c, slot);
        String key = slot + "|" + (Look.ics(c) ? "i" : "h") + "|" + (pf.exists() ? pf.lastModified() + ":" + pf.length() + ":" + Look.idxd(c, "scShape", 3, 0) : "") + "|" + Prefs.shortcut(c, slot);
        Drawable d = iconCache.get(key);
        if (d != null) return d;
        d = buildIcon(slot);
        if (d != null) { if (iconCache.size() > 32) iconCache.clear(); iconCache.put(key, d); }
        return d;
    }

    private Drawable buildIcon(int slot) {
        Context c = getContext();
        if (Prefs.scPhoto(c, slot).exists()) {
            Bitmap b = BitmapFactory.decodeFile(Prefs.scPhoto(c, slot).getPath());
            if (b != null) return new BitmapDrawable(c.getResources(), shaped(b, Look.idxd(c, "scShape", 3, 0)));
        }
        String pkg = Prefs.shortcut(c, slot);
        if (pkg == null) return null;
        if (pkg.equals(Presets.resolve(c, 2))) return Look.ics(c) ? c.getDrawable(R.drawable.ics_ic_lockscreen_camera_normal).mutate() : new CameraIcon(); // app de câmera: ícone do 4.0 ou redesenhado
        if (pkg.startsWith("com.google.android.googlequicksearchbox")) return c.getDrawable(R.drawable.ic_lockscreen_google_normal).mutate(); // logo "Google" do Holo Locker
        try { return c.getPackageManager().getApplicationIcon(pkg); } catch (PackageManager.NameNotFoundException e) { return null; }
    }

    /** O atalho usa um recurso original do 4.0 (câmera), desenhado no tamanho original. */
    private boolean isAsset(int slot) {
        Context c = getContext();
        String pkg = Prefs.shortcut(c, slot);
        return pkg != null && !Prefs.scPhoto(c, slot).exists() && pkg.equals(Presets.resolve(c, 2)); // atalho da câmera: ícone do Holo Locker (ou do 4.0)
    }

    /** 0 = redonda, 1 = quadrado arredondado (recorta o centro), 2 = original (mantém a proporção, sem recorte). */
    static Bitmap shaped(Bitmap src, int shape) {
        if (shape == 0) return circle(src);
        Bitmap b = src;
        if (shape == 1) {
            int s = Math.min(src.getWidth(), src.getHeight());
            b = Bitmap.createBitmap(src, (src.getWidth() - s) / 2, (src.getHeight() - s) / 2, s, s);
        }
        float k = 256f / Math.max(b.getWidth(), b.getHeight());
        int w = Math.max(1, Math.round(b.getWidth() * k)), h = Math.max(1, Math.round(b.getHeight() * k));
        Bitmap sc = Bitmap.createScaledBitmap(b, w, h, true);
        Bitmap out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new BitmapShader(sc, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP));
        float rad = shape == 1 ? w * 0.2f : Math.min(w, h) * 0.06f;
        new Canvas(out).drawRoundRect(new RectF(0, 0, w, h), rad, rad, p);
        return out;
    }

    static Bitmap circle(Bitmap src) {
        int s = Math.min(src.getWidth(), src.getHeight());
        Bitmap sq = Bitmap.createBitmap(src, (src.getWidth() - s) / 2, (src.getHeight() - s) / 2, s, s);
        Bitmap out = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap scaled = Bitmap.createScaledBitmap(sq, 256, 256, true);
        p.setShader(new BitmapShader(scaled, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP));
        new Canvas(out).drawCircle(128, 128, 128, p);
        return out;
    }
}
