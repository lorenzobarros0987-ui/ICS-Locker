package com.meu.pinlocker;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.format.DateFormat;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** A tela de bloqueio inteira (relógio, anéis, teclado de PIN). Fica numa janela por cima de tudo (LockService) ou na prévia. */
public class LockScreen extends FrameLayout {
    interface Host { void unlock(); void launch(int slot); void keyboardPin(); }

    private static final String[] LETTERS = {"+", "", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ"};

    private final Host host;
    private final FrameLayout lockPane;
    private final ImageView photo;
    private final View dim;
    private final LinearLayout pinPane, pad, clock;
    private final FrameLayout.LayoutParams clockLp;
    private final LockView lockView;
    private final TextView msg, dots;
    private final TextClock time, ampm, date;
    private final StringBuilder pin = new StringBuilder();

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    LockScreen(Context c, Host h) {
        super(c);
        host = h;
        photo = new ImageView(c);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        dim = new View(c);
        addView(photo, new FrameLayout.LayoutParams(-1, -1));
        addView(dim, new FrameLayout.LayoutParams(-1, -1));

        lockPane = new FrameLayout(c);
        lockView = new LockView(c, new LockView.Listener() {
            @Override public void onUnlock() {
                if (!Prefs.hasPin(getContext())) host.unlock();
                else if (Look.idxd(getContext(), "pinStyle", 2, 0) == 1) host.keyboardPin();
                else showPin();
            }
            @Override public void onShortcut(int slot) { host.launch(slot); }
        });
        lockPane.addView(lockView, new FrameLayout.LayoutParams(-1, -1));

        clock = new LinearLayout(c);
        clock.setOrientation(LinearLayout.VERTICAL);
        clock.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout hm = new LinearLayout(c);
        hm.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        time = new TextClock(c);
        time.setIncludeFontPadding(true);
        time.setPadding(0, dp(10), 0, dp(4));
        ampm = new TextClock(c);
        ampm.setFormat12Hour("a");
        ampm.setFormat24Hour("a");
        ampm.setTextSize(20);
        ampm.setTextColor(0xFFB0B0B0);
        ampm.setPadding(dp(6), 0, 0, dp(14));
        hm.addView(time);
        hm.addView(ampm);
        date = new TextClock(c);
        date.setTextSize(18);
        date.setTextColor(0xFFB0B0B0);
        date.setGravity(Gravity.CENTER_HORIZONTAL);
        clock.addView(hm);
        clock.addView(date);
        clockLp = new FrameLayout.LayoutParams(-1, -2);
        lockPane.addView(clock, clockLp);

        msg = new TextView(c);
        dots = new TextView(c);
        pad = new LinearLayout(c);
        pinPane = buildPin(c);
        pinPane.setVisibility(View.GONE);

        addView(lockPane, new FrameLayout.LayoutParams(-1, -1));
        addView(pinPane, new FrameLayout.LayoutParams(-1, -1));
        // se a barra de baixo aparecer por qualquer motivo, esconde de novo na hora
        setOnSystemUiVisibilityChangeListener(v -> { if ((v & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) == 0) hideBars(); });
    }

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_APP_SWITCH) return true;
        return super.dispatchKeyEvent(e);
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideBars();
    }

    /** Chamado ao mostrar a tela: aplica o visual escolhido e volta para o relógio. */
    void refresh() {
        applyLook();
        lockView.setIcons(icon(0), icon(1));
        showLock();
        hideBars();
    }

    void hideBars() {
        setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private void applyLook() {
        Context c = getContext();
        int bgIdx = Look.idxd(c, "bg", Look.BG.length, Look.BG_WALL);
        Drawable wp = null;
        Bitmap bmp = null;
        if (bgIdx == Look.BG_WALL) wp = wallpaper(c);
        if (bgIdx == Look.BG_PHOTO) bmp = Look.photo(c);
        int[] cols = Look.BG[bgIdx == Look.BG_WALL && wp == null ? 0 : bgIdx];
        setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, cols));
        if (wp != null) photo.setImageDrawable(wp); else photo.setImageBitmap(bmp);
        boolean hasPic = wp != null || bmp != null;
        photo.setVisibility(hasPic ? View.VISIBLE : View.GONE);
        int dimPct = Look.i(c, "dim", 30);
        dim.setBackgroundColor(Color.argb(hasPic ? dimPct * 255 / 100 : 0, 0, 0, 0));

        int acc = Look.accent(c);
        msg.setTextColor(acc);
        lockView.setTint(Look.b(c, "ringTint", false) ? acc : 0);

        time.setTypeface(Fonts.time(c));
        date.setTypeface(Fonts.date(c));
        ampm.setTypeface(Fonts.date(c));
        time.setTextSize(Look.i(c, "csize", 84));
        time.setTextColor(new int[]{Color.WHITE, acc, 0xFFCCCCCC, 0xFFFFEB3B}[Look.idxd(c, "ccol", 4, 0)]);

        int hm = Look.idxd(c, "hmode", 3, 0);
        boolean is24 = hm == 1 || (hm == 0 && DateFormat.is24HourFormat(c));
        String tf = is24 ? "HH:mm" : "h:mm";
        time.setFormat12Hour(tf);
        time.setFormat24Hour(tf);
        ampm.setVisibility(is24 ? View.GONE : View.VISIBLE);

        String df = Look.dfmt(c);
        date.setFormat12Hour(df);
        date.setFormat24Hour(df);
        date.setVisibility(Look.b(c, "showDate", true) ? View.VISIBLE : View.GONE);

        float hpx = getResources().getDisplayMetrics().heightPixels;
        int pos = Look.idxd(c, "cpos", 3, 2); // padrão: mais embaixo
        clockLp.topMargin = (int) (hpx * (pos == 0 ? 0.06f : pos == 1 ? 0.12f : 0.19f)) + dp(16);
        clock.setLayoutParams(clockLp);
    }

    private static Drawable wallpaperCache;

    /** Fundo de tela do celular (precisa da permissão de leitura; sem ela cai para o fundo Holo). */
    private Drawable wallpaper(Context c) {
        try {
            Drawable d = WallpaperManager.getInstance(c.getApplicationContext()).getDrawable();
            if (d != null) wallpaperCache = d;
        } catch (Throwable ignored) { }
        return wallpaperCache;
    }

    private LinearLayout buildPin(Context c) {
        LinearLayout p = new LinearLayout(c);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setGravity(Gravity.CENTER);
        p.setBackgroundColor(0xB3000000);
        msg.setTextSize(18);
        msg.setGravity(Gravity.CENTER);
        dots.setTextColor(Color.WHITE);
        dots.setTextSize(28);
        dots.setGravity(Gravity.CENTER);
        TypedValue tv = new TypedValue();
        if (c.getTheme().resolveAttribute(android.R.attr.editTextBackground, tv, true) && tv.resourceId != 0)
            dots.setBackgroundResource(tv.resourceId); // sublinhado Holo do tema do sistema
        dots.setMinWidth(dp(240));
        p.addView(msg);
        p.addView(dots, new LinearLayout.LayoutParams(-2, -2));
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setPadding(0, dp(16), 0, 0);
        p.addView(pad);
        Button cancel = new Button(c, null, android.R.attr.borderlessButtonStyle);
        cancel.setText(L.t("cancel"));
        cancel.setTextColor(0xFFCCCCCC);
        cancel.setOnClickListener(v -> showLock());
        p.addView(cancel);
        return p;
    }

    private void fillPad() {
        Context c = getContext();
        pad.removeAllViews();
        List<String> d = new ArrayList<>(Arrays.asList("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"));
        if (Look.b(c, "pinShuffle", false)) Collections.shuffle(d);
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(c);
            row.setGravity(Gravity.CENTER);
            for (int k = 0; k < 3; k++) {
                String key = r < 3 ? d.get(r * 3 + k) : (k == 0 ? "DEL" : k == 1 ? d.get(9) : "OK");
                row.addView(key(key), new LinearLayout.LayoutParams(dp(96), dp(72)));
            }
            pad.addView(row);
        }
    }

    private Button key(final String k) {
        Context c = getContext();
        Button b = new Button(c, null, android.R.attr.borderlessButtonStyle);
        b.setTransformationMethod(null);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        b.setPadding(0, 0, 0, 0);
        if (k.equals("DEL")) { b.setText(L.t("delete")); b.setTextSize(15); }
        else if (k.equals("OK")) { b.setText(L.t("ok")); b.setTextSize(20); }
        else {
            SpannableStringBuilder s = new SpannableStringBuilder(k);
            s.setSpan(new AbsoluteSizeSpan(30, true), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            String lt = LETTERS[Integer.parseInt(k)];
            if (Look.b(c, "pinLetters", true) && !lt.isEmpty()) {
                int st = s.length() + 1;
                s.append("\n").append(lt);
                s.setSpan(new AbsoluteSizeSpan(10, true), st, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                s.setSpan(new ForegroundColorSpan(0xFFAAAAAA), st, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            b.setText(s);
        }
        b.setOnClickListener(v -> {
            if (Look.b(getContext(), "pinHaptic", true))
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
            press(k);
        });
        return b;
    }

    private void press(String k) {
        if (k.equals("DEL")) { if (pin.length() > 0) pin.setLength(pin.length() - 1); dots(); return; }
        if (k.equals("OK")) { submit(); return; }
        if (pin.length() >= 8) return;
        pin.append(k);
        dots();
        if (pin.length() >= Prefs.pinLen(getContext())) submit();
    }

    private void submit() {
        if (pin.length() == 0) return;
        if (Prefs.check(getContext(), pin.toString())) { host.unlock(); return; }
        pin.setLength(0);
        dots();
        msg.setText(L.t("pin_wrong"));
        TranslateAnimation a = new TranslateAnimation(0, dp(14), 0, 0);
        a.setDuration(300);
        a.setInterpolator(new CycleInterpolator(3));
        dots.startAnimation(a);
    }

    private void dots() {
        StringBuilder s = new StringBuilder();
        boolean show = Look.b(getContext(), "pinShow", false);
        for (int i = 0; i < pin.length(); i++) s.append(show ? pin.charAt(i) + " " : "\u25CF ");
        dots.setText(s.length() == 0 ? " " : s.toString());
    }

    private void showPin() {
        pin.setLength(0);
        msg.setText(L.t("pin_enter"));
        dots();
        fillPad();
        lockPane.setVisibility(View.GONE);
        pinPane.setVisibility(View.VISIBLE);
    }

    void showLock() {
        pin.setLength(0);
        pinPane.setVisibility(View.GONE);
        lockPane.setVisibility(View.VISIBLE);
    }

    /** Ícone do atalho: foto escolhida (recortada em círculo) ou o ícone do app. */
    private Drawable icon(int slot) {
        Context c = getContext();
        if (Prefs.scPhoto(c, slot).exists()) {
            Bitmap b = BitmapFactory.decodeFile(Prefs.scPhoto(c, slot).getPath());
            if (b != null) return new BitmapDrawable(c.getResources(), circle(b));
        }
        String pkg = Prefs.shortcut(c, slot);
        if (pkg == null) return null;
        try { return c.getPackageManager().getApplicationIcon(pkg); } catch (PackageManager.NameNotFoundException e) { return null; }
    }

    static Bitmap circle(Bitmap src) {
        int s = Math.min(src.getWidth(), src.getHeight());
        Bitmap sq = Bitmap.createBitmap(src, (src.getWidth() - s) / 2, (src.getHeight() - s) / 2, s, s);
        Bitmap out = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap scaled = Bitmap.createScaledBitmap(sq, 256, 256, true);
        p.setShader(new BitmapShader(scaled, android.graphics.Shader.TileMode.CLAMP, android.graphics.Shader.TileMode.CLAMP));
        new Canvas(out).drawCircle(128, 128, 128, p);
        return out;
    }
}
