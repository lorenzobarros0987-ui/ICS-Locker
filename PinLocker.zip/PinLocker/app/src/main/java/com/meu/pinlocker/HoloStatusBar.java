package com.meu.pinlocker;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.View;
import java.util.Date;
import java.util.List;

/**
 * Status bar própria, estilo Holo: ícones das notificações à esquerda; alarme, som, Wi-Fi, sinal,
 * bateria e hora à direita. Desenhada no Canvas (a barra do sistema fica escondida).
 */
public class HoloStatusBar extends View {
    private static final int DIM = 0x55FFFFFF, WHITE = 0xFFFFFFFF;
    private final float dp;
    private final int barH;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Path path = new Path();
    private final Handler h = new Handler(Looper.getMainLooper());
    private LinearGradient bg;
    private int accent = 0xFF33B5E5;

    private int level = -1;            // bateria 0-100
    private boolean charging;
    private int net;                   // 0 nada, 1 Wi-Fi, 2 dados móveis
    private int wifiLvl = 4;           // 0-4
    private int cellLvl = 4;           // 0-4
    private boolean airplane, alarm;
    private int ringer = AudioManager.RINGER_MODE_NORMAL;

    private final Runnable changed = () -> postInvalidate();
    private final Runnable poll = new Runnable() {
        @Override public void run() { readSlow(); invalidate(); h.postDelayed(this, 3000); }
    };
    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_BATTERY_CHANGED.equals(i.getAction())) readBattery(i); else readSlow();
            invalidate();
        }
    };

    HoloStatusBar(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        int sb = 0;
        int rid = c.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (rid > 0) sb = c.getResources().getDimensionPixelSize(rid);
        barH = Math.max(sb, (int) (24 * dp));
        txt.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        txt.setColor(WHITE);
        txt.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 14, c.getResources().getDisplayMetrics()));
        p.setStrokeCap(Paint.Cap.ROUND);
        setClickable(false);
    }

    int barHeight() { return barH; }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        Context a = getContext().getApplicationContext();
        IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        f.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        f.addAction(AudioManager.RINGER_MODE_CHANGED_ACTION);
        f.addAction(Intent.ACTION_TIME_TICK);
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        f.addAction(Intent.ACTION_TIME_CHANGED);
        Intent sticky = a.registerReceiver(rx, f);
        if (sticky != null) readBattery(sticky);
        NotifListener.addListener(changed);
        readSlow();
        h.post(poll);
    }

    @Override protected void onDetachedFromWindow() {
        h.removeCallbacks(poll);
        NotifListener.removeListener(changed);
        try { getContext().getApplicationContext().unregisterReceiver(rx); } catch (Exception ignored) { }
        super.onDetachedFromWindow();
    }

    @Override protected void onMeasure(int w, int hh) { setMeasuredDimension(MeasureSpec.getSize(w), barH); }

    @Override protected void onSizeChanged(int w, int hh, int ow, int oh) {
        bg = new LinearGradient(0, 0, 0, hh, 0xB0000000, 0x40000000, Shader.TileMode.CLAMP);
    }

    private void readBattery(Intent i) {
        int sc = i.getIntExtra("scale", 100);
        level = sc > 0 ? i.getIntExtra("level", 0) * 100 / sc : 0;
        charging = i.getIntExtra("plugged", 0) != 0;
    }

    private void readSlow() {
        Context c = getContext().getApplicationContext();
        accent = Look.accent(c);
        try { airplane = Settings.Global.getInt(c.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0; } catch (Throwable ignored) { }
        try { AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE); if (am != null) ringer = am.getRingerMode(); } catch (Throwable ignored) { }
        try { AlarmManager al = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE); alarm = al != null && al.getNextAlarmClock() != null; } catch (Throwable ignored) { }
        net = 0;
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            if (ni != null && ni.isConnected()) net = ni.getType() == ConnectivityManager.TYPE_WIFI ? 1 : 2;
        } catch (Throwable ignored) { }
        if (net == 1) {
            try {
                WifiManager wm = (WifiManager) c.getSystemService(Context.WIFI_SERVICE);
                WifiInfo wi = wm == null ? null : wm.getConnectionInfo();
                if (wi != null) wifiLvl = Math.max(0, Math.min(4, WifiManager.calculateSignalLevel(wi.getRssi(), 5)));
            } catch (Throwable ignored) { }
        }
        // sinal do celular: sem a permissão de telefone o Android pode não informar; aí assume sinal cheio
        cellLvl = 4;
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
                SignalStrength ss = tm == null ? null : tm.getSignalStrength();
                if (ss != null) cellLvl = Math.max(0, Math.min(4, ss.getLevel()));
            } catch (Throwable ignored) { }
        }
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), hh = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setShader(bg);
        c.drawRect(0, 0, w, hh, p);
        p.setShader(null);
        p.setColor(accent);
        p.setAlpha(110);
        c.drawRect(0, hh - dp, w, hh, p); // fio fino de cor de destaque, como na barra Holo

        float cy = hh - 12f * dp; // centro do conteúdo: faixa de baixo da barra (acima do fio), ignora o recorte da câmera
        float x = w - 8f * dp;

        // hora
        String time = DateFormat.getTimeFormat(getContext()).format(new Date());
        txt.setColor(WHITE);
        txt.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 14, getResources().getDisplayMetrics()));
        float ty = cy - (txt.ascent() + txt.descent()) / 2f;
        x -= txt.measureText(time);
        c.drawText(time, x, ty, txt);
        x -= 10f * dp;

        // bateria (vertical, como no Holo) + porcentagem
        if (level >= 0) {
            float bw = 9f * dp, bh = 15f * dp, left = x - bw;
            drawBattery(c, left, cy - bh / 2f, bw, bh);
            x = left - 3f * dp;
            txt.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 12, getResources().getDisplayMetrics()));
            String pct = level + "%";
            float pw = txt.measureText(pct);
            c.drawText(pct, x - pw, cy - (txt.ascent() + txt.descent()) / 2f, txt);
            x -= pw + 10f * dp;
        }

        // sinal do celular / modo avião
        if (airplane) {
            txt.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 14, getResources().getDisplayMetrics()));
            float aw = txt.measureText("\u2708");
            c.drawText("\u2708", x - aw, cy - (txt.ascent() + txt.descent()) / 2f, txt);
            x -= aw + 8f * dp;
        } else {
            float bw = 3f * dp, gap = 1.5f * dp, tot = 4 * bw + 3 * gap, left = x - tot;
            for (int i = 0; i < 4; i++) {
                float bhh = (5f + i * 3f) * dp, bx = left + i * (bw + gap);
                p.setColor(i < cellLvl ? accent : DIM);
                rf.set(bx, cy + 7.5f * dp - bhh, bx + bw, cy + 7.5f * dp);
                c.drawRect(rf, p);
            }
            x = left - 8f * dp;
        }

        // Wi-Fi
        if (net == 1 && !airplane) {
            float s = 14f * dp, cx = x - s / 2f, by = cy + 7f * dp;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f * dp);
            for (int i = 1; i <= 4; i++) {
                float rad = s * 0.95f * i / 4f;
                p.setColor(i <= Math.max(1, wifiLvl) ? accent : DIM);
                rf.set(cx - rad, by - rad, cx + rad, by + rad);
                c.drawArc(rf, 225f, 90f, false, p);
            }
            p.setStyle(Paint.Style.FILL);
            x -= s + 8f * dp;
        }

        // som: vibrar / silencioso
        if (ringer == AudioManager.RINGER_MODE_VIBRATE) {
            p.setColor(WHITE);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.5f * dp);
            rf.set(x - 8f * dp, cy - 6f * dp, x - 2f * dp, cy + 6f * dp);
            c.drawRoundRect(rf, 1.5f * dp, 1.5f * dp, p);
            c.drawLine(x - 10.5f * dp, cy - 3f * dp, x - 10.5f * dp, cy + 3f * dp, p);
            c.drawLine(x + 0.5f * dp, cy - 3f * dp, x + 0.5f * dp, cy + 3f * dp, p);
            p.setStyle(Paint.Style.FILL);
            x -= 18f * dp;
        } else if (ringer == AudioManager.RINGER_MODE_SILENT) {
            x -= drawFw(c, android.R.drawable.ic_lock_silent_mode, x, cy, 16f * dp, WHITE) + 6f * dp;
        }

        // alarme
        if (alarm) x -= drawFw(c, android.R.drawable.ic_lock_idle_alarm, x, cy, 16f * dp, accent) + 6f * dp;

        // ícones das notificações (esquerda); some o que não couber e mostra "+N"
        List<Drawable> ic = NotifListener.icons();
        float lx = 8f * dp, isz = 16f * dp, room = x - lx - 8f * dp;
        int fit = (int) (room / (isz + 5f * dp)), n = ic.size();
        boolean more = n > fit;
        int show = more ? Math.max(0, fit - 1) : n;
        for (int i = 0; i < show; i++) {
            Drawable d = ic.get(i);
            d.setBounds((int) lx, (int) (cy - isz / 2f), (int) (lx + isz), (int) (cy + isz / 2f));
            d.draw(c);
            lx += isz + 5f * dp;
        }
        if (more && fit > 0) {
            txt.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 12, getResources().getDisplayMetrics()));
            txt.setColor(accent);
            c.drawText("+" + (n - show), lx, cy - (txt.ascent() + txt.descent()) / 2f, txt);
            txt.setColor(WHITE);
        }
    }

    /** Desenha um ícone do sistema pintado numa cor, terminando em x (à direita). Devolve a largura usada. */
    private float drawFw(Canvas c, int res, float xRight, float cy, float size, int color) {
        try {
            Drawable d = getContext().getDrawable(res);
            if (d == null) return 0;
            d = d.mutate();
            d.setColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN);
            d.setBounds((int) (xRight - size), (int) (cy - size / 2f), (int) xRight, (int) (cy + size / 2f));
            d.draw(c);
            return size;
        } catch (Throwable t) { return 0; }
    }

    private void drawBattery(Canvas c, float x, float y, float bw, float bh) {
        float nub = 2f * dp, body = bh - nub;
        int col = level <= 15 && !charging ? 0xFFFF4444 : accent;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.3f * dp);
        p.setColor(0xFFDDDDDD);
        rf.set(x, y + nub, x + bw, y + bh);
        c.drawRoundRect(rf, 1.5f * dp, 1.5f * dp, p);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(x + bw * 0.3f, y, x + bw * 0.7f, y + nub + 0.5f * dp, p); // ponta
        p.setColor(col);
        float in = 2f * dp, fh = (body - 2 * in) * Math.max(0, Math.min(100, level)) / 100f;
        rf.set(x + in, y + bh - in - fh, x + bw - in, y + bh - in);
        c.drawRect(rf, p);
        if (charging) { // raio
            float cx = x + bw / 2f, cyy = y + nub + body / 2f;
            path.reset();
            path.moveTo(cx + 1.2f * dp, cyy - 4.5f * dp);
            path.lineTo(cx - 2.2f * dp, cyy + 0.5f * dp);
            path.lineTo(cx - 0.1f * dp, cyy + 0.5f * dp);
            path.lineTo(cx - 1.2f * dp, cyy + 4.5f * dp);
            path.lineTo(cx + 2.2f * dp, cyy - 0.5f * dp);
            path.lineTo(cx + 0.1f * dp, cyy - 0.5f * dp);
            path.close();
            p.setColor(WHITE);
            c.drawPath(path, p);
        }
    }
}
