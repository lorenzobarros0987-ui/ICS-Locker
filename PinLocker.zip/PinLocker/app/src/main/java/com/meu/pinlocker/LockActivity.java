package com.meu.pinlocker;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.format.DateFormat;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LockActivity extends Activity {
    private static final String[] LETTERS = {"+", "", "ABC", "DEF", "GHI", "JKL", "MNO", "PQRS", "TUV", "WXYZ"};

    private FrameLayout root, lockPane;
    private ImageView photo;
    private View dim;
    private LinearLayout pinPane, pad, clock;
    private FrameLayout.LayoutParams clockLp;
    private LockView lockView;
    private TextView msg, dots;
    private TextClock time, ampm, date;
    private boolean preview;
    private final StringBuilder pin = new StringBuilder();

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        preview = getIntent().getBooleanExtra("preview", false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        root = new FrameLayout(this);
        photo = new ImageView(this);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        dim = new View(this);
        root.addView(photo, new FrameLayout.LayoutParams(-1, -1));
        root.addView(dim, new FrameLayout.LayoutParams(-1, -1));

        lockPane = new FrameLayout(this);
        lockView = new LockView(this, new LockView.Listener() {
            @Override public void onUnlock() { if (Prefs.hasPin(LockActivity.this)) showPin(); else unlockNow(); }
            @Override public void onShortcut(int slot) { launch(slot); }
        });
        lockPane.addView(lockView, new FrameLayout.LayoutParams(-1, -1));

        clock = new LinearLayout(this);
        clock.setOrientation(LinearLayout.VERTICAL);
        clock.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout hm = new LinearLayout(this);
        hm.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        time = new TextClock(this);
        time.setIncludeFontPadding(false);
        ampm = new TextClock(this);
        ampm.setFormat12Hour("a");
        ampm.setFormat24Hour("a");
        ampm.setTextSize(20);
        ampm.setTextColor(0xFFB0B0B0);
        ampm.setPadding(dp(6), 0, 0, dp(10));
        hm.addView(time);
        hm.addView(ampm);
        date = new TextClock(this);
        date.setTextSize(18);
        date.setTextColor(0xFFB0B0B0);
        date.setGravity(Gravity.CENTER_HORIZONTAL);
        clock.addView(hm);
        clock.addView(date);
        clockLp = new FrameLayout.LayoutParams(-1, -2);
        lockPane.addView(clock, clockLp);

        pinPane = buildPin();
        pinPane.setVisibility(View.GONE);

        root.addView(lockPane, new FrameLayout.LayoutParams(-1, -1));
        root.addView(pinPane, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    /** Aplica fundo, cores, fonte e tamanhos escolhidos em Aparência. */
    private void applyLook() {
        int bgIdx = Look.idx(this, "bg", Look.BG_N.length);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, Look.BG[bgIdx]));
        Bitmap bmp = bgIdx == 7 ? Look.photo(this) : null;
        photo.setImageBitmap(bmp);
        photo.setVisibility(bmp == null ? View.GONE : View.VISIBLE);
        dim.setBackgroundColor(Color.argb(bmp == null ? 0 : Look.i(this, "dim", 30) * 255 / 100, 0, 0, 0));

        int acc = Look.accent(this);
        msg.setTextColor(acc);
        lockView.setTint(Look.b(this, "ringTint", false) ? acc : 0);

        time.setTypeface(Fonts.time(this));
        date.setTypeface(Fonts.date(this));
        ampm.setTypeface(Fonts.date(this));
        time.setTextSize(Look.i(this, "csize", 84));
        time.setTextColor(new int[]{Color.WHITE, acc, 0xFFCCCCCC, 0xFFFFEB3B}[Look.idx(this, "ccol", 4)]);

        int hm = Look.idx(this, "hmode", 3);
        boolean is24 = hm == 1 || (hm == 0 && DateFormat.is24HourFormat(this));
        String tf = is24 ? "HH:mm" : "h:mm";
        time.setFormat12Hour(tf);
        time.setFormat24Hour(tf);
        ampm.setVisibility(is24 ? View.GONE : View.VISIBLE);

        String df = Look.DFMT[Look.idx(this, "dfmt", Look.DFMT.length)];
        date.setFormat12Hour(df);
        date.setFormat24Hour(df);
        date.setVisibility(Look.b(this, "showDate", true) ? View.VISIBLE : View.GONE);

        clockLp.topMargin = Look.idx(this, "cpos", 2) == 0 ? dp(48) : (int) (getResources().getDisplayMetrics().heightPixels * 0.14f);
        clock.setLayoutParams(clockLp);
    }

    private LinearLayout buildPin() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setGravity(Gravity.CENTER);
        p.setBackgroundColor(0xB3000000);
        msg = new TextView(this);
        msg.setTextSize(18);
        msg.setGravity(Gravity.CENTER);
        dots = new TextView(this);
        dots.setTextColor(Color.WHITE);
        dots.setTextSize(28);
        dots.setGravity(Gravity.CENTER);
        TypedValue tv = new TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.editTextBackground, tv, true) && tv.resourceId != 0)
            dots.setBackgroundResource(tv.resourceId); // sublinhado Holo do tema do sistema
        dots.setMinWidth(dp(240));
        p.addView(msg);
        p.addView(dots, new LinearLayout.LayoutParams(-2, -2));
        pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setPadding(0, dp(16), 0, 0);
        p.addView(pad);
        Button cancel = new Button(this, null, android.R.attr.borderlessButtonStyle);
        cancel.setText("Cancelar");
        cancel.setTextColor(0xFFCCCCCC);
        cancel.setOnClickListener(v -> showLock());
        p.addView(cancel);
        return p;
    }

    private void fillPad() {
        pad.removeAllViews();
        List<String> d = new ArrayList<>(Arrays.asList("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"));
        if (Look.b(this, "pinShuffle", false)) Collections.shuffle(d);
        for (int r = 0; r < 4; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            for (int c = 0; c < 3; c++) {
                String k = r < 3 ? d.get(r * 3 + c) : (c == 0 ? "DEL" : c == 1 ? d.get(9) : "OK");
                row.addView(key(k), new LinearLayout.LayoutParams(dp(96), dp(72)));
            }
            pad.addView(row);
        }
    }

    /** Tecla com o estilo Holo do sistema (borderlessButtonStyle: destaque azul ao tocar). */
    private Button key(final String k) {
        Button b = new Button(this, null, android.R.attr.borderlessButtonStyle);
        b.setTransformationMethod(null);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        b.setPadding(0, 0, 0, 0);
        if (k.equals("DEL")) { b.setText("Apagar"); b.setTextSize(15); }
        else if (k.equals("OK")) { b.setText("OK"); b.setTextSize(20); }
        else {
            SpannableStringBuilder s = new SpannableStringBuilder(k);
            s.setSpan(new AbsoluteSizeSpan(30, true), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            String L = LETTERS[Integer.parseInt(k)];
            if (Look.b(this, "pinLetters", true) && !L.isEmpty()) {
                int st = s.length() + 1;
                s.append("\n").append(L);
                s.setSpan(new AbsoluteSizeSpan(10, true), st, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                s.setSpan(new ForegroundColorSpan(0xFFAAAAAA), st, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            b.setText(s);
        }
        b.setOnClickListener(v -> {
            if (Look.b(this, "pinHaptic", true))
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
            press(k);
        });
        return b;
    }

    private void press(String k) {
        if (k.equals("DEL")) { if (pin.length() > 0) pin.setLength(pin.length() - 1); dots(); return; }
        if (k.equals("OK")) { submit(); return; }
        if (pin.length() >= 8) return;
        pin.append(k);
        dots();
        if (pin.length() >= Prefs.pinLen(this)) submit();
    }

    private void submit() {
        if (pin.length() == 0) return;
        if (Prefs.check(this, pin.toString())) { unlockNow(); return; }
        pin.setLength(0);
        dots();
        msg.setText("PIN incorreto");
        TranslateAnimation a = new TranslateAnimation(0, dp(14), 0, 0);
        a.setDuration(300);
        a.setInterpolator(new CycleInterpolator(3));
        dots.startAnimation(a);
    }

    private void dots() {
        StringBuilder s = new StringBuilder();
        boolean show = Look.b(this, "pinShow", false);
        for (int i = 0; i < pin.length(); i++) s.append(show ? pin.charAt(i) + " " : "\u25CF ");
        dots.setText(s.length() == 0 ? " " : s.toString());
    }

    private void showPin() {
        pin.setLength(0);
        msg.setText("Digite o PIN");
        dots();
        fillPad();
        lockPane.setVisibility(View.GONE);
        pinPane.setVisibility(View.VISIBLE);
    }

    private void showLock() {
        pin.setLength(0);
        pinPane.setVisibility(View.GONE);
        lockPane.setVisibility(View.VISIBLE);
    }

    private void unlockNow() {
        if (!preview) startService(new Intent(this, LockService.class).setAction(LockService.ACT_UNLOCK));
        finish();
    }

    private void launch(int slot) {
        if (preview) return;
        String pkg = Prefs.shortcut(this, slot);
        if (pkg == null) return;
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) return;
        startService(new Intent(this, LockService.class).setAction(LockService.ACT_ALLOW).putExtra("pkg", pkg));
        startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    private Drawable icon(int slot) {
        String pkg = Prefs.shortcut(this, slot);
        if (pkg == null) return null;
        try { return getPackageManager().getApplicationIcon(pkg); } catch (PackageManager.NameNotFoundException e) { return null; }
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!preview && !Prefs.locked(this)) { finish(); return; }
        applyLook();
        lockView.setIcons(icon(0), icon(1));
        showLock();
        hideBars();
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideBars();
    }

    @Override public void onBackPressed() { if (preview) finish(); }
}
