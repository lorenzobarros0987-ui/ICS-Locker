package com.meu.pinlocker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Usada para: prévia da tela, página de PIN com o teclado do celular e, se faltar a permissão de sobrepor,
 * como tela de bloqueio de reserva. A tela de bloqueio de verdade é a janela do LockService.
 */
public class LockActivity extends Activity implements LockScreen.Host {
    private boolean preview, kbMode, fromService, unlocked, secondary;
    private static LockActivity sec; // camada secundária (atrás do app de atalho)

    /** Tira a camada secundária (chamado pelo LockService depois que a principal voltou). */
    static void closeSecondary() { if (sec != null) { sec.finish(); sec = null; } }
    private LockScreen screen;
    private LinearLayout kbRoot;
    private EditText et;
    private TextView msg;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        L.init(this);
        preview = getIntent().getBooleanExtra("preview", false);
        fromService = getIntent().getBooleanExtra("kb", false);
        secondary = getIntent().getBooleanExtra("secondary", false);
        if (secondary) sec = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        screen = new LockScreen(this, this);
        buildKb();
        if (fromService) showKb(); else showScreen();
    }

    private void showScreen() {
        kbMode = false;
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        if (kbRoot.getParent() != null) ((android.view.ViewGroup) kbRoot.getParent()).removeView(kbRoot);
        setContentView(screen);
        screen.refresh();
    }

    private void buildKb() {
        kbRoot = new LinearLayout(this);
        kbRoot.setOrientation(LinearLayout.VERTICAL);
        kbRoot.setGravity(Gravity.CENTER);
        kbRoot.setPadding(dp(24), dp(24), dp(24), dp(24));
        kbRoot.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, Look.BG[0]));
        msg = new TextView(this);
        msg.setTextSize(20);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, 0, 0, dp(12));
        kbRoot.addView(msg);
        et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        et.setGravity(Gravity.CENTER);
        et.setTextSize(28);
        et.setTextColor(Color.WHITE);
        et.setImeOptions(EditorInfo.IME_ACTION_DONE);
        et.setOnEditorActionListener((v, a, e) -> { submit(); return true; });
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { if (s.length() >= Prefs.pinLen(LockActivity.this)) submit(); }
        });
        kbRoot.addView(et, new LinearLayout.LayoutParams(dp(260), -2));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp(12), 0, 0);
        Button cancel = new Button(this, null, android.R.attr.borderlessButtonStyle), ok = new Button(this, null, android.R.attr.borderlessButtonStyle);
        cancel.setText(L.t("cancel"));
        cancel.setTextColor(0xFFCCCCCC);
        cancel.setOnClickListener(v -> cancelKb());
        ok.setText(L.t("ok"));
        ok.setTextColor(Color.WHITE);
        ok.setOnClickListener(v -> submit());
        row.addView(cancel, new LinearLayout.LayoutParams(dp(120), -2));
        row.addView(ok, new LinearLayout.LayoutParams(dp(120), -2));
        kbRoot.addView(row);
    }

    private void showKb() {
        kbMode = true;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        msg.setTextColor(Look.accent(this));
        msg.setText(L.t("kb_hint"));
        et.setText("");
        if (screen.getParent() != null) ((android.view.ViewGroup) screen.getParent()).removeView(screen);
        setContentView(kbRoot);
        et.requestFocus();
        et.postDelayed(() -> {
            InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (m != null) m.showSoftInput(et, InputMethodManager.SHOW_FORCED);
        }, 200);
    }

    private void submit() {
        String p = et.getText().toString();
        if (p.isEmpty()) return;
        if (Prefs.check(this, p)) { unlock(); return; }
        et.setText("");
        msg.setText(L.t("pin_wrong"));
        TranslateAnimation a = new TranslateAnimation(0, dp(14), 0, 0);
        a.setDuration(300);
        a.setInterpolator(new CycleInterpolator(3));
        et.startAnimation(a);
    }

    private void cancelKb() {
        if (fromService || preview) finish(); else showScreen();
    }

    // ---- LockScreen.Host (modo reserva / prévia) ----
    @Override public void unlock() {
        unlocked = true;
        if (!preview) startService(new Intent(this, LockService.class).setAction(LockService.ACT_UNLOCK));
        finish();
    }

    @Override public void launch(int slot) {
        if (preview) return;
        String pkg = Prefs.shortcut(this, slot);
        if (pkg == null) return;
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) return;
        startService(new Intent(this, LockService.class).setAction(LockService.ACT_ALLOW).putExtra("pkg", pkg));
        startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    @Override public void keyboardPin() { showKb(); }

    @Override public void unlockAndLaunch(int slot) {
        String pkg = Prefs.shortcut(this, slot);
        Intent li = (preview || pkg == null) ? null : getPackageManager().getLaunchIntentForPackage(pkg);
        unlock();
        if (li != null) { try { startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) { } }
    }

    @Override protected void onResume() {
        super.onResume();
        if (!preview && !Prefs.locked(this)) { finish(); return; }
        if (secondary) LockService.onSecondaryReady(); // camada pronta: o serviço pode tirar a principal e abrir o app
        if (kbMode) { msg.setTextColor(Look.accent(this)); }
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        secondary = i.getBooleanExtra("secondary", false);
        if (secondary) { sec = this; showScreen(); LockService.onSecondaryReady(); }
    }

    @Override protected void onDestroy() {
        if (sec == this) sec = null;
        super.onDestroy();
    }

    @Override protected void onStop() {
        super.onStop();
        // saiu da página do PIN sem digitar: a camada de bloqueio volta
        if (fromService && !unlocked && !preview) startService(new Intent(this, LockService.class).setAction(LockService.ACT_SHOW));
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f && !kbMode) screen.hideBars();
    }

    @Override public void onBackPressed() {
        if (kbMode) cancelKb(); else if (preview) finish();
    }
}
