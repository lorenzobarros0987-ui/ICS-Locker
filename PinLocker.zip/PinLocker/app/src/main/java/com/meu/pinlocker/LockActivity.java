package com.meu.pinlocker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextClock;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Usada para: prévia da tela, página de PIN com o teclado do celular e, se faltar a permissão de sobrepor,
 * como tela de bloqueio de reserva. A tela de bloqueio de verdade é a janela do LockService.
 */
public class LockActivity extends Activity implements LockScreen.Host {
    private boolean preview, kbMode, fromService, unlocked, secondary;
    private static LockActivity sec; // camada secundária (atrás do app de atalho)

    /** Tira a camada secundária (chamado pelo LockService depois que a principal voltou). */
    static void closeSecondary() { if (sec != null) { sec.finish(); sec = null; } }
    private LockScreen screen;
    private LinearLayout kbRoot;
    private EditText et;
    private TextView msg, sub, info, tries;
    private int kbSlot = -1, wrong;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        L.init(this);
        preview = getIntent().getBooleanExtra("preview", false);
        fromService = getIntent().getBooleanExtra("kb", false);
        secondary = getIntent().getBooleanExtra("secondary", false);
        kbSlot = getIntent().getIntExtra("slot", -1);
        if (secondary) sec = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        if (Look.isLive(this)) { // papel de parede ao vivo atrás da tela
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
            getWindow().setFormat(PixelFormat.TRANSLUCENT);
            getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams wa = getWindow().getAttributes();
            wa.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(wa);
        }
        screen = new LockScreen(this, this);
        buildKb();
        if (fromService) showKb(); else showScreen();
    }

    private void showScreen() {
        kbMode = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        if (kbRoot.getParent() != null) ((android.view.ViewGroup) kbRoot.getParent()).removeView(kbRoot);
        setContentView(screen);
        screen.refresh();
    }

    private TextView tv(String t, int sp, int color, int gravity) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setGravity(gravity);
        v.setTypeface(Fonts.date(this)); // fonte leve, parecida com a do relógio Holo
        return v;
    }

    private void buildKb() {
        int acc = Look.accent(this);
        int sbh = statusBarH();
        kbRoot = new LinearLayout(this);
        kbRoot.setOrientation(LinearLayout.VERTICAL);
        kbRoot.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, Look.BG[0]));

        // barra superior Holo: cadeado + título + hora, com fio na cor de destaque
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFF0D0D0D);
        bar.setPadding(dp(14), sbh, dp(16), 0);
        ImageView ic = new ImageView(this);
        ic.setImageResource(android.R.drawable.ic_lock_lock);
        ic.setColorFilter(acc);
        bar.addView(ic, new LinearLayout.LayoutParams(dp(26), dp(26)));
        TextView title = tv("PIN Locker", 22, Color.WHITE, Gravity.LEFT);
        title.setPadding(dp(10), 0, 0, 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextClock clk = new TextClock(this);
        clk.setTextSize(16);
        clk.setTextColor(0xFFB0B0B0);
        clk.setTypeface(Fonts.date(this));
        bar.addView(clk);
        kbRoot.addView(bar, new LinearLayout.LayoutParams(-1, dp(52) + sbh));
        View line = new View(this);
        line.setBackgroundColor(acc);
        kbRoot.addView(line, new LinearLayout.LayoutParams(-1, dp(2)));

        // corpo
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER);
        body.setPadding(dp(24), dp(16), dp(24), dp(16));
        msg = tv("", 28, acc, Gravity.CENTER);
        body.addView(msg);
        sub = tv("", 15, 0xFFB0B0B0, Gravity.CENTER);
        sub.setPadding(0, dp(4), 0, dp(20));
        body.addView(sub);
        et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        et.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        et.setGravity(Gravity.CENTER);
        et.setTextSize(32);
        et.setTypeface(Fonts.date(this));
        et.setTextColor(Color.WHITE);
        et.setImeOptions(EditorInfo.IME_ACTION_DONE);
        et.setOnEditorActionListener((v, a, e) -> { submit(); return true; });
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { if (s.length() >= Prefs.pinLen(LockActivity.this)) submit(); }
        });
        body.addView(et, new LinearLayout.LayoutParams(dp(260), -2));
        tries = tv("", 13, 0xFFFF4444, Gravity.CENTER);
        tries.setPadding(0, dp(6), 0, 0);
        body.addView(tries);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp(14), 0, 0);
        Button cancel = new Button(this, null, android.R.attr.borderlessButtonStyle), ok = new Button(this, null, android.R.attr.borderlessButtonStyle);
        cancel.setText(L.t("cancel"));
        cancel.setTextColor(0xFFCCCCCC);
        cancel.setOnClickListener(v -> cancelKb());
        ok.setText(L.t("ok"));
        ok.setTextColor(acc);
        ok.setOnClickListener(v -> submit());
        row.addView(cancel, new LinearLayout.LayoutParams(dp(120), -2));
        row.addView(ok, new LinearLayout.LayoutParams(dp(120), -2));
        body.addView(row);
        kbRoot.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));

        // rodapé com a explicação
        View div = new View(this);
        div.setBackgroundColor(0x33FFFFFF);
        kbRoot.addView(div, new LinearLayout.LayoutParams(-1, dp(1)));
        info = tv("", 13, 0xFF9A9A9A, Gravity.CENTER);
        info.setPadding(dp(24), dp(12), dp(24), dp(14));
        kbRoot.addView(info);
    }

    private int statusBarH() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    /** Modo foco: esconde barra de status e de navegação também na página do PIN. */
    private void focusMode() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try {
                android.view.WindowInsetsController wc = getWindow().getInsetsController();
                if (wc != null) {
                    wc.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    wc.hide(android.view.WindowInsets.Type.systemBars());
                }
            } catch (Throwable ignored) { }
        }
    }

    private String appName(int slot) {
        String pkg = Prefs.shortcut(this, slot);
        if (pkg == null) return null;
        try { return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return null; }
    }

    private void showKb() {
        kbMode = true;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_SECURE); // modo foco: sem barras, sem print/miniatura
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        msg.setTextColor(Look.accent(this));
        msg.setText(L.t("kb_title"));
        String app = kbSlot >= 0 ? appName(kbSlot) : null;
        sub.setText(app != null ? String.format(L.t("kb_for_app"), app) : L.t("kb_unlock_phone"));
        info.setText(String.format(L.t("kb_help"), Prefs.pinLen(this)));
        tries.setText(wrong > 0 ? String.format(L.t("kb_tries"), wrong) : "");
        et.setText("");
        if (screen.getParent() != null) ((android.view.ViewGroup) screen.getParent()).removeView(screen);
        setContentView(kbRoot);
        focusMode();
        getWindow().getDecorView().setOnSystemUiVisibilityChangeListener(v -> { if (kbMode) focusMode(); });
        et.requestFocus();
        et.postDelayed(() -> {
            InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (m != null) m.showSoftInput(et, InputMethodManager.SHOW_FORCED);
        }, 200);
    }

    private void submit() {
        String p = et.getText().toString();
        if (p.isEmpty()) return;
        if (Prefs.check(this, p)) { if (kbSlot >= 0) unlockAndLaunch(kbSlot); else unlock(); return; }
        et.setText("");
        wrong++;
        msg.setTextColor(0xFFFF4444);
        msg.setText(L.t("pin_wrong"));
        tries.setText(String.format(L.t("kb_tries"), wrong));
        TranslateAnimation a = new TranslateAnimation(0, dp(14), 0, 0);
        a.setDuration(300);
        a.setInterpolator(new CycleInterpolator(3));
        et.startAnimation(a);
    }

    private void cancelKb() {
        if (preview) finish();
        else if (fromService) {
            // a tela de bloqueio volta PRIMEIRO; o serviço fecha esta camada depois (sem piscar o menu do celular)
            startService(new Intent(this, LockService.class).setAction(LockService.ACT_SHOW));
            if (!secondary) finish();
        } else showScreen();
    }

    // ---- LockScreen.Host (modo reserva / prévia) ----
    @Override public void unlock() {
        unlocked = true;
        if (!preview) startService(new Intent(this, LockService.class).setAction(LockService.ACT_UNLOCK));
        finish();
    }

    @Override public void launch(int slot) {
        if (preview) return;
        String pkg = Prefs.shortcut(this, slot);
        if (pkg == null) return;
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) return;
        startService(new Intent(this, LockService.class).setAction(LockService.ACT_ALLOW).putExtra("pkg", pkg));
        startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    @Override public void keyboardPin(int slot) { kbSlot = slot; showKb(); }

    @Override public void unlockAndLaunch(int slot) {
        String pkg = Prefs.shortcut(this, slot);
        Intent li = (preview || pkg == null) ? null : getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) { unlock(); return; }
        unlocked = true; // o app abre por baixo e só então esta tela sai (sem piscar o menu)
        try { startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) { }
        getWindow().getDecorView().postDelayed(this::unlock, 300);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!preview && !Prefs.locked(this)) { finish(); return; }
        if (secondary) LockService.onSecondaryReady(); // camada pronta: o serviço pode tirar a principal e abrir o app
        if (kbMode) { msg.setTextColor(Look.accent(this)); }
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        if (i.getBooleanExtra("kb", false)) { // a camada secundária vira a página do PIN
            fromService = true;
            kbSlot = i.getIntExtra("slot", -1);
            showKb();
            return;
        }
        secondary = i.getBooleanExtra("secondary", false);
        if (secondary) { sec = this; showScreen(); LockService.onSecondaryReady(); }
    }

    @Override protected void onDestroy() {
        if (sec == this) sec = null;
        super.onDestroy();
    }

    @Override protected void onStop() {
        super.onStop();
        // saiu da página do PIN sem digitar: a camada de bloqueio volta
        if (fromService && !unlocked && !preview) startService(new Intent(this, LockService.class).setAction(LockService.ACT_SHOW));
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) { if (kbMode) focusMode(); else screen.hideBars(); }
    }

    @Override public void onBackPressed() {
        if (kbMode) cancelKb(); else if (preview) finish();
    }
}
