package com.meu.pinlocker;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.UserManager;
import java.util.Map;

/**
 * Onde ficam as configurações, o PIN e o padrão. Ficam no armazenamento "protegido do dispositivo", que já está
 * disponível logo que o aparelho liga, antes de o armazenamento do usuário ser liberado. Assim o PIN e o padrão salvos
 * continuam valendo mesmo nesse momento (antes, a leitura falhava e qualquer PIN passava).
 */
final class Store {
    private static boolean copied;

    private Store() { }

    static SharedPreferences sp(Context c) {
        Context app = c.getApplicationContext() != null ? c.getApplicationContext() : c;
        if (Build.VERSION.SDK_INT < 24) return app.getSharedPreferences("pl", Context.MODE_PRIVATE);
        Context d = app.createDeviceProtectedStorageContext();
        SharedPreferences de = d.getSharedPreferences("pl", Context.MODE_PRIVATE);
        if (!copied && unlocked(app)) {
            copied = true;
            if (!de.getBoolean("dp", false)) { // primeira vez depois da atualização: traz tudo do armazenamento antigo
                try {
                    SharedPreferences ce = app.getSharedPreferences("pl", Context.MODE_PRIVATE);
                    SharedPreferences.Editor e = de.edit();
                    for (Map.Entry<String, ?> en : ce.getAll().entrySet()) {
                        Object v = en.getValue();
                        String k = en.getKey();
                        if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
                        else if (v instanceof Integer) e.putInt(k, (Integer) v);
                        else if (v instanceof Long) e.putLong(k, (Long) v);
                        else if (v instanceof Float) e.putFloat(k, (Float) v);
                        else if (v instanceof String) e.putString(k, (String) v);
                    }
                    e.putBoolean("dp", true).commit();
                } catch (Exception ignored) { copied = false; }
            }
        }
        return de;
    }

    static boolean unlocked(Context c) {
        if (Build.VERSION.SDK_INT < 24) return true;
        UserManager um = (UserManager) c.getSystemService(Context.USER_SERVICE);
        return um == null || um.isUserUnlocked();
    }

    /** Armazenamento ainda trancado e sem cópia segura dos dados: não dá para conferir PIN/padrão, então nada desbloqueia. */
    static boolean sealed(Context c) {
        if (Build.VERSION.SDK_INT < 24) return false;
        return !unlocked(c) && !sp(c).getBoolean("dp", false);
    }
}
