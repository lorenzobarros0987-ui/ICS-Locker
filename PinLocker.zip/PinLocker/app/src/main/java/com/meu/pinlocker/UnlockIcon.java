package com.meu.pinlocker;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/**
 * Cadeado liberado do Android 4.0 em vetor (HD). Normal = cadeado branco; ativo = disco branco com o cadeado vazado.
 * Grade do cadeado: x 5.5..30.5 (25), y 5.3..36 (30.7).
 */
class UnlockIcon extends Drawable {
    private static final float GW = 25f, GH = 30.7f, GCX = 18f, GCY = 20.65f;
    private final boolean active;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), stroke = new Paint(Paint.ANTI_ALIAS_FLAG), disc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cutFill = new Paint(Paint.ANTI_ALIAS_FLAG), cutStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path body = new Path(), shackle = new Path();

    UnlockIcon(boolean active) {
        this.active = active;
        fill.setColor(0xFFFFFFFF); fill.setStyle(Paint.Style.FILL);
        stroke.setColor(0xFFFFFFFF); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(3.6f); stroke.setStrokeCap(Paint.Cap.BUTT); stroke.setStrokeJoin(Paint.Join.ROUND);
        disc.setColor(0xFFFFFFFF); disc.setStyle(Paint.Style.FILL);
        PorterDuffXfermode clear = new PorterDuffXfermode(PorterDuff.Mode.CLEAR);
        cutFill.setStyle(Paint.Style.FILL); cutFill.setXfermode(clear);
        cutStroke.setStyle(Paint.Style.STROKE); cutStroke.setStrokeWidth(3.6f); cutStroke.setStrokeCap(Paint.Cap.BUTT); cutStroke.setStrokeJoin(Paint.Join.ROUND); cutStroke.setXfermode(clear);

        body.setFillType(Path.FillType.EVEN_ODD);
        body.addRoundRect(new RectF(5.5f, 19.5f, 30.5f, 36f), 1.3f, 1.3f, Path.Direction.CW);
        body.addCircle(18f, 26f, 2.4f, Path.Direction.CW);                                   // furo da chave
        body.addRect(new RectF(16.75f, 27f, 19.25f, 33.6f), Path.Direction.CW);              // fenda da chave
        shackle.moveTo(11.2f, 19.8f);
        shackle.lineTo(11.2f, 13.8f);
        shackle.arcTo(new RectF(11.2f, 7.1f, 24.6f, 20.5f), 180f, 180f);                     // arco aberto
        shackle.lineTo(24.6f, 14.6f);                                                         // perna direita curta
    }

    private void glyph(Canvas c, Paint f, Paint s) { c.drawPath(body, f); c.drawPath(shackle, s); }

    @Override public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        if (!active) {
            float k = Math.min(b.width() / GW, b.height() / GH);
            c.save();
            c.translate(b.exactCenterX(), b.exactCenterY());
            c.scale(k, k);
            c.translate(-GCX, -GCY);
            glyph(c, fill, stroke);
            c.restore();
        } else {
            float d = Math.min(b.width(), b.height());
            int layer = c.saveLayer(new RectF(b), null);
            c.drawCircle(b.exactCenterX(), b.exactCenterY(), d / 2f, disc);
            float k = (0.6f * d) / GH; // cadeado ocupa 60% do disco
            c.save();
            c.translate(b.exactCenterX(), b.exactCenterY());
            c.scale(k, k);
            c.translate(-GCX, -GCY);
            glyph(c, cutFill, cutStroke);
            c.restore();
            c.restoreToCount(layer);
        }
    }

    @Override public int getIntrinsicWidth() { return active ? 120 : 100; }
    @Override public int getIntrinsicHeight() { return active ? 120 : 123; }
    @Override public void setAlpha(int a) { fill.setAlpha(a); stroke.setAlpha(a); disc.setAlpha(a); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter f) { fill.setColorFilter(f); stroke.setColorFilter(f); disc.setColorFilter(f); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
