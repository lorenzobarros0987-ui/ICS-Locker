package com.meu.pinlocker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

/** Tela de bloqueio com os visuais do Holo Locker (anel + alvos), efeitos e lógica própria. */
public class LockView extends View {
    interface Listener { void onUnlock(); void onShortcut(int slot); }

    private static final int TRAIL = 14, DOTS = 9;

    private final Drawable handleN, handleP, unlockN, unlockA, disc, chev, dotD;
    private final PointF tmp = new PointF();
    private float[] px = new float[400], py = new float[400], pr = new float[400];
    private int pn;
    private float cloudInner, cloudOuter, dotBase;
    private boolean ext; // visual estendido (efeitos extras); falso = visual original do Holo Locker
    /** Pontos em anéis concêntricos (mesmo algoritmo do PointCloud do GlowPad). */
    private void buildCloud() {
        cloudInner = r * 0.22f; cloudOuter = r * 1.25f; dotBase = dotD.getIntrinsicWidth() * 1.1f;
        float ds = (float) (2 * Math.PI * cloudInner / 8f);
        int bands = Math.max(1, Math.round((cloudOuter - cloudInner) / ds));
        float dr = (cloudOuter - cloudInner) / bands, rad = cloudInner;
        for (int b = 0; b <= bands; b++, rad += dr) {
            int n = Math.max(1, (int) (2 * Math.PI * rad / ds));
            double eta = Math.PI / 2, de = 2 * Math.PI / n;
            for (int i = 0; i < n && pn < 400; i++, eta += de) { px[pn] = (float) (rad * Math.cos(eta)); py[pn] = (float) (rad * Math.sin(eta)); pr[pn] = rad; pn++; }
        }
    }

    void setExtended(boolean e) { ext = e; invalidate(); }
    private final PointF[] t = {new PointF(), new PointF(), new PointF()}; // 0 atalho esq, 1 desbloquear, 2 atalho dir
    private final PointF handle = new PointF(), cur = new PointF();
    private final float[] trX = new float[TRAIL], trY = new float[TRAIL];
    private final long[] trT = new long[TRAIL];
    private int trN;
    private final Drawable[] icons = new Drawable[2];
    private final Listener l;
    private final float r, dens;
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float reach;
    private boolean drag;
    private int near = -1;
    private long dragStart, nearSince;
    private int accent = 0xFFFFFFFF;

    LockView(Context c, Listener l) {
        super(c);
        this.l = l;
        dens = c.getResources().getDisplayMetrics().density;
        handleN = c.getDrawable(R.drawable.ic_lockscreen_handle_normal).mutate();
        handleP = c.getDrawable(R.drawable.ic_lockscreen_handle_pressed).mutate();
        unlockN = c.getDrawable(R.drawable.ic_lockscreen_unlock_normal).mutate();
        unlockA = c.getDrawable(R.drawable.ic_lockscreen_unlock_activated).mutate();
        disc = c.getDrawable(R.drawable.ic_lockscreen_triggered).mutate();
        chev = c.getDrawable(R.drawable.ic_lockscreen_chevron_right).mutate();
        dotD = c.getDrawable(R.drawable.ic_lockscreen_glowdot).mutate();
        r = handleN.getIntrinsicWidth() / 2f;
        buildCloud();
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(2f * dens);
        fill.setStyle(Paint.Style.FILL);
    }

    void setTint(int color) {
        accent = color == 0 ? 0xFFFFFFFF : color;
        for (Drawable d : new Drawable[]{handleN, handleP, unlockN, unlockA, disc, chev, dotD}) {
            if (color == 0) d.clearColorFilter(); else d.setColorFilter(color, android.graphics.PorterDuff.Mode.MULTIPLY);
        }
        invalidate();
    }

    void setIcons(Drawable left, Drawable right) { icons[0] = left; icons[1] = right; invalidate(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        float hy = h * 0.78f;
        handle.set(w / 2f, hy);
        reach = Math.min(w * 0.42f, h * 0.4f);
        t[1].set(w / 2f + reach, hy);   // desbloquear: direita
        t[0].set(w / 2f - reach, hy);   // atalho 1: esquerda
        t[2].set(w / 2f, hy - reach);   // atalho 2: em cima
    }

    /** Guarda em cur a posição do dedo, limitada ao raio do círculo externo (reach) ao redor do anel. */
    private void clampTo(float x, float y) {
        float dx = x - handle.x, dy = y - handle.y, d = (float) Math.hypot(dx, dy);
        if (d > reach) { dx *= reach / d; dy *= reach / d; }
        cur.set(handle.x + dx, handle.y + dy);
    }

    private static float dist(float x, float y, PointF p) { return (float) Math.hypot(x - p.x, y - p.y); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                // pode começar a arrastar pelo anel ou por qualquer ponto da faixa de baixo
                if (dist(x, y, handle) < r * 2f) { // como no original: só começa tocando no anel
                    drag = true; clampTo(x, y); trN = 0; dragStart = SystemClock.uptimeMillis();
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
                    invalidate(); return true;
                }
                return false;
            case MotionEvent.ACTION_MOVE:
                if (!drag) return false;
                clampTo(x, y); // como no GlowPad original: o anel não sai do círculo externo
                addTrail(cur.x, cur.y);
                int n = -1;
                // como no GlowPad: passou da margem do círculo na direção de um alvo -> o anel fica SELECIONADO nele
                if (dist(x, y, handle) > reach - 20f * dens) {
                    float fa = (float) Math.atan2(y - handle.y, x - handle.x), best = (float) Math.toRadians(40);
                    for (int i = 0; i < 3; i++) {
                        if (i != 1 && icons[i == 0 ? 0 : 1] == null) continue; // slot sem atalho não é alvo
                        float df = Math.abs(fa - (float) Math.atan2(t[i].y - handle.y, t[i].x - handle.x));
                        if (df > Math.PI) df = (float) (2 * Math.PI - df);
                        if (df < best) { best = df; n = i; }
                    }
                }
                if (n != near) {
                    near = n; nearSince = SystemClock.uptimeMillis();
                    if (n >= 0) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!drag) return false;
                int hit = near;
                drag = false;
                near = -1;
                invalidate();
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    if (hit == 1) l.onUnlock();
                    else if (hit == 0) l.onShortcut(0);
                    else if (hit == 2) l.onShortcut(1);
                }
                return true;
        }
        return true;
    }

    private void addTrail(float x, float y) {
        if (trN == TRAIL) { System.arraycopy(trX, 1, trX, 0, TRAIL - 1); System.arraycopy(trY, 1, trY, 0, TRAIL - 1); System.arraycopy(trT, 1, trT, 0, TRAIL - 1); trN--; }
        trX[trN] = x; trY[trN] = y; trT[trN] = SystemClock.uptimeMillis(); trN++;
    }

    private static void draw(Canvas c, Drawable d, PointF p, float size, int alpha) {
        float w = size > 0 ? size : d.getIntrinsicWidth(), h = size > 0 ? size : d.getIntrinsicHeight();
        float iw = d.getIntrinsicWidth(), ih = d.getIntrinsicHeight();
        if (size > 0 && iw > 0 && ih > 0) { if (iw >= ih) h = size * ih / iw; else w = size * iw / ih; } // mantém a proporção (fotos não quadradas)
        d.setBounds((int) (p.x - w / 2), (int) (p.y - h / 2), (int) (p.x + w / 2), (int) (p.y + h / 2));
        d.setAlpha(alpha);
        d.draw(c);
        d.setAlpha(255);
    }

    private void circle(Canvas c, float x, float y, float rad, int color, int alpha, boolean stroke) {
        Paint p = stroke ? ring : fill;
        p.setColor(color);
        p.setAlpha(Math.max(0, Math.min(255, alpha)));
        c.drawCircle(x, y, rad, p);
    }

    @Override protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        float appear = drag ? Math.min(1f, (now - dragStart) / 220f) : 0f; // alvos "acendem" ao tocar

        // ondas saindo do anel (efeito de repouso, como no original)
        float ph = (now % 2400) / 2400f;
        if (!drag) {
            circle(c, handle.x, handle.y, r * (0.9f + ph * 1.3f), accent, (int) (110 * (1f - ph)), true);
            float ph2 = ((now + 1200) % 2400) / 2400f;
            circle(c, handle.x, handle.y, r * (0.9f + ph2 * 1.3f), accent, (int) (70 * (1f - ph2)), true);
        } else if (ext) {
            // ao arrastar: ondas expandem do ponto de partida até os alvos
            float w = ((now - dragStart) % 900) / 900f;
            circle(c, handle.x, handle.y, r + (reach - r) * w, accent, (int) (90 * (1f - w)), true);
        }

        // anel externo do GlowPad: fraco em repouso, mais forte ao arrastar
        circle(c, handle.x, handle.y, reach, 0xFFFFFFFF, ext ? (int) (28 + 40 * appear) : (int) (110 * appear), true);

        // nuvem de pontos em volta do toque (PointCloud do GlowPad): mais densa no centro, com onda que se expande
        if (appear > 0f) {
            float span = cloudOuter - cloudInner;
            float waveR = cloudInner + span * (((now - dragStart) % 1100) / 1100f);
            for (int k = 0; k < pn; k++) {
                float f = (pr[k] - cloudInner) / span;
                float wv = Math.max(0f, 1f - Math.abs(pr[k] - waveR) / (0.3f * cloudOuter));
                float al = Math.min(1f, (1f - 0.8f * f) * 0.6f + wv * 0.5f) * appear;
                tmp.set(handle.x + px[k], handle.y + py[k]);
                draw(c, dotD, tmp, dotBase * (1f - 0.45f * f + 0.35f * wv), (int) (255 * al));
            }
        }

        // chevrons em onda, do anel em direção a cada alvo (só em repouso)
        if (ext && !drag) {
            float phase = (now % 1600) / 1600f;
            for (int k = 0; k < 3; k++) {
                float ang = (float) Math.atan2(t[k].y - handle.y, t[k].x - handle.x);
                for (int j = 0; j < 3; j++) {
                    float d = r * (1.5f + j * 0.55f);
                    if (d > reach - r * 0.9f) continue;
                    float lp = (phase - j * 0.15f + 1f) % 1f;
                    int al = (int) (190 * Math.sin(Math.PI * lp));
                    int cw = chev.getIntrinsicWidth(), ch = chev.getIntrinsicHeight();
                    c.save();
                    c.translate(handle.x + (float) Math.cos(ang) * d, handle.y + (float) Math.sin(ang) * d);
                    c.rotate((float) Math.toDegrees(ang));
                    chev.setBounds(-cw / 2, -ch / 2, cw / 2, ch / 2);
                    chev.setAlpha(Math.max(0, al));
                    chev.draw(c);
                    c.restore();
                    chev.setAlpha(255);
                }
            }
        }

        // alvos: círculo contornado sempre visível; cresce quando o dedo se aproxima
        for (int i = 0; i < 3; i++) {
            PointF p = t[i];
            float prox = 0f;
            if (drag) prox = Math.max(0f, 1f - dist(cur.x, cur.y, p) / (reach * 0.7f));
            float sc = ext ? 1f + 0.3f * prox + (near == i ? 0.1f : 0f) : 1f;
            int ta = ext ? 255 : (int) (255 * appear); // original: alvos só aparecem ao tocar no anel
            int base = (int) (150 + 80 * appear);
            if (ext) {
                circle(c, p.x, p.y, r * 0.8f * sc, 0xFFFFFFFF, base - 40 + (int) (40 * prox), true);
                circle(c, p.x, p.y, r * 0.8f * sc, 0xFFFFFFFF, 18 + (int) (30 * prox), false);
            }
            if (near == i) {
                draw(c, disc, p, r * 1.9f, 255);
                if (ext) {
                    float pw = ((now - nearSince) % 700) / 700f;
                    circle(c, p.x, p.y, r * (1f + pw * 0.9f), accent, (int) (140 * (1f - pw)), true);
                }
            }
            if (i == 1) {
                if (near == 1) draw(c, unlockA, p, r * 1.4f * sc, ta); else draw(c, unlockN, p, r * 1.4f * sc, ta);
            } else if (icons[i == 0 ? 0 : 1] != null) {
                draw(c, icons[i == 0 ? 0 : 1], p, r * 0.95f * sc, ta);
            }
        }

        // rastro atrás do dedo
        if (ext && drag) {
            for (int i = 0; i < trN; i++) {
                float age = Math.min(1f, (now - trT[i]) / 380f);
                circle(c, trX[i], trY[i], r * 0.35f * (1f - age * 0.6f), accent, (int) (120 * (1f - age)), false);
            }
        }

        // anel (handle): no dedo; ao encostar num alvo, gruda nele
        if (drag) {
            PointF at = near >= 0 ? t[near] : cur;
            draw(c, handleP, at, 0, 255);
        } else {
            draw(c, handleN, handle, 0, 255);
        }
        postInvalidateOnAnimation();
    }
}
