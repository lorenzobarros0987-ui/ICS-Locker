package com.meu.pinlocker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;

/** Tela de bloqueio com os visuais originais do Holo Locker (anel + alvos), lógica própria. */
public class LockView extends View {
    interface Listener { void onUnlock(); void onShortcut(int slot); }

    private final Drawable handleN, handleP, unlockN, unlockA, disc;
    private final PointF[] t = {new PointF(), new PointF(), new PointF()}; // 0 atalho esq, 1 desbloquear, 2 atalho dir
    private final PointF handle = new PointF(), cur = new PointF();
    private final Drawable[] icons = new Drawable[2];
    private final Listener l;
    private final float r;
    private boolean drag;
    private int near = -1;

    LockView(Context c, Listener l) {
        super(c);
        this.l = l;
        handleN = c.getDrawable(R.drawable.ic_lockscreen_handle_normal);
        handleP = c.getDrawable(R.drawable.ic_lockscreen_handle_pressed);
        unlockN = c.getDrawable(R.drawable.ic_lockscreen_unlock_normal);
        unlockA = c.getDrawable(R.drawable.ic_lockscreen_unlock_activated);
        disc = c.getDrawable(R.drawable.ic_lockscreen_triggered);
        r = handleN.getIntrinsicWidth() / 2f;
    }

    void setTint(int color) {
        for (Drawable d : new Drawable[]{handleN, handleP, unlockN, unlockA, disc}) {
            if (color == 0) d.clearColorFilter(); else d.setColorFilter(color, android.graphics.PorterDuff.Mode.MULTIPLY);
        }
        invalidate();
    }

    void setIcons(Drawable left, Drawable right) { icons[0] = left; icons[1] = right; invalidate(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        handle.set(w / 2f, h * 0.84f);
        t[0].set(w * 0.2f, h * 0.55f);
        t[1].set(w / 2f, h * 0.42f);
        t[2].set(w * 0.8f, h * 0.55f);
    }

    private static float dist(float x, float y, PointF p) { return (float) Math.hypot(x - p.x, y - p.y); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (dist(x, y, handle) < r * 1.3f) { drag = true; cur.set(x, y); invalidate(); return true; }
                return false;
            case MotionEvent.ACTION_MOVE:
                if (!drag) return false;
                cur.set(x, y);
                near = -1;
                for (int i = 0; i < 3; i++) if (dist(x, y, t[i]) < r * 1.1f) near = i;
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!drag) return false;
                int n = near;
                drag = false;
                near = -1;
                invalidate();
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    if (n == 1) l.onUnlock();
                    else if (n == 0) l.onShortcut(0);
                    else if (n == 2) l.onShortcut(1);
                }
                return true;
        }
        return true;
    }

    private static void draw(Canvas c, Drawable d, PointF p, float size) {
        float w = size > 0 ? size : d.getIntrinsicWidth(), h = size > 0 ? size : d.getIntrinsicHeight();
        d.setBounds((int) (p.x - w / 2), (int) (p.y - h / 2), (int) (p.x + w / 2), (int) (p.y + h / 2));
        d.draw(c);
    }

    @Override protected void onDraw(Canvas c) {
        // alvo de desbloquear
        if (near == 1) draw(c, unlockA, t[1], 0); else draw(c, unlockN, t[1], 0);
        // atalhos: ícone do app; ao encostar, disco branco por trás
        for (int s = 0; s < 2; s++) {
            PointF p = t[s == 0 ? 0 : 2];
            Drawable d = icons[s];
            if (near == (s == 0 ? 0 : 2)) draw(c, disc, p, 0);
            if (d != null) draw(c, d, p, r * 0.95f);
        }
        // anel (handle)
        if (drag) draw(c, handleP, cur, 0); else draw(c, handleN, handle, 0);
    }
}
