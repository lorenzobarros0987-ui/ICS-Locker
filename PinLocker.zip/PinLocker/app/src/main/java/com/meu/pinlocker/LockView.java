package com.meu.pinlocker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

/**
 * Tela de bloqueio com os visuais do Holo Locker (anel + alvos), efeitos e lógica própria.
 *
 * Alvos (5), em semicírculo acima do anel:  esquerda = atalho 0, diagonal esq. = atalho 2 (opcional),
 * topo = atalho 1, diagonal dir. = atalho 3 (opcional), direita = desbloquear.
 */
public class LockView extends View {
    interface Listener { void onUnlock(); void onShortcut(int slot); }

    static final int SLOTS = 4;
    private static final int TRAIL = 14, N_T = 5, UNLOCK = 1;
    /** Ângulo de cada alvo em graus (0 = direita, 90 = cima). */
    private static final float[] ANG = {180f, 0f, 90f, 135f, 45f};
    /** Alvo -> atalho (-1 = desbloquear). */
    private static final int[] SLOT_OF = {0, -1, 1, 2, 3};

    private final Drawable handleN, handleP, unlockN, unlockA, disc, chev, dotD;
    private final PointF tmp = new PointF();
    private final PointF[] t = new PointF[N_T];
    private final float[] tAng = new float[N_T];
    private final PointF handle = new PointF(), cur = new PointF();
    private final float[] trX = new float[TRAIL], trY = new float[TRAIL];
    private final long[] trT = new long[TRAIL];
    private int trN;
    private final Drawable[] icons = new Drawable[SLOTS];
    private final Listener l;
    private final float r, dens, dotBase;
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG), fogPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // névoa de bolinhas: cobre o círculo inteiro, mas cada bolinha só acende onde o dedo passa
    private float[] px = new float[0], py = new float[0], gl = new float[0];
    private int pn;
    private long lastFrame;
    private float lastX, lastY;

    private boolean screenOn = true;
    private boolean ext; // ext = estendido (efeitos extras); falso = original do Holo Locker
    // proporções (em múltiplos do raio r): ícone de atalho, altura do cadeado, disco de seleção
    private static final float ICON = 1.55f, LOCK = 1.2f, DISC = 1.9f;
    private float reach;
    private boolean drag;
    private int near = -1;
    private long dragStart, nearSince;
    private int accent = 0xFFFFFFFF;

    LockView(Context c, Listener l) {
        super(c);
        this.l = l;
        dens = c.getResources().getDisplayMetrics().density;
        handleN = c.getDrawable(R.drawable.ic_lockscreen_handle_normal).mutate();
        handleP = c.getDrawable(R.drawable.ic_lockscreen_handle_pressed).mutate();
        unlockN = new UnlockIcon(false); // cadeado liberado em vetor (HD)
        unlockA = new UnlockIcon(true);
        disc = c.getDrawable(R.drawable.ic_lockscreen_triggered).mutate();
        chev = c.getDrawable(R.drawable.ic_lockscreen_chevron_right).mutate();
        dotD = c.getDrawable(R.drawable.ic_lockscreen_glowdot).mutate();
        r = 48f * dens;          // raio do anel (e dos alvos)
        dotBase = 9f * dens;     // tamanho base de cada bolinha da névoa
        for (int i = 0; i < N_T; i++) t[i] = new PointF();
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(2f * dens);
        fill.setStyle(Paint.Style.FILL);
        buildFog();
    }

    void setExtended(boolean e) { ext = e; invalidate(); }

    /** 0 = original (Holo Locker), 1 = estendido. */
    void setStyle(int s) { ext = s == 1; invalidate(); }

    void setTint(int color) {
        accent = color == 0 ? 0xFFFFFFFF : color;
        for (Drawable d : new Drawable[]{handleN, handleP, unlockN, unlockA, disc, chev, dotD}) {
            if (color == 0) d.clearColorFilter(); else d.setColorFilter(color, android.graphics.PorterDuff.Mode.MULTIPLY);
        }
        buildFog();
        invalidate();
    }

    void setIcons(Drawable... d) {
        for (int i = 0; i < SLOTS; i++) icons[i] = i < d.length ? d[i] : null;
        invalidate();
    }

    /** Brilho suave embaixo do dedo (a "névoa"). */
    private void buildFog() {
        float fr = 95f * dens;
        int rgb = accent & 0x00FFFFFF;
        fogPaint.setShader(new RadialGradient(0, 0, fr, new int[]{rgb | 0x66000000, rgb | 0x26000000, rgb},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        // o círculo inteiro (reach) precisa caber na tela e os alvos laterais não podem cortar nas bordas
        reach = Math.max(90f * dens, Math.min(w / 2f - 46f * dens, h * 0.38f));
        float hy = Math.min(h * 0.78f, h - reach - 28f * dens);
        handle.set(w / 2f, hy);
        for (int i = 0; i < N_T; i++) {
            double a = Math.toRadians(ANG[i]);
            t[i].set(handle.x + reach * (float) Math.cos(a), handle.y - reach * (float) Math.sin(a));
            tAng[i] = (float) Math.atan2(t[i].y - handle.y, t[i].x - handle.x);
        }
        buildCloud();
    }

    /** Pontos em anéis concêntricos, do centro até a borda do círculo. */
    private void buildCloud() {
        float ds = 13f * dens;
        float k = reach / ds;
        int cap = (int) (Math.PI * k * k * 1.4) + 64;
        px = new float[cap]; py = new float[cap]; gl = new float[cap];
        pn = 0;
        px[pn] = 0; py[pn] = 0; pn++;
        int ringN = 0;
        for (float rad = ds; rad <= reach; rad += ds, ringN++) {
            int n = Math.max(6, (int) (2 * Math.PI * rad / ds));
            double de = 2 * Math.PI / n, a = ringN * 0.6;
            for (int i = 0; i < n && pn < cap; i++, a += de) {
                px[pn] = (float) (rad * Math.cos(a)); py[pn] = (float) (rad * Math.sin(a)); pn++;
            }
        }
    }

    /** Acende as bolinhas que estão perto do ponto (x, y). */
    private void light(float x, float y) {
        float rr = 50f * dens, r2 = rr * rr;
        for (int k = 0; k < pn; k++) {
            float dx = handle.x + px[k] - x, dy = handle.y + py[k] - y, d2 = dx * dx + dy * dy;
            if (d2 < r2) {
                float v = 1f - (float) Math.sqrt(d2) / rr;
                if (v > gl[k]) gl[k] = v;
            }
        }
    }

    /** Acende ao longo do caminho do dedo (não pula bolinhas quando o dedo é rápido). */
    private void lightSeg(float x0, float y0, float x1, float y1) {
        float len = (float) Math.hypot(x1 - x0, y1 - y0), step = 18f * dens;
        int n = Math.max(1, (int) (len / step));
        for (int i = 1; i <= n; i++) { float f = i / (float) n; light(x0 + (x1 - x0) * f, y0 + (y1 - y0) * f); }
    }

    private boolean has(int i) { return i == UNLOCK || icons[SLOT_OF[i]] != null; }

    /** Guarda em cur a posição do dedo, limitada ao raio do círculo externo (reach) ao redor do anel. */
    private void clampTo(float x, float y) {
        float dx = x - handle.x, dy = y - handle.y, d = (float) Math.hypot(dx, dy);
        if (d > reach) { dx *= reach / d; dy *= reach / d; }
        cur.set(handle.x + dx, handle.y + dy);
    }

    private static float dist(float x, float y, PointF p) { return (float) Math.hypot(x - p.x, y - p.y); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (dist(x, y, handle) < r * 2f) { // como no original: só começa tocando no anel
                    drag = true; clampTo(x, y); trN = 0; dragStart = SystemClock.uptimeMillis();
                    lastX = cur.x; lastY = cur.y;
                    light(cur.x, cur.y);
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
                    invalidate(); return true;
                }
                return false;
            case MotionEvent.ACTION_MOVE:
                if (!drag) return false;
                clampTo(x, y);
                lightSeg(lastX, lastY, cur.x, cur.y);
                lastX = cur.x; lastY = cur.y;
                addTrail(cur.x, cur.y);
                int n = -1;
                // chegou perto do fim do círculo: seleciona NA HORA o alvo mais próximo (cadeado incluído).
                // Só seleciona; o atalho é ativado ao soltar o dedo.
                if (dist(x, y, handle) > reach - 36f * dens) {
                    float bd = Float.MAX_VALUE;
                    for (int i = 0; i < N_T; i++) {
                        if (!has(i)) continue;
                        float dd = dist(cur.x, cur.y, t[i]);
                        if (dd < bd) { bd = dd; n = i; }
                    }
                }
                if (n != near) {
                    near = n; nearSince = SystemClock.uptimeMillis();
                    if (n >= 0) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING);
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!drag) return false;
                int hit = near;
                drag = false;
                near = -1;
                invalidate();
                if (e.getActionMasked() == MotionEvent.ACTION_UP && hit >= 0) {
                    if (hit == UNLOCK) l.onUnlock(); else l.onShortcut(SLOT_OF[hit]);
                }
                return true;
        }
        return true;
    }

    private void addTrail(float x, float y) {
        if (trN == TRAIL) { System.arraycopy(trX, 1, trX, 0, TRAIL - 1); System.arraycopy(trY, 1, trY, 0, TRAIL - 1); System.arraycopy(trT, 1, trT, 0, TRAIL - 1); trN--; }
        trX[trN] = x; trY[trN] = y; trT[trN] = SystemClock.uptimeMillis(); trN++;
    }

    private static void draw(Canvas c, Drawable d, PointF p, float size, int alpha) {
        float w = size > 0 ? size : d.getIntrinsicWidth(), h = size > 0 ? size : d.getIntrinsicHeight();
        float iw = d.getIntrinsicWidth(), ih = d.getIntrinsicHeight();
        if (size > 0 && iw > 0 && ih > 0) { if (iw >= ih) h = size * ih / iw; else w = size * iw / ih; } // mantém a proporção (fotos não quadradas)
        d.setBounds((int) (p.x - w / 2), (int) (p.y - h / 2), (int) (p.x + w / 2), (int) (p.y + h / 2));
        d.setAlpha(Math.max(0, Math.min(255, alpha)));
        d.draw(c);
        d.setAlpha(255);
    }

    private void circle(Canvas c, float x, float y, float rad, int color, int alpha, boolean stroke) {
        Paint p = stroke ? ring : fill;
        p.setColor(color);
        p.setAlpha(Math.max(0, Math.min(255, alpha)));
        c.drawCircle(x, y, rad, p);
    }

    @Override protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0 ? 16f : Math.min(48f, now - lastFrame);
        lastFrame = now;
        float appear = drag ? Math.min(1f, (now - dragStart) / 220f) : 0f; // alvos "acendem" ao tocar

        // ondas saindo do anel (efeito de repouso, como no original)
        float ph = (now % 2400) / 2400f;
        if (!drag) {
            circle(c, handle.x, handle.y, r * (0.9f + ph * 1.3f), accent, (int) (110 * (1f - ph)), true);
            float ph2 = ((now + 1200) % 2400) / 2400f;
            circle(c, handle.x, handle.y, r * (0.9f + ph2 * 1.3f), accent, (int) (70 * (1f - ph2)), true);
        } else if (ext) {
            // ao arrastar: ondas expandem do ponto de partida até os alvos
            float w = ((now - dragStart) % 900) / 900f;
            circle(c, handle.x, handle.y, r + (reach - r) * w, accent, (int) (90 * (1f - w)), true);
        }

        // círculo externo do GlowPad: fraco em repouso, mais forte ao arrastar
        circle(c, handle.x, handle.y, reach, 0xFFFFFFFF, ext ? (int) (28 + 40 * appear) : (int) (110 * appear), true);

        // névoa: brilho embaixo do dedo + bolinhas que acendem por onde o dedo passa e vão apagando
        if (drag) light(cur.x, cur.y);
        float fade = dt / 850f;
        for (int k = 0; k < pn; k++) if (gl[k] > 0f) gl[k] = Math.max(0f, gl[k] - fade);
        if (drag && appear > 0f) {
            c.save();
            c.translate(cur.x, cur.y);
            fogPaint.setAlpha((int) (255 * appear));
            c.drawCircle(0, 0, 95f * dens, fogPaint);
            c.restore();
        }
        for (int k = 0; k < pn; k++) {
            float g = gl[k];
            if (g <= 0.02f) continue;
            tmp.set(handle.x + px[k], handle.y + py[k]);
            draw(c, dotD, tmp, dotBase * (0.65f + 0.9f * g), (int) (255 * Math.min(1f, g * 1.25f)));
        }

        // chevrons em onda, do anel em direção a cada alvo (só em repouso)
        if (ext && !drag) {
            float phase = (now % 1600) / 1600f;
            for (int k = 0; k < N_T; k++) {
                if (!has(k)) continue;
                float ang = tAng[k];
                for (int j = 0; j < 3; j++) {
                    float d = r * (1.5f + j * 0.55f);
                    if (d > reach - r * 1.1f) continue;
                    float lp = (phase - j * 0.15f + 1f) % 1f;
                    int al = (int) (190 * Math.sin(Math.PI * lp));
                    int cw = chev.getIntrinsicWidth(), ch = chev.getIntrinsicHeight();
                    c.save();
                    c.translate(handle.x + (float) Math.cos(ang) * d, handle.y + (float) Math.sin(ang) * d);
                    c.rotate((float) Math.toDegrees(ang));
                    chev.setBounds(-cw / 2, -ch / 2, cw / 2, ch / 2);
                    chev.setAlpha(Math.max(0, al));
                    chev.draw(c);
                    c.restore();
                    chev.setAlpha(255);
                }
            }
        }

        // alvos: círculo contornado sempre visível; cresce um pouco quando o dedo se aproxima
        for (int i = 0; i < N_T; i++) {
            if (!has(i)) continue;
            PointF p = t[i];
            float prox = drag ? Math.max(0f, 1f - dist(cur.x, cur.y, p) / (reach * 0.8f)) : 0f;
            float sc = ext ? 1f + 0.12f * prox + (near == i ? 0.06f : 0f) : 1f;
            int ta = ext ? 255 : (int) (255 * appear); // original: alvos só aparecem ao tocar no anel
            if (ext) {
                int col = i == UNLOCK ? accent : 0xFFFFFFFF;
                circle(c, p.x, p.y, r * sc, col, (i == UNLOCK ? 170 : 110) + (int) (90 * prox), true);
                circle(c, p.x, p.y, r * sc, col, 16 + (int) (34 * prox), false);
            }
            if (near == i) {
                if (i != UNLOCK) draw(c, disc, p, r * DISC, 255);
                if (ext) {
                    float pw = ((now - nearSince) % 700) / 700f;
                    circle(c, p.x, p.y, r * (1f + pw * 0.9f), accent, (int) (140 * (1f - pw)), true);
                }
            }
            if (i == UNLOCK) {
                if (near == i) draw(c, unlockA, p, r * DISC, 255); else draw(c, unlockN, p, r * LOCK * sc, ta);
            } else draw(c, icons[SLOT_OF[i]], p, r * ICON * sc, ta);
        }

        // rastro atrás do dedo
        if (ext && drag) {
            for (int i = 0; i < trN; i++) {
                float age = Math.min(1f, (now - trT[i]) / 380f);
                circle(c, trX[i], trY[i], r * 0.3f * (1f - age * 0.6f), accent, (int) (120 * (1f - age)), false);
            }
        }

        // anel (handle): no dedo; ao encostar num alvo, gruda nele
        if (drag) {
            PointF at = near >= 0 ? t[near] : cur;
            draw(c, handleP, at, r * 2f, 255);
        } else {
            draw(c, handleN, handle, r * 2f, 255);
        }
        if (screenOn) postInvalidateOnAnimation(); // com a tela apagada não fica redesenhando
    }

    @Override public void onScreenStateChanged(int state) {
        super.onScreenStateChanged(state);
        screenOn = state == View.SCREEN_STATE_ON;
        if (screenOn) { lastFrame = 0; invalidate(); }
    }
}
