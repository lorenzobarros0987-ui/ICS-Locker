package com.meu.pinlocker;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;
import java.security.MessageDigest;

final class Prefs {
    private static SharedPreferences p(Context c) { return Store.sp(c); }

    static String hash(String pin) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-256").digest(("pl1:" + pin).getBytes("UTF-8"));
            StringBuilder s = new StringBuilder();
            for (byte b : h) s.append(String.format("%02x", b));
            return s.toString();
        } catch (Exception e) { return ""; }
    }

    static void setPin(Context c, String pin) { p(c).edit().putString("h", hash(pin)).putInt("len", pin.length()).apply(); }
    static boolean hasPin(Context c) { return p(c).getString("h", null) != null; }
    static int pinLen(Context c) { return p(c).getInt("len", 4); }
    static void clearPin(Context c) { p(c).edit().remove("h").remove("len").apply(); }
    static boolean check(Context c, String pin) { return !Store.sealed(c) && hash(pin).equals(p(c).getString("h", "")); }

    // padrão de desbloqueio (sequência de pontos 0-8, guardada só como hash)
    static String hashPat(String seq) { return hash("pat:" + seq); }
    static void setPattern(Context c, String seq) { p(c).edit().putString("ph", hashPat(seq)).apply(); }
    static boolean hasPattern(Context c) { return p(c).getString("ph", null) != null; }
    static void clearPattern(Context c) { p(c).edit().remove("ph").apply(); }
    static boolean checkPattern(Context c, String seq) { return !Store.sealed(c) && hashPat(seq).equals(p(c).getString("ph", "")); }

    static boolean locked(Context c) { return p(c).getBoolean("locked", true); }
    static void setLocked(Context c, boolean v) { p(c).edit().putBoolean("locked", v).apply(); }
    static boolean enabled(Context c) { return p(c).getBoolean("enabled", false); }
    static void setEnabled(Context c, boolean v) { p(c).edit().putBoolean("enabled", v).apply(); }

    /** Atalho 0 vem com a câmera por padrão (até o usuário escolher outro ou "nenhum"). */
    static String shortcut(Context c, int i) {
        SharedPreferences sp = p(c);
        if (!sp.contains("sc" + i)) return i == 0 ? Presets.resolve(c, 2) : null;
        String v = sp.getString("sc" + i, null);
        return v == null || v.isEmpty() ? null : v;
    }
    static void setShortcut(Context c, int i, String pkg) {
        SharedPreferences.Editor e = p(c).edit();
        e.putString("sc" + i, pkg == null ? "" : pkg);
        e.apply();
    }

    static File scPhoto(Context c, int i) { return new File(c.getFilesDir(), "sc" + i + ".png"); }
}
