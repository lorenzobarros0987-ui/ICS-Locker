package com.meu.pinlocker;

import android.content.Context;
import android.content.SharedPreferences;
import java.security.MessageDigest;

final class Prefs {
    private static SharedPreferences p(Context c) { return c.getSharedPreferences("pl", Context.MODE_PRIVATE); }

    static String hash(String pin) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-256").digest(("pl1:" + pin).getBytes("UTF-8"));
            StringBuilder s = new StringBuilder();
            for (byte b : h) s.append(String.format("%02x", b));
            return s.toString();
        } catch (Exception e) { return ""; }
    }

    static void setPin(Context c, String pin) { p(c).edit().putString("h", hash(pin)).putInt("len", pin.length()).apply(); }
    static boolean hasPin(Context c) { return p(c).getString("h", null) != null; }
    static int pinLen(Context c) { return p(c).getInt("len", 4); }
    static boolean check(Context c, String pin) { return hash(pin).equals(p(c).getString("h", "")); }

    static boolean locked(Context c) { return p(c).getBoolean("locked", true); }
    static void setLocked(Context c, boolean v) { p(c).edit().putBoolean("locked", v).apply(); }
    static boolean enabled(Context c) { return p(c).getBoolean("enabled", false); }
    static void setEnabled(Context c, boolean v) { p(c).edit().putBoolean("enabled", v).apply(); }

    static String shortcut(Context c, int i) { return p(c).getString("sc" + i, null); }
    static void setShortcut(Context c, int i, String pkg) {
        SharedPreferences.Editor e = p(c).edit();
        if (pkg == null) e.remove("sc" + i); else e.putString("sc" + i, pkg);
        e.apply();
    }
}
