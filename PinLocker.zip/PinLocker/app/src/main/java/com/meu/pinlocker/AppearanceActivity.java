package com.meu.pinlocker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.function.IntConsumer;

public class AppearanceActivity extends Activity {
    private LinearLayout col;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        setTitle("Aparência");
        ScrollView sv = new ScrollView(this);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(8), dp(16), dp(16));
        sv.addView(col);
        setContentView(sv);
        build();
    }

    private void build() {
        col.removeAllViews();
        int bg = Look.idx(this, "bg", Look.BG_N.length);
        btn("VER PRÉVIA", v -> startActivity(new Intent(this, LockActivity.class).putExtra("preview", true)));

        head("Fundo");
        choice("Fundo", Look.BG_N, bg, w -> { Look.setI(this, "bg", w); if (w == 7 && !Look.photoFile(this).exists()) pickPhoto(); });
        if (bg == 7) {
            btn("Trocar foto", v -> pickPhoto());
            seek("Escurecer foto (%)", "dim", 0, 85, 30);
        }
        choice("Cor de destaque", Look.ACCENT_N, Look.idx(this, "accent", Look.ACCENT.length), w -> Look.setI(this, "accent", w));
        check("Pintar os anéis com a cor de destaque", "ringTint", false);

        head("Relógio e data");
        choice("Fonte do relógio", Fonts.NAMES, Fonts.index(this), w -> Fonts.set(this, w));
        choice("Cor do relógio", Look.CCOL_N, Look.idx(this, "ccol", Look.CCOL_N.length), w -> Look.setI(this, "ccol", w));
        seek("Tamanho do relógio (sp)", "csize", 48, 120, 84);
        choice("Posição do relógio", Look.CPOS_N, Look.idx(this, "cpos", Look.CPOS_N.length), w -> Look.setI(this, "cpos", w));
        choice("Formato da hora", Look.HMODE_N, Look.idx(this, "hmode", Look.HMODE_N.length), w -> Look.setI(this, "hmode", w));
        check("Mostrar data", "showDate", true);
        choice("Formato da data", Look.DFMT_N, Look.idx(this, "dfmt", Look.DFMT.length), w -> Look.setI(this, "dfmt", w));

        head("Teclado de PIN");
        check("Mostrar letras (ABC, DEF...)", "pinLetters", true);
        check("Embaralhar as teclas", "pinShuffle", false);
        check("Vibrar ao tocar", "pinHaptic", true);
        check("Mostrar os números digitados", "pinShow", false);

        btn("Restaurar padrão", v -> { Look.reset(this); build(); });
    }

    private void head(String t) {
        TextView v = new TextView(this);
        v.setText(t.toUpperCase());
        v.setTextColor(0xFF33B5E5);
        v.setPadding(0, dp(18), 0, dp(4));
        col.addView(v);
    }

    private void btn(String t, android.view.View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(t);
        x.setOnClickListener(l);
        col.addView(x);
    }

    private void choice(String label, String[] names, int cur, IntConsumer on) {
        btn(label + ": " + names[cur], v -> new AlertDialog.Builder(this).setTitle(label)
                .setSingleChoiceItems(names, cur, (d, w) -> { d.dismiss(); on.accept(w); build(); }).show());
    }

    private void check(String label, String key, boolean def) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setChecked(Look.b(this, key, def));
        c.setOnCheckedChangeListener((v, on) -> Look.setB(this, key, on));
        col.addView(c);
    }

    private void seek(final String label, final String key, final int min, int max, int def) {
        final TextView t = new TextView(this);
        int cur = Look.i(this, key, def);
        t.setText(label + ": " + cur);
        t.setPadding(0, dp(8), 0, 0);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(cur - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) {
                Look.setI(AppearanceActivity.this, key, p + min);
                t.setText(label + ": " + (p + min));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        col.addView(t);
        col.addView(s);
    }

    private void pickPhoto() {
        startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 1 && res == RESULT_OK && data != null && data.getData() != null) {
            try { savePhoto(data.getData()); } catch (Exception e) { Toast.makeText(this, "Não consegui usar essa foto", Toast.LENGTH_LONG).show(); }
            build();
        }
    }

    private void savePhoto(Uri u) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 1400) s *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = s;
        Bitmap bmp;
        try (InputStream in = getContentResolver().openInputStream(u)) { bmp = BitmapFactory.decodeStream(in, null, o); }
        try (FileOutputStream f = new FileOutputStream(Look.photoFile(this))) { bmp.compress(Bitmap.CompressFormat.JPEG, 90, f); }
    }
}
