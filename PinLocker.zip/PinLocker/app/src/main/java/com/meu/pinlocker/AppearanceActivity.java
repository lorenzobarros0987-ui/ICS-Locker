package com.meu.pinlocker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.function.IntConsumer;

public class AppearanceActivity extends Activity {
    private LinearLayout col;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        L.init(this);
        setTitle(L.t("app_title_appearance"));
        col = Ui.page(this);
        build();
    }

    private void build() {
        col.removeAllViews();
        card = null;
        int bg = Look.idxd(this, "bg", Look.BG.length, Look.BG_WALL);
        btn(L.t("preview"), v -> startActivity(new Intent(this, LockActivity.class).putExtra("preview", true)));

        head(L.t("h_bg"));
        choice(L.t("bg"), Look.bgN(), bg, w -> {
            Look.setI(this, "bg", w);
            if (w == Look.BG_PHOTO && !Look.photoFile(this).exists()) pickPhoto();
            if (w == Look.BG_LIVE) Toast.makeText(this, L.t("wp_live_hint"), Toast.LENGTH_LONG).show();
            if ((w == Look.BG_WALL || w == Look.BG_LOCKWP) && android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 2);
                Toast.makeText(this, L.t("wp_perm"), Toast.LENGTH_LONG).show();
            }
        });
        if (bg == Look.BG_PHOTO) btn(L.t("change_photo"), v -> pickPhoto());
        if (bg == Look.BG_PHOTO || bg == Look.BG_WALL || bg == Look.BG_LOCKWP || bg == Look.BG_LIVE) seek(L.t("dim"), "dim", 0, 85, 40);
        if (Look.isLive(this)) check(L.t("wp_touch"), "wpTouch", true);
        if (bg == Look.BG_LIVE || bg == Look.BG_WALL) btn(L.t("wp_pick_live"), v -> {
            try { startActivity(new Intent(android.app.WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)); }
            catch (Throwable t) { Toast.makeText(this, L.t("wp_pick_fail"), Toast.LENGTH_LONG).show(); }
        });
        choice(L.t("accent"), Look.accentN(), Look.idxd(this, "accent", Look.ACCENT_COUNT, 0), w -> Look.setI(this, "accent", w));
        choice(L.t("visual"), Look.visualN(), Look.idxd(this, "visual", 2, 0), w -> Look.setI(this, "visual", w));
        check(L.t("ringtint"), "ringTint", false);

        head(L.t("h_status"));
        check(L.t("holobar"), "holoBar", true);

        head(L.t("h_ring"));
        seek(L.t("ringsize"), "ringSize", 60, 110, 85);

        head(L.t("h_clock"));
        choice(L.t("cfont"), Fonts.NAMES, Fonts.index(this), w -> Fonts.set(this, w));
        choice(L.t("ccolor"), Look.ccolN(), Look.idxd(this, "ccol", 4, 0), w -> Look.setI(this, "ccol", w));
        seek(L.t("csize"), "csize", 48, 120, 84);
        choice(L.t("cpos"), Look.cposN(), Look.idxd(this, "cpos", 3, 0), w -> Look.setI(this, "cpos", w));
        choice(L.t("calign"), Look.calignN(), Look.idxd(this, "calign", 3, 0), w -> Look.setI(this, "calign", w));
        choice(L.t("hmode"), Look.hmodeN(), Look.idxd(this, "hmode", 3, 0), w -> Look.setI(this, "hmode", w));
        check(L.t("showdate"), "showDate", true);
        choice(L.t("dfmt"), Look.dfmtN(), Look.idxd(this, "dfmt", 4, 0), w -> Look.setI(this, "dfmt", w));

        head(L.t("h_pin"));
        choice(L.t("pinstyle"), Look.pinStyleN(), Look.pinUi(this), w -> Look.setI(this, "pinUi", w));
        check(L.t("pinletters"), "pinLetters", true);
        check(L.t("pinshuffle"), "pinShuffle", false);
        check(L.t("pinhaptic"), "pinHaptic", true);
        check(L.t("pinshow"), "pinShow", false);
        check(L.t("pincircles"), "pinCircles", true);

        head(L.t("h_bottom"));
        choice(L.t("btm"), Look.btmN(), Look.idxd(this, "btm", 3, 0), w -> Look.setI(this, "btm", w));
        btn(L.t("edit_label"), v -> {
            final android.widget.EditText et = new android.widget.EditText(this);
            et.setText(Look.s(this, "label", ""));
            new android.app.AlertDialog.Builder(this).setTitle(L.t("edit_label")).setView(et)
                    .setPositiveButton(L.t("save"), (d, w) -> Look.setS(this, "label", et.getText().toString().trim()))
                    .setNegativeButton(L.t("cancel"), null).show();
        });

        head(L.t("h_shortcuts"));
        choice(L.t("scshape"), Look.scShapeN(), Look.idxd(this, "scShape", 3, 0), w -> Look.setI(this, "scShape", w));
        check(L.t("sc_need_unlock"), "scNeedUnlock", false);

        head(L.t("h_behavior"));
        choice(L.t("lockmode"), Look.lockModeN(), Look.lockMode(this), w -> Look.setI(this, "lockMode", w));
        check(L.t("mutebg"), "muteBg", true);

        head(L.t("h_lang"));
        choice(L.t("language"), L.LANG_N, Look.idxd(this, "lang", 3, 0), w -> { Look.setI(this, "lang", w); L.init(this); });

        btn(L.t("reset"), v -> { Look.reset(this); build(); });
    }

    private LinearLayout card;

    private LinearLayout tgt() { if (card == null) card = Ui.card(this, col, null); return card; }

    private void head(String t) { card = Ui.card(this, col, t); }

    private void btn(String t, android.view.View.OnClickListener l) { Ui.action(this, tgt(), t, l); }

    private void choice(String label, String[] names, int cur, IntConsumer on) {
        Ui.item(this, tgt(), label, names[cur], v -> new AlertDialog.Builder(this).setTitle(label)
                .setSingleChoiceItems(names, cur, (d, w) -> { d.dismiss(); on.accept(w); build(); }).show());
    }

    private void check(String label, String key, boolean def) {
        Ui.toggle(this, tgt(), label, null, Look.b(this, key, def), (v, on) -> Look.setB(this, key, on));
    }

    private void seek(final String label, final String key, final int min, int max, int def) {
        Ui.seek(this, tgt(), label, min, max, Look.i(this, key, def), key.equals("dim") || key.equals("ringSize") ? "%" : "", v -> Look.setI(this, key, v));
    }

    private void pickPhoto() {
        startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 1 && res == RESULT_OK && data != null && data.getData() != null) {
            try { savePhoto(data.getData()); } catch (Exception e) { Toast.makeText(this, L.t("photo_fail"), Toast.LENGTH_LONG).show(); }
            build();
        }
    }

    private void savePhoto(Uri u) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 1400) s *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = s;
        Bitmap bmp;
        try (InputStream in = getContentResolver().openInputStream(u)) { bmp = BitmapFactory.decodeStream(in, null, o); }
        try (FileOutputStream f = new FileOutputStream(Look.photoFile(this))) { bmp.compress(Bitmap.CompressFormat.JPEG, 90, f); }
    }
}
