package com.meu.pinlocker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.view.ContextThemeWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.graphics.PixelFormat;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.view.KeyEvent;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/**
 * Fica rodando. Enquanto trancado, a tela de bloqueio é uma janela por cima de TUDO o tempo todo
 * (não espera o usuário sair de um app para tampar). Só o menu de desligar (segurar o power) passa por cima.
 */
public class LockService extends Service {
    static final String ACT_LOCK = "lock", ACT_UNLOCK = "unlock", ACT_ALLOW = "allow", ACT_SHOW = "show", ACT_KB = "kb";
    private static final long POWER_GRACE = 7000;

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private LockScreen screen;   // janela principal (cobre tudo)
    private View blocker;        // faixa sobre a barra de status
    private String allowed;      // app de atalho liberado enquanto trancado
    private long allowedAt, watchFrom, graceUntil;
    private boolean suspended; // camada montada, mas invisível e sem toque (app de atalho na frente)
    private boolean pinPage;     // página de PIN com teclado do celular aberta
    static LockService inst;
    private String pendingPkg;  // atalho esperando a camada secundária ficar pronta
    private boolean pendingKb; // página de PIN esperando a camada secundária
    private int kbSlot = -1;     // atalho que a página de PIN vai abrir depois (-1 = só desbloquear)
    private boolean secondary;  // camada secundária (LockActivity) atrás do app de atalho
    private static final long SECONDARY_WAIT = 2500; // quanto esperar a camada secundária antes de desistir do atalho
    private final Runnable fallbackRun = () -> { if (pendingKb) pinPage = false; if (pendingPkg != null || pendingKb) endSecondary(); }; // não abriu a secundária: não abre o app
    private boolean liveWin;   // janela criada em modo papel de parede ao vivo (translúcida)
    private boolean lowered, sawLoss; // tela atrás do menu de desligar / o menu já tirou o foco dela
    private int ticks;

    private final LockScreen.Host host = new LockScreen.Host() {
        @Override public void unlock() { LockService.this.unlock(); }
        @Override public void launch(int slot) { launchShortcut(slot); }
        @Override public void keyboardPin(int slot) { startKeyboardPin(slot); }
        @Override public void unlockAndLaunch(int slot) { LockService.this.unlockAndLaunch(slot); }
    };

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(a)) { if (Look.lockMode(c) == 2 && !Prefs.locked(c)) return; lock(); } // modo 2: só bloqueia logo após ligar o celular
            else if (Intent.ACTION_WALLPAPER_CHANGED.equals(a)) { LockScreen.dropWallpaperCache(); }
            else if (Intent.ACTION_SCREEN_ON.equals(a)) { if (Prefs.locked(c)) { graceUntil = 0; bringBackToFront(); ensureCovered(); silenceBackground(); startTick(700); } } // o 1º tick espera a tela ligar
            else if (Intent.ACTION_CLOSE_SYSTEM_DIALOGS.equals(a)) {
                // menu de desligar (segurar o power): deixa passar por alguns segundos
                String reason = i.getStringExtra("reason");
                if ("globalactions".equals(reason) && Prefs.locked(c) && Look.b(c, "blockPower", false)) {
                    blockPowerMenu();
                } else if ("globalactions".equals(reason) && Prefs.locked(c)) {
                    graceUntil = System.currentTimeMillis() + POWER_GRACE;
                    holdBehindPowerMenu();
                } else if (("homekey".equals(reason) || "recentapps".equals(reason)) && Prefs.locked(c) && suspended && !pinPage) {
                    returnToMain(); // Home ou Recentes com um atalho aberto: a tela de bloqueio volta na hora, sem esperar o tick
                }
            }
        }
    };

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!Prefs.locked(LockService.this) || !interactive()) return;
            long now = System.currentTimeMillis();
            if (now < graceUntil) { h.postDelayed(this, 200); return; }
            if (graceUntil != 0) { graceUntil = 0; bringBackToFront(); if (!suspended) ensureCovered(); } // com app de atalho aberto, não pula a tela de bloqueio por cima dele
            else if (lowered) bringBackToFront();
            collapse();
            if (!suspended && screen != null && ticks % 4 == 0) silenceBackground();
            if ((screen == null || suspended) && !pinPage) {
                String fg = foreground(watchFrom);
                boolean ours = fg != null && fg.equals(getPackageName());
                if (secondary && ours) {
                    // voltou para a camada secundária (ex.: botão voltar): traz a principal de volta
                    if (now - allowedAt > 1500) returnToMain();
                } else if (fg != null && !ours && !isSystemUi(fg)) { // menu de desligar/SystemUI não é "outro app": evita a tela de bloqueio piscar por cima do atalho
                    if (allowed != null && now - allowedAt < 3000) allowed = fg; // aprende o pacote real do atalho
                    else if (!fg.equals(allowed)) { if (secondary) returnToMain(); else showOverlay(); }
                }
            }
            h.postDelayed(this, suspended ? 120 : 500);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        inst = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        L.init(this);
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        f.addAction(Intent.ACTION_WALLPAPER_CHANGED);
        registerReceiver(rx, f);
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        L.init(this);
        startForeground(1, notif());
        String a = i == null ? null : i.getAction();
        if (ACT_UNLOCK.equals(a)) unlock();
        else if (ACT_ALLOW.equals(a)) { allowed = i.getStringExtra("pkg"); allowedAt = System.currentTimeMillis(); watchFrom = allowedAt; suspendOverlay(); startTick(); }
        else if (ACT_SHOW.equals(a)) { pinPage = false; if (Prefs.locked(this)) { if (secondary) returnToMain(); else ensureCovered(); startTick(); } }
        else if (ACT_KB.equals(a)) { pinPage = true; }
        else if (ACT_LOCK.equals(a) || Prefs.locked(this)) lock();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        inst = null;
        endSecondary();
        h.removeCallbacks(tick);
        hideOverlay();
        hideBlocker();
        try { unregisterReceiver(rx); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    /**
     * Opção "bloquear menu de desligar": com o serviço de acessibilidade a tela fica numa camada ACIMA do menu
     * (ver overlayType). Se um app de atalho estiver aberto, a tela de bloqueio volta ao início na hora.
     */
    private void blockPowerMenu() {
        if (suspended) returnToMain();
        if (Build.VERSION.SDK_INT >= 26 && PowerGuard.inst == null) { // sem acessibilidade não dá para ficar por cima: fecha uma vez
            try { sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)); } catch (Throwable ignored) { }
        }
    }

    private static boolean isSystemUi(String pkg) { return pkg.contains(".systemui") || pkg.equals("android"); }

    // ---- sons de apps em segundo plano ----
    private AudioManager am;
    private AudioFocusRequest afReq;
    private final AudioManager.OnAudioFocusChangeListener afl = f -> { };

    /** Pausa quem estiver tocando e segura o foco de áudio enquanto estiver trancado (apps que respeitam o foco ficam quietos). */
    private void silenceBackground() {
        if (!Look.muteBg(this)) return;
        try {
            if (am == null) am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am == null) return;
            if (am.isMusicActive()) {
                long n = android.os.SystemClock.uptimeMillis();
                am.dispatchMediaKeyEvent(new KeyEvent(n, n, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0));
                am.dispatchMediaKeyEvent(new KeyEvent(n, n, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0));
            }
            if (Build.VERSION.SDK_INT >= 26) {
                if (afReq == null) afReq = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                        .setOnAudioFocusChangeListener(afl).build();
                am.requestAudioFocus(afReq);
            } else am.requestAudioFocus(afl, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        } catch (Throwable ignored) { }
    }

    private void releaseAudio() {
        try {
            if (am == null) return;
            if (Build.VERSION.SDK_INT >= 26) { if (afReq != null) am.abandonAudioFocusRequest(afReq); }
            else am.abandonAudioFocus(afl);
        } catch (Throwable ignored) { }
    }

    private boolean aboveMenu() { return Build.VERSION.SDK_INT >= 26 && Look.b(this, "blockPower", false) && PowerGuard.inst != null; }

    private boolean interactive() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm == null || pm.isInteractive();
    }

    private void startTick() { startTick(0); }
    private void startTick(long delay) { h.removeCallbacks(tick); if (delay > 0) h.postDelayed(tick, delay); else h.post(tick); }

    private void lock() {
        Prefs.setLocked(this, true);
        silenceBackground();
        bringBackToFront(); // apagou a tela com o menu aberto: não deixa a janela no nível baixo
        endSecondary();
        allowed = null;
        pinPage = false;
        graceUntil = 0;
        if (screen != null && !suspended && liveWin != wantLive()) hideOverlay(); // trocou o tipo de fundo: recria a janela
        if (screen != null) screen.refresh();
        ensureCovered();
        if (interactive()) startTick(); else h.removeCallbacks(tick);
    }

    private void unlock() {
        Prefs.setLocked(this, false);
        releaseAudio();
        allowed = null;
        pinPage = false;
        graceUntil = 0;
        endSecondary();
        h.removeCallbacks(tick);
        hideOverlay();
        hideBlocker();
    }

    private void ensureCovered() {
        showBlocker();
        if (!pinPage) showOverlay();
    }

    /**
     * Atalho em camadas: 1) cria a camada secundária escondida atrás dos apps (LockActivity), 2) tira a principal,
     * 3) abre o app. Ao sair do app: 4) a principal volta e 5) a secundária é removida.
     */
    private void launchShortcut(int slot) {
        String pkg = Prefs.shortcut(this, slot);
        if (pendingPkg != null || pendingKb || pkg == null || getPackageManager().getLaunchIntentForPackage(pkg) == null) return;
        pendingPkg = pkg;
        try {
            startActivity(new Intent(this, LockActivity.class).putExtra("secondary", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
            h.postDelayed(fallbackRun, SECONDARY_WAIT); // se a secundária demorar, cancela (a principal continua na frente)
        } catch (Exception e) { endSecondary(); }
    }

    /** Opção "exigir PIN para atalhos": PIN certo desbloqueia de vez e abre o app. */
    private void unlockAndLaunch(int slot) {
        String pkg = Prefs.shortcut(this, slot);
        Intent li = pkg == null ? null : getPackageManager().getLaunchIntentForPackage(pkg);
        if (li != null) { try { startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception ignored) { } }
        h.postDelayed(this::unlock, 300); // o app abre por baixo e só então a tela de bloqueio sai (sem piscar a home)
    }

    /** Chamado pela LockActivity quando a camada secundária já está na tela. */
    static void onSecondaryReady() { if (inst != null) inst.secondaryReady(); }

    private void secondaryReady() {
        if (pendingPkg == null && !pendingKb) return;
        h.removeCallbacks(fallbackRun);
        secondary = true;
        if (pendingKb) openKb(); else openPending();
    }

    private void openPending() {
        String pkg = pendingPkg;
        pendingPkg = null;
        if (pkg == null) return;
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) { endSecondary(); return; }
        allowed = pkg;
        allowedAt = System.currentTimeMillis();
        suspendOverlay();                      // 2) tira a camada principal
        watchFrom = System.currentTimeMillis();
        try { startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } // 3) abre o app
        catch (Exception e) { returnToMain(); return; }
        startTick();
    }

    /** 4) principal volta para a frente e 5) só depois a secundária é removida. */
    private void returnToMain() {
        secondary = false;
        showOverlay();
        h.postDelayed(LockActivity::closeSecondary, 150);
    }

    private void endSecondary() {
        secondary = false;
        pendingPkg = null;
        pendingKb = false;
        h.removeCallbacks(fallbackRun);
        LockActivity.closeSecondary();
    }

    /**
     * Desbloqueio em página cheia, em camadas (igual aos atalhos): 1) cria a camada secundária atrás,
     * 2) tira a principal, 3) mostra a página do PIN. Cancelar/sair: a principal volta e a secundária some.
     */
    private void startKeyboardPin(int slot) {
        if (pendingKb || pendingPkg != null) return;
        pendingKb = true;
        kbSlot = slot;
        pinPage = true;
        try {
            startActivity(new Intent(this, LockActivity.class).putExtra("secondary", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
            h.postDelayed(fallbackRun, SECONDARY_WAIT);
        } catch (Exception e) { pinPage = false; endSecondary(); }
    }

    private void openKb() {
        pendingKb = false;
        suspendOverlay();                                  // 2) tira a camada principal
        try {
            startActivity(new Intent(this, LockActivity.class).putExtra("kb", true).putExtra("slot", kbSlot)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)); // 3) página do PIN
        } catch (Exception e) { pinPage = false; returnToMain(); }
    }

    private boolean canOverlay() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this); }

    /** Com a barra de status ligada a tela fica ABAIXO da barra do sistema (SYSTEM_ALERT), que aparece por cima dela. */
    private int overlayType() {
        if (Build.VERSION.SDK_INT >= 26) return aboveMenu() ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY : WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        return WindowManager.LayoutParams.TYPE_SYSTEM_ERROR; // cobre também a barra de status do sistema (a Holo é desenhada pela própria tela)
    }

    /** A faixa que bloqueia toque na barra de status precisa ficar ACIMA dela. */
    private int blockerType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
    }

    private void showOverlay() {
        if (screen != null) { if (suspended) resumeOverlay(); return; }
        if (!canOverlay()) { // sem permissão de sobrepor: cai para a tela de bloqueio em Activity
            if (!interactive()) return;
            try { startActivity(new Intent(this, LockActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)); } catch (Exception ignored) { }
            return;
        }
        allowed = null;
        LockScreen s = addOverlay(overlayType(), false);
        if (s != null) { screen = s; suspended = false; }
    }

    private LockScreen addOverlay(int type, boolean behindPowerMenu) {
        Point p = new Point();
        wm.getDefaultDisplay().getRealSize(p);
        final int pw = Math.min(p.x, p.y), ph = Math.max(p.x, p.y); // a tela de bloqueio nunca vira para horizontal
        // focável de propósito: só a janela com foco manda esconder a barra de baixo
        int flags = WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN; // sem barra de status/navegação do sistema
        final boolean live = wantLive();
        if (live) flags |= WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER; // o sistema desenha o papel de parede (inclusive animado) atrás
        // atrás do menu de desligar: mantém a tela ligada (continua focável: assim sabemos quando o menu fecha)
        if (behindPowerMenu) flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(pw, ph, type, flags, live ? PixelFormat.TRANSLUCENT : PixelFormat.OPAQUE);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        final LockScreen s = new LockScreen(new ContextThemeWrapper(this, android.R.style.Theme_Holo), host);
        s.refresh();
        // o menu de desligar tira o foco da tela; quando ele fecha antes dos 7 s, o foco volta e a tela volta na hora
        s.setFocusListener(f -> {
            if (s != screen || !lowered) return;
            if (!f) sawLoss = true;
            else if (sawLoss) bringBackToFront();
        });
        try {
            WindowManager w = type == WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY && PowerGuard.inst != null
                    ? (WindowManager) PowerGuard.inst.getSystemService(WINDOW_SERVICE) : wm;
            w.addView(s, lp);
            liveWin = live;
            if (!behindPowerMenu) { s.setFocusableInTouchMode(true); s.requestFocus(); }
            return s;
        } catch (Exception ignored) { return null; }
    }

    /**
     * Menu de desligar (segurar o power): a tela de bloqueio continua ligada e visível ATRÁS do menu, sem sumir.
     * No Android 8+ a janela de sobreposição já fica abaixo do menu. No Android 7 (TYPE_SYSTEM_ERROR cobre o menu)
     * ela é recriada num tipo de janela mais baixo durante a tolerância.
     */
    private void holdBehindPowerMenu() {
        if (screen == null || suspended) return;
        lowered = true;
        sawLoss = false;
        if (Build.VERSION.SDK_INT < 26) swapOverlay(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT, true);
        else screen.setKeepScreenOn(true);
        startTick();
    }

    /** Fim da tolerância: a tela de bloqueio volta para a frente de tudo. */
    private void bringBackToFront() {
        if (!lowered) return;
        lowered = false;
        graceUntil = 0;
        if (screen == null || suspended) return;
        screen.setKeepScreenOn(false);
        if (Build.VERSION.SDK_INT < 26) swapOverlay(overlayType(), false);
    }

    /** Põe uma janela nova no tipo pedido e só então tira a antiga (sem piscar). */
    private void swapOverlay(int type, boolean behindPowerMenu) {
        if (screen == null || !canOverlay()) return;
        LockScreen n = addOverlay(type, behindPowerMenu);
        if (n == null) return;
        LockScreen old = screen;
        screen = n; // antes de remover a antiga, para ignorar os eventos de foco dela
        h.postDelayed(() -> { try { wm.removeView(old); } catch (Exception ignored) { } }, 250); // a nova já desenhou: aí sim sai a antiga
    }

    /** Remove de vez (desbloqueou ou serviço parou). */
    private boolean wantLive() { return Look.isLive(this); }

    private void hideOverlay() {
        suspended = false;
        lowered = false;
        if (screen == null) return;
        try { wm.removeView(screen); } catch (Exception ignored) { }
        screen = null;
    }

    /** Deixa a camada montada mas invisível e sem toque, para voltar na hora (sem recriar). */
    private void suspendOverlay() {
        if (screen == null || suspended) return;
        try {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) screen.getLayoutParams();
            lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            lp.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; // com o atalho aberto, o app escolhe a orientação dele
            screen.setVisibility(View.GONE);
            wm.updateViewLayout(screen, lp);
            suspended = true;
        } catch (Exception e) { hideOverlay(); }
    }

    private void resumeOverlay() {
        if (screen == null || !suspended) return;
        try {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) screen.getLayoutParams();
            lp.flags &= ~(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
            lp.screenOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT; // a tela de bloqueio volta sempre em pé
            screen.setVisibility(View.VISIBLE);
            screen.showLock();
            screen.hideBars();
            wm.updateViewLayout(screen, lp);
            screen.requestFocus();
            suspended = false;
        } catch (Exception e) { hideOverlay(); showOverlay(); }
    }

    /** Fecha a aba de notificações se alguém conseguir puxar. */
    private Object sbSvc;
    private java.lang.reflect.Method collapseM;
    private void collapse() {
        try {
            if (collapseM == null) { // reflexão uma vez só
                sbSvc = getSystemService("statusbar");
                if (sbSvc != null) collapseM = sbSvc.getClass().getMethod("collapsePanels");
            }
            if (collapseM != null) collapseM.invoke(sbSvc);
        } catch (Throwable ignored) { }
        if (++ticks % 2 == 0) {
            try { sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)); } catch (Throwable ignored) { }
        }
    }

    private String foreground(long from) {
        try {
            UsageStatsManager u = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            long n = System.currentTimeMillis();
            UsageEvents ev = u.queryEvents(Math.max(n - 10000, from), n);
            UsageEvents.Event e = new UsageEvents.Event();
            String last = null;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.getPackageName();
            }
            return last;
        } catch (Exception x) { return null; }
    }

    /** Faixa invisível sobre a barra de status (fica sempre, mesmo com app de atalho aberto). */
    private void showBlocker() {
        if (blocker != null || !canOverlay()) return;
        int sb = 0;
        int rid = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (rid > 0) sb = getResources().getDimensionPixelSize(rid);
        if (sb == 0) sb = (int) (28 * getResources().getDisplayMetrics().density);
        sb += (int) (8 * getResources().getDisplayMetrics().density);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, sb, blockerType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        View v = new View(this);
        v.setOnTouchListener((a, b) -> true);
        try { wm.addView(v, lp); blocker = v; } catch (Exception ignored) { }
    }

    private void hideBlocker() {
        if (blocker == null) return;
        try { wm.removeView(blocker); } catch (Exception ignored) { }
        blocker = null;
    }

    private Notification notif() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("pl", "PIN Locker", NotificationManager.IMPORTANCE_MIN));
            b = new Notification.Builder(this, "pl");
        } else b = new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle(L.t("active_notif")).build();
    }
}
