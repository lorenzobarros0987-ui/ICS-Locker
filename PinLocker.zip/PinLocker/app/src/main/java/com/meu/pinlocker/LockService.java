package com.meu.pinlocker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/** Fica rodando, tranca ao apagar a tela e vigia qual app está na frente enquanto trancado. */
public class LockService extends Service {
    static final String ACT_LOCK = "lock", ACT_UNLOCK = "unlock", ACT_ALLOW = "allow";

    private final Handler h = new Handler(Looper.getMainLooper());
    private View blocker;
    private String allowed;      // app de atalho liberado enquanto trancado
    private long allowedAt;

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) lock();
            else if (Prefs.locked(c)) bringLock();
        }
    };

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!Prefs.locked(LockService.this)) return;
            String fg = foreground();
            if (fg != null && !fg.equals(getPackageName())) {
                if (allowed != null && System.currentTimeMillis() - allowedAt < 3000) allowed = fg; // aprende o pacote real do atalho
                else if (!fg.equals(allowed)) bringLock();
            }
            h.postDelayed(this, 400);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(rx, f);
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        startForeground(1, notif());
        String a = i == null ? null : i.getAction();
        if (ACT_UNLOCK.equals(a)) unlock();
        else if (ACT_ALLOW.equals(a)) { allowed = i.getStringExtra("pkg"); allowedAt = System.currentTimeMillis(); }
        else if (ACT_LOCK.equals(a) || Prefs.locked(this)) lock();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        h.removeCallbacks(tick);
        hideBlocker();
        try { unregisterReceiver(rx); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    private void lock() {
        Prefs.setLocked(this, true);
        allowed = null;
        showBlocker();
        h.removeCallbacks(tick);
        h.post(tick);
        bringLock();
    }

    private void unlock() {
        Prefs.setLocked(this, false);
        allowed = null;
        hideBlocker();
        h.removeCallbacks(tick);
    }

    private void bringLock() {
        allowed = null;
        try { sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)); } catch (Exception ignored) { }
        Intent i = new Intent(this, LockActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { startActivity(i); } catch (Exception ignored) { }
    }

    private String foreground() {
        try {
            UsageStatsManager u = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            long n = System.currentTimeMillis();
            UsageEvents ev = u.queryEvents(n - 10000, n);
            UsageEvents.Event e = new UsageEvents.Event();
            String last = null;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.getPackageName();
            }
            return last;
        } catch (Exception x) { return null; }
    }

    /** Faixa invisível sobre a barra de status para não puxar as notificações. */
    private void showBlocker() {
        if (blocker != null || !Settings.canDrawOverlays(this)) return;
        int sb = 0;
        int rid = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (rid > 0) sb = getResources().getDimensionPixelSize(rid);
        if (sb == 0) sb = (int) (28 * getResources().getDisplayMetrics().density);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, sb,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        View v = new View(this);
        v.setOnTouchListener((a, b) -> true);
        try { ((WindowManager) getSystemService(WINDOW_SERVICE)).addView(v, lp); blocker = v; } catch (Exception ignored) { }
    }

    private void hideBlocker() {
        if (blocker == null) return;
        try { ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(blocker); } catch (Exception ignored) { }
        blocker = null;
    }

    private Notification notif() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("pl", "PIN Locker", NotificationManager.IMPORTANCE_MIN));
            b = new Notification.Builder(this, "pl");
        } else b = new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("PIN Locker ativo").build();
    }
}
