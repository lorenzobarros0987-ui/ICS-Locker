package com.meu.pinlocker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.view.ContextThemeWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

/**
 * Fica rodando. Enquanto trancado, a tela de bloqueio é uma janela por cima de TUDO o tempo todo
 * (não espera o usuário sair de um app para tampar). Só o menu de desligar (segurar o power) passa por cima.
 */
public class LockService extends Service {
    static final String ACT_LOCK = "lock", ACT_UNLOCK = "unlock", ACT_ALLOW = "allow", ACT_SHOW = "show", ACT_KB = "kb";
    private static final long POWER_GRACE = 7000;

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private LockScreen screen;   // janela principal (cobre tudo)
    private View blocker;        // faixa sobre a barra de status
    private String allowed;      // app de atalho liberado enquanto trancado
    private long allowedAt, watchFrom, graceUntil;
    private boolean suspended; // camada montada, mas invisível e sem toque (app de atalho na frente)
    private boolean pinPage;     // página de PIN com teclado do celular aberta
    private int ticks;

    private final LockScreen.Host host = new LockScreen.Host() {
        @Override public void unlock() { LockService.this.unlock(); }
        @Override public void launch(int slot) { launchShortcut(slot); }
        @Override public void keyboardPin() { startKeyboardPin(); }
    };

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            String a = i.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(a)) { lock(); }
            else if (Intent.ACTION_SCREEN_ON.equals(a)) { if (Prefs.locked(c)) { graceUntil = 0; ensureCovered(); startTick(); } }
            else if (Intent.ACTION_CLOSE_SYSTEM_DIALOGS.equals(a)) {
                // menu de desligar (segurar o power): deixa passar por alguns segundos
                if ("globalactions".equals(i.getStringExtra("reason")) && Prefs.locked(c)) {
                    graceUntil = System.currentTimeMillis() + POWER_GRACE;
                    suspendOverlay();
                }
            }
        }
    };

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!Prefs.locked(LockService.this) || !interactive()) return;
            long now = System.currentTimeMillis();
            if (now < graceUntil) { h.postDelayed(this, 200); return; }
            if (graceUntil != 0) { graceUntil = 0; ensureCovered(); }
            collapse();
            if ((screen == null || suspended) && !pinPage) {
                String fg = foreground(watchFrom);
                if (fg != null && !fg.equals(getPackageName())) {
                    if (allowed != null && now - allowedAt < 3000) allowed = fg; // aprende o pacote real do atalho
                    else if (!fg.equals(allowed)) showOverlay();
                }
            }
            h.postDelayed(this, suspended ? 100 : 250);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        L.init(this);
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        registerReceiver(rx, f);
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        L.init(this);
        startForeground(1, notif());
        String a = i == null ? null : i.getAction();
        if (ACT_UNLOCK.equals(a)) unlock();
        else if (ACT_ALLOW.equals(a)) { allowed = i.getStringExtra("pkg"); allowedAt = System.currentTimeMillis(); watchFrom = allowedAt; suspendOverlay(); startTick(); }
        else if (ACT_SHOW.equals(a)) { pinPage = false; if (Prefs.locked(this)) { ensureCovered(); startTick(); } }
        else if (ACT_KB.equals(a)) { pinPage = true; }
        else if (ACT_LOCK.equals(a) || Prefs.locked(this)) lock();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        h.removeCallbacks(tick);
        hideOverlay();
        hideBlocker();
        try { unregisterReceiver(rx); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    private boolean interactive() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm == null || pm.isInteractive();
    }

    private void startTick() { h.removeCallbacks(tick); h.post(tick); }

    private void lock() {
        Prefs.setLocked(this, true);
        allowed = null;
        pinPage = false;
        graceUntil = 0;
        if (screen != null) screen.refresh();
        ensureCovered();
        if (interactive()) startTick(); else h.removeCallbacks(tick);
    }

    private void unlock() {
        Prefs.setLocked(this, false);
        allowed = null;
        pinPage = false;
        graceUntil = 0;
        h.removeCallbacks(tick);
        hideOverlay();
        hideBlocker();
    }

    private void ensureCovered() {
        showBlocker();
        if (!pinPage) showOverlay();
    }

    private void launchShortcut(int slot) {
        String pkg = Prefs.shortcut(this, slot);
        if (pkg == null) return;
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) return;
        allowed = pkg;
        allowedAt = System.currentTimeMillis();
        watchFrom = allowedAt;
        try { startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception e) { return; }
        suspendOverlay();
        startTick();
    }

    private void startKeyboardPin() {
        pinPage = true;
        try { startActivity(new Intent(this, LockActivity.class).putExtra("kb", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP)); } catch (Exception e) { pinPage = false; return; }
        h.postDelayed(() -> { if (pinPage) suspendOverlay(); }, 350); // só tira a camada depois da página aparecer
    }

    private boolean canOverlay() { return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this); }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;
    }

    private void showOverlay() {
        if (screen != null) { if (suspended) resumeOverlay(); return; }
        if (!canOverlay()) { // sem permissão de sobrepor: cai para a tela de bloqueio em Activity
            if (!interactive()) return;
            try { startActivity(new Intent(this, LockActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)); } catch (Exception ignored) { }
            return;
        }
        allowed = null;
        Point p = new Point();
        wm.getDefaultDisplay().getRealSize(p);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(p.x, p.y, overlayType(),
                // focável de propósito: só a janela com foco manda esconder a barra de baixo
                WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.OPAQUE);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        LockScreen s = new LockScreen(new ContextThemeWrapper(this, android.R.style.Theme_Holo), host);
        s.refresh();
        try {
            wm.addView(s, lp);
            screen = s;
            suspended = false;
            s.setFocusableInTouchMode(true);
            s.requestFocus();
        } catch (Exception ignored) { }
    }

    /** Remove de vez (desbloqueou ou serviço parou). */
    private void hideOverlay() {
        suspended = false;
        if (screen == null) return;
        try { wm.removeView(screen); } catch (Exception ignored) { }
        screen = null;
    }

    /** Deixa a camada montada mas invisível e sem toque, para voltar na hora (sem recriar). */
    private void suspendOverlay() {
        if (screen == null || suspended) return;
        try {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) screen.getLayoutParams();
            lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            screen.setVisibility(View.GONE);
            wm.updateViewLayout(screen, lp);
            suspended = true;
        } catch (Exception e) { hideOverlay(); }
    }

    private void resumeOverlay() {
        if (screen == null || !suspended) return;
        try {
            WindowManager.LayoutParams lp = (WindowManager.LayoutParams) screen.getLayoutParams();
            lp.flags &= ~(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
            screen.setVisibility(View.VISIBLE);
            screen.showLock();
            screen.hideBars();
            wm.updateViewLayout(screen, lp);
            screen.requestFocus();
            suspended = false;
        } catch (Exception e) { hideOverlay(); showOverlay(); }
    }

    /** Fecha a aba de notificações se alguém conseguir puxar. */
    private void collapse() {
        try {
            Object sb = getSystemService("statusbar");
            if (sb != null) sb.getClass().getMethod("collapsePanels").invoke(sb);
        } catch (Throwable ignored) { }
        if (++ticks % 4 == 0) {
            try { sendBroadcast(new Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)); } catch (Throwable ignored) { }
        }
    }

    private String foreground(long from) {
        try {
            UsageStatsManager u = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            long n = System.currentTimeMillis();
            UsageEvents ev = u.queryEvents(Math.max(n - 10000, from), n);
            UsageEvents.Event e = new UsageEvents.Event();
            String last = null;
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.getPackageName();
            }
            return last;
        } catch (Exception x) { return null; }
    }

    /** Faixa invisível sobre a barra de status (fica sempre, mesmo com app de atalho aberto). */
    private void showBlocker() {
        if (blocker != null || !canOverlay()) return;
        int sb = 0;
        int rid = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (rid > 0) sb = getResources().getDimensionPixelSize(rid);
        if (sb == 0) sb = (int) (28 * getResources().getDisplayMetrics().density);
        sb += (int) (8 * getResources().getDisplayMetrics().density);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, sb, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        View v = new View(this);
        v.setOnTouchListener((a, b) -> true);
        try { wm.addView(v, lp); blocker = v; } catch (Exception ignored) { }
    }

    private void hideBlocker() {
        if (blocker == null) return;
        try { wm.removeView(blocker); } catch (Exception ignored) { }
        blocker = null;
    }

    private Notification notif() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("pl", "PIN Locker", NotificationManager.IMPORTANCE_MIN));
            b = new Notification.Builder(this, "pl");
        } else b = new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle(L.t("active_notif")).build();
    }
}
