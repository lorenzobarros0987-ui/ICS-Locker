package com.meu.pinlocker;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** Visual Holo do app: títulos de seção em azul com fio, linhas de lista com divisor, botões e caixas padrão do Holo. */
final class Ui {
    static final int ACC = 0xFF33B5E5, SUB = 0xFFBEBEBE, DIV = 0x33FFFFFF;

    private Ui() { }

    static int dp(Context c, float v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }

    private static StateListDrawable press() {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, new ColorDrawable(0x6633B5E5));
        s.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        return s;
    }

    /** Página rolável; devolve a coluna onde entram as seções. */
    static LinearLayout page(Activity a) {
        ScrollView sv = new ScrollView(a);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(a, 14), dp(a, 8), dp(a, 14), dp(a, 24));
        sv.addView(col);
        a.setContentView(sv);
        return col;
    }

    /** Seção: título em azul com fio azul embaixo (como as divisões do Holo). Título nulo = só um espaço. */
    static LinearLayout card(Context c, LinearLayout col, String title) {
        if (title != null) {
            TextView t = new TextView(c);
            t.setText(title.toUpperCase());
            t.setTextColor(ACC);
            t.setTextSize(14);
            t.setPadding(dp(c, 4), dp(c, 22), 0, dp(c, 4));
            col.addView(t);
            View line = new View(c);
            line.setBackgroundColor(ACC);
            col.addView(line, new LinearLayout.LayoutParams(-1, dp(c, 2)));
        }
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        if (title == null) lp.topMargin = dp(c, 8);
        col.addView(box, lp);
        return box;
    }

    private static void divider(Context c, LinearLayout box) {
        View d = new View(c);
        d.setBackgroundColor(DIV);
        box.addView(d, new LinearLayout.LayoutParams(-1, 1));
    }

    private static TextView text(Context c, String s, int sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    /** Linha de lista: título e valor; com listener fica clicável e, se houver, mostra um botão extra à direita. */
    static TextView item(Context c, LinearLayout box, String title, String value, View.OnClickListener l, String act, View.OnClickListener al) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(c, 6), dp(c, 10), dp(c, 6), dp(c, 10));
        row.setMinimumHeight(dp(c, 56));
        LinearLayout left = new LinearLayout(c);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(c, title, 18, Color.WHITE));
        TextView v = text(c, value == null ? "" : value, 14, SUB);
        v.setVisibility(value == null || value.isEmpty() ? View.GONE : View.VISIBLE);
        left.addView(v);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        if (act != null) {
            Button b = new Button(c);
            b.setText(act);
            b.setTextSize(13);
            b.setFocusable(false);
            b.setOnClickListener(al);
            row.addView(b, new LinearLayout.LayoutParams(-2, -2));
        }
        if (l != null) { row.setBackground(press()); row.setOnClickListener(l); }
        box.addView(row, new LinearLayout.LayoutParams(-1, -2));
        divider(c, box);
        return v;
    }

    static TextView item(Context c, LinearLayout box, String title, String value, View.OnClickListener l) {
        return item(c, box, title, value, l, null, null);
    }

    static CompoundButton toggle(Context c, LinearLayout box, String title, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        CheckBox cb = new CheckBox(c);
        cb.setText(title);
        cb.setTextSize(18);
        cb.setChecked(on);
        cb.setOnCheckedChangeListener(l);
        cb.setPadding(dp(c, 6), dp(c, 12), dp(c, 6), dp(c, 12));
        box.addView(cb, new LinearLayout.LayoutParams(-1, -2));
        if (sub != null) {
            TextView s = text(c, sub, 14, SUB);
            s.setPadding(dp(c, 6), 0, dp(c, 6), dp(c, 10));
            box.addView(s);
        }
        divider(c, box);
        return cb;
    }

    /** Botões Holo lado a lado (ex.: Definir / Remover). */
    static void actions(Context c, LinearLayout box, String[] labels, View.OnClickListener[] ls) {
        LinearLayout row = new LinearLayout(c);
        for (int i = 0; i < labels.length; i++) {
            Button b = new Button(c);
            b.setText(labels[i]);
            b.setOnClickListener(ls[i]);
            row.addView(b, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(c, 4);
        box.addView(row, lp);
    }

    static void action(Context c, LinearLayout box, String label, View.OnClickListener l) {
        actions(c, box, new String[]{label}, new View.OnClickListener[]{l});
    }

    /** Controle deslizante com o valor à direita. */
    static void seek(Context c, LinearLayout box, String title, int min, int max, int cur, String suffix, java.util.function.IntConsumer on) {
        LinearLayout top = new LinearLayout(c);
        top.setPadding(dp(c, 6), dp(c, 12), dp(c, 6), 0);
        top.addView(text(c, title, 18, Color.WHITE), new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = text(c, cur + suffix, 16, ACC);
        top.addView(val);
        box.addView(top);
        SeekBar s = new SeekBar(c);
        s.setMax(max - min);
        s.setProgress(cur - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { val.setText((p + min) + suffix); on.accept(p + min); }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        box.addView(s, new LinearLayout.LayoutParams(-1, -2));
        divider(c, box);
    }
}
