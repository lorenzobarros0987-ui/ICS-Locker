package com.meu.pinlocker;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Visual do app: fundo escuro, seções em cartões, linhas com título + valor, interruptores e botões de texto em azul. */
final class Ui {
    static final int BG = 0xFF0D1217, CARD = 0xFF171F26, DIV = 0x1AFFFFFF, ACC = 0xFF33B5E5, SUB = 0xFF9AA7B0;

    private Ui() { }

    static int dp(Context c, float v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }

    private static GradientDrawable round(int color, float r, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, r));
        return g;
    }

    private static StateListDrawable press(Context c, int base) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, round(0x33FFFFFF, 0, c));
        s.addState(new int[]{}, round(Color.TRANSPARENT, 0, c));
        return s;
    }

    /** Página rolável com o fundo escuro; devolve a coluna onde entram os cartões. */
    static LinearLayout page(Activity a) {
        a.getWindow().getDecorView().setBackgroundColor(BG);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            a.getWindow().setStatusBarColor(BG);
            a.getWindow().setNavigationBarColor(BG);
        }
        ScrollView sv = new ScrollView(a);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(a, 14), dp(a, 10), dp(a, 14), dp(a, 28));
        sv.addView(col);
        a.setContentView(sv);
        return col;
    }

    /** Cartão com título pequeno em azul acima dele (título nulo = cartão sem título). */
    static LinearLayout card(Context c, LinearLayout col, String title) {
        if (title != null) {
            TextView t = new TextView(c);
            t.setText(title.toUpperCase());
            t.setTextColor(ACC);
            t.setTextSize(12);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setLetterSpacing(0.08f);
            t.setPadding(dp(c, 6), dp(c, 20), 0, dp(c, 8));
            col.addView(t);
        }
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(round(CARD, 12, c));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        if (title == null) lp.topMargin = dp(c, 10);
        col.addView(card, lp);
        return card;
    }

    private static void divider(Context c, LinearLayout card) {
        if (card.getChildCount() == 0) return;
        View d = new View(c);
        d.setBackgroundColor(DIV);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 1);
        lp.leftMargin = dp(c, 16);
        card.addView(d, lp);
    }

    private static TextView text(Context c, String s, int sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    /** Linha com título e valor; com listener vira clicável (seta à direita) e, se houver, mostra uma ação extra em azul. */
    static TextView item(Context c, LinearLayout card, String title, String value, View.OnClickListener l, String act, View.OnClickListener al) {
        divider(c, card);
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(c, 16), dp(c, 13), dp(c, 12), dp(c, 13));
        row.setMinimumHeight(dp(c, 56));
        LinearLayout left = new LinearLayout(c);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(c, title, 16, Color.WHITE));
        TextView v = text(c, value == null ? "" : value, 13, SUB);
        v.setPadding(0, dp(c, 2), 0, 0);
        v.setVisibility(value == null || value.isEmpty() ? View.GONE : View.VISIBLE);
        left.addView(v);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        if (act != null) {
            TextView a = text(c, act, 14, ACC);
            a.setTypeface(Typeface.DEFAULT_BOLD);
            a.setPadding(dp(c, 14), dp(c, 8), dp(c, 8), dp(c, 8));
            a.setOnClickListener(al);
            row.addView(a);
        } else if (l != null) {
            row.addView(text(c, "\u203A", 24, SUB));
        }
        if (l != null) { row.setBackground(press(c, CARD)); row.setOnClickListener(l); }
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return v;
    }

    static TextView item(Context c, LinearLayout card, String title, String value, View.OnClickListener l) {
        return item(c, card, title, value, l, null, null);
    }

    static Switch toggle(Context c, LinearLayout card, String title, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        divider(c, card);
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(c, 16), dp(c, 10), dp(c, 14), dp(c, 10));
        row.setMinimumHeight(dp(c, 56));
        LinearLayout left = new LinearLayout(c);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(c, title, 16, Color.WHITE));
        if (sub != null) { TextView s = text(c, sub, 13, SUB); s.setPadding(0, dp(c, 2), 0, 0); left.addView(s); }
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        final Switch sw = new Switch(c);
        sw.setChecked(on);
        sw.setOnCheckedChangeListener(l);
        row.addView(sw);
        row.setBackground(press(c, CARD));
        row.setOnClickListener(v -> sw.toggle());
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return sw;
    }

    /** Linha de botões de texto lado a lado (ex.: Definir / Remover). */
    static void actions(Context c, LinearLayout card, String[] labels, View.OnClickListener[] ls) {
        divider(c, card);
        LinearLayout row = new LinearLayout(c);
        for (int i = 0; i < labels.length; i++) {
            if (i > 0) {
                View d = new View(c);
                d.setBackgroundColor(DIV);
                row.addView(d, new LinearLayout.LayoutParams(1, -1));
            }
            TextView t = text(c, labels[i], 14, ACC);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(c, 8), dp(c, 15), dp(c, 8), dp(c, 15));
            t.setBackground(press(c, CARD));
            t.setOnClickListener(ls[i]);
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    static void action(Context c, LinearLayout card, String label, View.OnClickListener l) {
        actions(c, card, new String[]{label}, new View.OnClickListener[]{l});
    }

    /** Controle deslizante com o valor à direita. */
    static void seek(Context c, LinearLayout card, String title, int min, int max, int cur, String suffix, java.util.function.IntConsumer on) {
        divider(c, card);
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 10));
        LinearLayout top = new LinearLayout(c);
        top.addView(text(c, title, 16, Color.WHITE), new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView val = text(c, cur + suffix, 14, ACC);
        top.addView(val);
        box.addView(top);
        SeekBar s = new SeekBar(c);
        s.setMax(max - min);
        s.setProgress(cur - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) { val.setText((p + min) + suffix); on.accept(p + min); }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        box.addView(s);
        card.addView(box, new LinearLayout.LayoutParams(-1, -2));
    }
}
