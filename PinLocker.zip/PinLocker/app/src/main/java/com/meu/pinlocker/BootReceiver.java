package com.meu.pinlocker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Liga o bloqueio junto com o sistema (e depois de atualizar o app). */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (!Prefs.enabled(c)) return;
        if (!Intent.ACTION_MY_PACKAGE_REPLACED.equals(i.getAction())) Prefs.setLocked(c, true);
        start(c);
    }

    static void start(Context c) {
        try {
            Intent s = new Intent(c, LockService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
        } catch (Exception ignored) { }
    }
}
