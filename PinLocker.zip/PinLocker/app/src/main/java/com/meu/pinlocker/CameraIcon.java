package com.meu.pinlocker;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/**
 * Ícone de câmera do Android 4.0 (ICS), redesenhado em vetor a partir do original: mesmas proporções
 * (canto superior esquerdo arredondado, botãozinho, visor e lente com anel). Nítido em qualquer tamanho (HD).
 * Grade de desenho: x 2.3..37.7, y 2.7..29.8.
 */
class CameraIcon extends Drawable {
    private static final float VX = 2.3f, VY = 2.7f, VW = 35.4f, VH = 27.1f;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path body = new Path(), extras = new Path();

    CameraIcon() {
        p.setColor(0xFFFFFFFF);
        p.setStyle(Paint.Style.FILL);
        body.setFillType(Path.FillType.EVEN_ODD);
        body.moveTo(9.2f, 6.3f);
        body.lineTo(36.3f, 6.3f);
        body.quadTo(37.5f, 6.3f, 37.5f, 7.5f);
        body.lineTo(37.5f, 28.4f);
        body.quadTo(37.5f, 29.6f, 36.3f, 29.6f);
        body.lineTo(3.7f, 29.6f);
        body.quadTo(2.5f, 29.6f, 2.5f, 28.4f);
        body.lineTo(2.5f, 10.8f);
        body.cubicTo(2.5f, 8.2f, 5.6f, 6.3f, 9.2f, 6.3f); // canto superior esquerdo bem arredondado
        body.close();
        body.addCircle(20f, 17.3f, 9.1f, Path.Direction.CW); // vão da lente
        body.addCircle(20f, 17.3f, 6.4f, Path.Direction.CW); // lente (preenchida)
        extras.addRoundRect(new RectF(15f, 2.7f, 25.4f, 6.6f), 0.8f, 0.8f, Path.Direction.CW);   // visor
        extras.addRoundRect(new RectF(4.4f, 3.6f, 9.4f, 5.9f), 1f, 1f, Path.Direction.CW);       // botãozinho
    }

    @Override public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        c.save();
        c.translate(b.left, b.top);
        c.scale(b.width() / VW, b.height() / VH);
        c.translate(-VX, -VY);
        c.drawPath(body, p);
        c.drawPath(extras, p);
        c.restore();
    }

    @Override public int getIntrinsicWidth() { return 177; }
    @Override public int getIntrinsicHeight() { return 136; }
    @Override public void setAlpha(int a) { p.setAlpha(a); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter f) { p.setColorFilter(f); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
