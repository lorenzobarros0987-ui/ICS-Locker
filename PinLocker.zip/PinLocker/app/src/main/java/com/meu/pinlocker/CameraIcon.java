package com.meu.pinlocker;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

/** Ícone de câmera desenhado em código (branco, como no Android 4.0), nítido em qualquer tamanho. */
class CameraIcon extends Drawable {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    CameraIcon() {
        p.setColor(0xFFFFFFFF);
        p.setStyle(Paint.Style.FILL);
        path.setFillType(Path.FillType.EVEN_ODD); // grade 24 x 20
        path.addRoundRect(0f, 4f, 24f, 20f, 2.2f, 2.2f, Path.Direction.CW);       // corpo
        path.moveTo(7.5f, 4f); path.lineTo(9.2f, 0.8f); path.lineTo(14.8f, 0.8f); path.lineTo(16.5f, 4f); path.close(); // visor
        path.addCircle(12f, 12.2f, 5.6f, Path.Direction.CW);                       // vão da lente
        path.addCircle(12f, 12.2f, 3.7f, Path.Direction.CW);                       // lente
    }

    @Override public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        c.save();
        c.translate(b.left, b.top);
        c.scale(b.width() / 24f, b.height() / 20f);
        c.drawPath(path, p);
        c.restore();
    }

    @Override public int getIntrinsicWidth() { return 120; }
    @Override public int getIntrinsicHeight() { return 100; }
    @Override public void setAlpha(int a) { p.setAlpha(a); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter f) { p.setColorFilter(f); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
