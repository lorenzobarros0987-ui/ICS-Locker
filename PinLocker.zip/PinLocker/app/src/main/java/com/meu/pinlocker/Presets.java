package com.meu.pinlocker;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import java.util.List;

/** Atalhos prontos, como no Holo Locker original: Telefone, Mensagens, Câmera, Navegador etc. */
final class Presets {
    static final String[] PT = {"Telefone", "Mensagens", "Câmera", "Navegador", "Galeria", "E-mail", "Contatos", "Música", "Calendário", "Mapas", "Relógio / Alarme", "Calculadora"};
    static final String[] EN = {"Phone", "Messages", "Camera", "Browser", "Gallery", "Email", "Contacts", "Music", "Calendar", "Maps", "Clock / Alarm", "Calculator"};

    static String[] names() { return L.isEn() ? EN : PT; }

    private static Intent main(String cat) { return new Intent(Intent.ACTION_MAIN).addCategory(cat); }

    static Intent intent(int i) {
        switch (i) {
            case 0: return new Intent(Intent.ACTION_DIAL);
            case 1: return main(Intent.CATEGORY_APP_MESSAGING);
            case 2: return new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
            case 3: return main(Intent.CATEGORY_APP_BROWSER);
            case 4: return main(Intent.CATEGORY_APP_GALLERY);
            case 5: return main(Intent.CATEGORY_APP_EMAIL);
            case 6: return main(Intent.CATEGORY_APP_CONTACTS);
            case 7: return main(Intent.CATEGORY_APP_MUSIC);
            case 8: return main(Intent.CATEGORY_APP_CALENDAR);
            case 9: return main(Intent.CATEGORY_APP_MAPS);
            case 10: return new Intent(AlarmClock.ACTION_SHOW_ALARMS);
            default: return main(Intent.CATEGORY_APP_CALCULATOR);
        }
    }

    /** Pacote do app padrão para o atalho pronto; null se o celular não tiver. */
    static String resolve(Context c, int i) {
        PackageManager pm = c.getPackageManager();
        Intent in = intent(i);
        ResolveInfo def = pm.resolveActivity(in, 0);
        if (def != null && def.activityInfo != null && !"android".equals(def.activityInfo.packageName)) return def.activityInfo.packageName;
        List<ResolveInfo> l = pm.queryIntentActivities(in, 0);
        for (ResolveInfo r : l) if (!"android".equals(r.activityInfo.packageName)) return r.activityInfo.packageName;
        return null;
    }
}
