package com.meu.pinlocker;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.text.InputType;
import android.text.InputFilter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private TextView status;
    private final Button[] scBtn = new Button[4], permBtn = new Button[6];
    private static final String[] PERM_KEYS = {"perm1", "perm2", "perm3", "perm4", "perm5", "perm6"};
    private static final String[] SC_SHORT = {"sc_left_s", "sc_right_s", "sc_ul_s", "sc_ur_s"};

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        L.init(this);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(12), dp(16), dp(28));
        sv.addView(col);

        TextView title = new TextView(this);
        title.setText("PIN Locker");
        title.setTextSize(32);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Fonts.date(this));
        col.addView(title);
        status = new TextView(this);
        status.setPadding(0, dp(2), 0, dp(4));
        col.addView(status);

        head(col, L.t("h_lock"));
        LinearLayout lr = new LinearLayout(this);
        add(lr, L.t("enable"), v -> {
            Prefs.setEnabled(this, true);
            Prefs.setLocked(this, false);
            Intent s = new Intent(this, LockService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
            Toast.makeText(this, L.t("enabled_toast") + (Look.hasAuth(this) ? "" : "\n" + L.t("no_pin_warn")), Toast.LENGTH_LONG).show();
            refresh();
        }, 1f);
        add(lr, L.t("disable"), v -> {
            Prefs.setEnabled(this, false);
            Prefs.setLocked(this, false);
            stopService(new Intent(this, LockService.class));
            refresh();
        }, 1f);
        col.addView(lr);
        final CheckBox bp = new CheckBox(this);
        bp.setText(L.t("block_power"));
        bp.setChecked(Look.b(this, "blockPower", false));
        bp.setOnCheckedChangeListener((v, on) -> {
            if (!on) { Look.setB(this, "blockPower", false); return; }
            if (Look.b(this, "blockPower", false)) return;
            bp.setChecked(false); // só liga depois do PIN
            if (!Prefs.hasPin(this)) { Toast.makeText(this, L.t("pin_set_first"), Toast.LENGTH_LONG).show(); return; }
            final EditText e = field(L.t("pin_current"));
            LinearLayout box = new LinearLayout(this);
            box.setPadding(dp(20), dp(8), dp(20), 0);
            box.addView(e);
            new AlertDialog.Builder(this).setTitle(L.t("block_power")).setView(box).setNegativeButton(L.t("cancel"), null)
                    .setPositiveButton(L.t("ok"), (d, w) -> {
                        if (Prefs.check(this, e.getText().toString())) { Look.setB(this, "blockPower", true); bp.setChecked(true); }
                        else Toast.makeText(this, L.t("pin_wrong"), Toast.LENGTH_SHORT).show();
                    }).show();
        });
        col.addView(bp);

        head(col, L.t("m_pin"));
        LinearLayout pr = new LinearLayout(this);
        add(pr, L.t("set_pin"), v -> pinDialog(), 1f);
        add(pr, L.t("remove_pin"), v -> removePin(), 1f);
        col.addView(pr);
        LinearLayout pt = new LinearLayout(this);
        add(pt, L.t("set_pattern"), v -> patternDialog(), 1f);
        add(pt, L.t("remove_pattern"), v -> removePattern(), 1f);
        col.addView(pt);

        head(col, L.t("m_shortcuts"));
        for (int i = 0; i < SC_SHORT.length; i++) {
            final int slot = i;
            LinearLayout r = new LinearLayout(this);
            scBtn[i] = add(r, "", v -> pickApp(slot), 3f);
            add(r, L.t("photo_btn"), v -> photoMenu(slot), 1f);
            col.addView(r);
        }

        head(col, L.t("h_bg"));
        btn(col, L.t("appearance"), v -> startActivity(new Intent(this, AppearanceActivity.class)));

        head(col, L.t("m_perms"));
        for (int i = 0; i < PERM_KEYS.length; i++) permBtn[i] = btn(col, L.t(PERM_KEYS[i]), null);
        permBtn[0].setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        permBtn[1].setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
        permBtn[2].setOnClickListener(v -> startActivity(new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(this, AdminReceiver.class))
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, L.t("admin_expl"))));
        permBtn[3].setOnClickListener(v -> { if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 2); });
        permBtn[5].setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        permBtn[4].setOnClickListener(v -> startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));

        head(col, L.t("m_general"));
        btn(col, L.t("language") + ": " + L.LANG_N[Look.idxd(this, "lang", 3, 0)], v -> pickLang());
        btn(col, L.t("credits"), v -> new android.app.AlertDialog.Builder(this)
                .setTitle(L.t("credits")).setMessage(L.t("credits_text")).setPositiveButton(L.t("ok"), null).show());

        head(col, L.t("m_howto"));
        TextView hint = new TextView(this);
        hint.setText(L.t("hint"));
        hint.setTextColor(0xFFB0B0B0);
        col.addView(hint);
        setContentView(sv);
    }

    /** Título de seção no estilo Holo: texto azul em caixa alta com fio embaixo. */
    private void head(LinearLayout col, String t) {
        TextView v = new TextView(this);
        v.setText(t.toUpperCase());
        v.setTextColor(0xFF33B5E5);
        v.setTextSize(13);
        v.setPadding(dp(2), dp(20), 0, dp(4));
        col.addView(v);
        View line = new View(this);
        line.setBackgroundColor(0xFF33B5E5);
        col.addView(line, new LinearLayout.LayoutParams(-1, dp(2)));
    }

    private Button btn(LinearLayout col, String t, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(t);
        x.setOnClickListener(l);
        col.addView(x);
        return x;
    }

    /** Botão dentro de uma linha horizontal, com peso. */
    private Button add(LinearLayout row, String t, View.OnClickListener l, float w) {
        Button x = new Button(this);
        x.setText(t);
        x.setOnClickListener(l);
        row.addView(x, new LinearLayout.LayoutParams(0, -2, w));
        return x;
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private String label(String pkg) {
        if (pkg == null) return L.t("none").replace("(", "").replace(")", "");
        try { PackageManager pm = getPackageManager(); return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return pkg; }
    }

    private boolean usageOk() {
        AppOpsManager a = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }

    private void refresh() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        status.setText(L.t("p_status") + (Prefs.hasPin(this) ? L.t("defined") : L.t("notdefined"))
                + "\n" + L.t("p_pattern") + (Prefs.hasPattern(this) ? L.t("defined") : L.t("notdefined"))
                + "\n" + L.t("lock") + (Prefs.enabled(this) ? L.t("on") : L.t("off")));
        for (int i = 0; i < SC_SHORT.length; i++) scBtn[i].setText(L.t(SC_SHORT[i]) + ": " + label(Prefs.shortcut(this, i)));
        boolean[] ok = {Settings.canDrawOverlays(this), usageOk(), dpm.isAdminActive(new ComponentName(this, AdminReceiver.class)),
                Build.VERSION.SDK_INT < 23 || Build.VERSION.SDK_INT >= 33 || checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED,
                notifOk(), accOk()};
        for (int i = 0; i < permBtn.length; i++) permBtn[i].setText(L.t(PERM_KEYS[i]) + (ok[i] ? "   \u2714" : "   \u2716"));
    }

    private boolean accOk() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(getPackageName());
    }

    private boolean notifOk() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private void pinDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText a = field(L.t("new_pin")), c = field(L.t("repeat_pin"));
        l.addView(a);
        l.addView(c);
        new AlertDialog.Builder(this).setTitle("PIN").setView(l).setNegativeButton(L.t("cancel"), null)
                .setPositiveButton(L.t("save"), (d, w) -> {
                    String p = a.getText().toString();
                    if (p.length() < 4 || !p.equals(c.getText().toString())) {
                        Toast.makeText(this, L.t("pin_invalid"), Toast.LENGTH_LONG).show();
                        return;
                    }
                    Prefs.setPin(this, p);
                    refresh();
                }).show();
    }

    /** Define o padrão: desenha duas vezes (mínimo 4 pontos), na própria grade do 4.0.4. */
    private void patternDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(0xFF1A1A1A);
        l.setPadding(dp(16), dp(16), dp(16), dp(8));
        final TextView m = new TextView(this);
        m.setTextColor(Color.WHITE);
        m.setTextSize(16);
        m.setGravity(android.view.Gravity.CENTER);
        m.setText(L.t("pat_new"));
        l.addView(m, new LinearLayout.LayoutParams(-1, -2));
        final PatternView pv = new PatternView(this);
        int s = Math.min(dp(300), getResources().getDisplayMetrics().widthPixels - dp(72));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(s, s);
        pl.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        pl.topMargin = dp(12);
        l.addView(pv, pl);
        final String[] first = new String[1];
        final AlertDialog dlg = new AlertDialog.Builder(this).setView(l).setNegativeButton(L.t("cancel"), null).create();
        pv.setListener(seq -> {
            if (seq.length() < 4) { m.setText(L.t("pat_short")); pv.showWrong(); return; }
            if (first[0] == null) { first[0] = seq; m.setText(L.t("pat_confirm")); pv.clearAfter(600); return; }
            if (first[0].equals(seq)) {
                Prefs.setPattern(this, seq);
                Look.setI(this, "unlockMode", 1);
                dlg.dismiss();
                Toast.makeText(this, L.t("pat_saved"), Toast.LENGTH_SHORT).show();
                refresh();
            } else { first[0] = null; m.setText(L.t("pat_mismatch")); pv.showWrong(); }
        });
        dlg.show();
    }

    private void removePattern() {
        new AlertDialog.Builder(this).setMessage(L.t("remove_pattern_q")).setNegativeButton(L.t("no"), null)
                .setPositiveButton(L.t("yes"), (d, w) -> {
                    Prefs.clearPattern(this);
                    Look.setI(this, "unlockMode", 0);
                    Toast.makeText(this, L.t("pat_removed"), Toast.LENGTH_SHORT).show();
                    refresh();
                }).show();
    }

    private void removePin() {
        new AlertDialog.Builder(this).setMessage(L.t("remove_pin_q")).setNegativeButton(L.t("no"), null)
                .setPositiveButton(L.t("yes"), (d, w) -> {
                    Prefs.clearPin(this);
                    Toast.makeText(this, L.t("pin_removed"), Toast.LENGTH_SHORT).show();
                    refresh();
                }).show();
    }

    private void pickLang() {
        new AlertDialog.Builder(this).setTitle(L.t("language"))
                .setSingleChoiceItems(L.LANG_N, Look.idxd(this, "lang", 3, 0), (d, w) -> { Look.setI(this, "lang", w); d.dismiss(); recreate(); }).show();
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        return e;
    }

    /** Escolha do atalho: atalhos prontos do Holo Locker original ou qualquer app. */
    private void pickApp(final int slot) {
        final String[] pre = Presets.names();
        String[] names = new String[pre.length + 2];
        names[0] = L.t("none");
        for (int i = 0; i < pre.length; i++) names[i + 1] = pre[i];
        names[pre.length + 1] = L.t("choose_app") + "...";
        new AlertDialog.Builder(this).setTitle(L.t("shortcut_presets")).setItems(names, (d, w) -> {
            if (w == 0) { Prefs.setShortcut(this, slot, null); refresh(); }
            else if (w == pre.length + 1) pickAnyApp(slot);
            else {
                String pkg = Presets.resolve(this, w - 1);
                if (pkg == null) Toast.makeText(this, names[w] + ": -", Toast.LENGTH_SHORT).show();
                else { Prefs.setShortcut(this, slot, pkg); refresh(); }
            }
        }).show();
    }

    private void pickAnyApp(final int slot) {
        PackageManager pm = getPackageManager();
        final List<ResolveInfo> l = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
        Collections.sort(l, new ResolveInfo.DisplayNameComparator(pm));
        String[] names = new String[l.size()];
        for (int i = 0; i < l.size(); i++) names[i] = l.get(i).loadLabel(pm).toString();
        new AlertDialog.Builder(this).setTitle(L.t("choose_app")).setItems(names, (d, w) -> {
            Prefs.setShortcut(this, slot, l.get(w).activityInfo.packageName);
            refresh();
        }).show();
    }

    /** Foto personalizada para o atalho (aparece no lugar do ícone do app). */
    private void photoMenu(final int slot) {
        new AlertDialog.Builder(this).setTitle(L.t("shortcut_photo"))
                .setItems(new String[]{L.t("change_photo_short"), L.t("photo_remove")}, (d, w) -> {
                    if (w == 0) startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 10 + slot);
                    else { Prefs.scPhoto(this, slot).delete(); refresh(); }
                }).show();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req >= 10 && req <= 13 && res == RESULT_OK && data != null && data.getData() != null) {
            try { savePhoto(data.getData(), req - 10); }
            catch (Exception e) { Toast.makeText(this, L.t("photo_fail"), Toast.LENGTH_LONG).show(); }
            refresh();
        }
    }

    private void savePhoto(Uri u, int slot) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 600) s *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = s;
        Bitmap bmp;
        try (InputStream in = getContentResolver().openInputStream(u)) { bmp = BitmapFactory.decodeStream(in, null, o); }
        try (FileOutputStream f = new FileOutputStream(Prefs.scPhoto(this, slot))) { bmp.compress(Bitmap.CompressFormat.PNG, 100, f); }
    }
}
