package com.meu.pinlocker;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.text.InputType;
import android.text.InputFilter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private TextView status;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        L.init(this);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(16), dp(16), dp(16));
        sv.addView(col);

        TextView hint = new TextView(this);
        hint.setText(L.t("hint"));
        col.addView(hint);
        status = new TextView(this);
        status.setPadding(0, dp(12), 0, dp(12));
        col.addView(status);

        btn(col, L.t("set_pin"), v -> pinDialog());
        btn(col, L.t("remove_pin"), v -> removePin());
        btn(col, L.t("sc_left"), v -> pickApp(0));
        btn(col, L.t("sc_right"), v -> pickApp(1));
        btn(col, L.t("photo_left"), v -> photoMenu(0));
        btn(col, L.t("photo_right"), v -> photoMenu(1));
        btn(col, L.t("appearance"), v -> startActivity(new Intent(this, AppearanceActivity.class)));
        btn(col, L.t("perm1"), v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        btn(col, L.t("perm2"), v -> startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
        btn(col, L.t("perm3"), v -> startActivity(new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(this, AdminReceiver.class))
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, L.t("admin_expl"))));
        btn(col, L.t("perm4"), v -> {
            if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 2);
        });
        btn(col, L.t("enable"), v -> {
            Prefs.setEnabled(this, true);
            Prefs.setLocked(this, false);
            Intent s = new Intent(this, LockService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
            Toast.makeText(this, L.t("enabled_toast") + (Prefs.hasPin(this) ? "" : "\n" + L.t("no_pin_warn")), Toast.LENGTH_LONG).show();
        });
        btn(col, L.t("disable"), v -> {
            Prefs.setEnabled(this, false);
            Prefs.setLocked(this, false);
            stopService(new Intent(this, LockService.class));
        });
        btn(col, L.t("language") + ": " + L.LANG_N[Look.idxd(this, "lang", 3, 0)], v -> pickLang());
        setContentView(sv);
    }

    private void btn(LinearLayout col, String t, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(t);
        x.setOnClickListener(l);
        col.addView(x);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private String label(String pkg) {
        if (pkg == null) return L.t("none").replace("(", "").replace(")", "");
        try { PackageManager pm = getPackageManager(); return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return pkg; }
    }

    private boolean usageOk() {
        AppOpsManager a = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }

    private void refresh() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        status.setText(L.t("p_status") + (Prefs.hasPin(this) ? L.t("defined") : L.t("notdefined"))
                + "\n" + L.t("overlay") + (Settings.canDrawOverlays(this) ? L.t("okk") : L.t("missing"))
                + "\n" + L.t("usage") + (usageOk() ? L.t("okk") : L.t("missing"))
                + "\n" + L.t("admin") + (dpm.isAdminActive(new ComponentName(this, AdminReceiver.class)) ? L.t("active") : L.t("inactive"))
                + "\n" + L.t("sc_left_s") + ": " + label(Prefs.shortcut(this, 0))
                + "\n" + L.t("sc_right_s") + ": " + label(Prefs.shortcut(this, 1))
                + "\n" + L.t("clock_font") + Fonts.NAMES[Fonts.index(this)]
                + "\n" + L.t("lock") + (Prefs.enabled(this) ? L.t("on") : L.t("off")));
    }

    private void pinDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText a = field(L.t("new_pin")), c = field(L.t("repeat_pin"));
        l.addView(a);
        l.addView(c);
        new AlertDialog.Builder(this).setTitle("PIN").setView(l).setNegativeButton(L.t("cancel"), null)
                .setPositiveButton(L.t("save"), (d, w) -> {
                    String p = a.getText().toString();
                    if (p.length() < 4 || !p.equals(c.getText().toString())) {
                        Toast.makeText(this, L.t("pin_invalid"), Toast.LENGTH_LONG).show();
                        return;
                    }
                    Prefs.setPin(this, p);
                    refresh();
                }).show();
    }

    private void removePin() {
        new AlertDialog.Builder(this).setMessage(L.t("remove_pin_q")).setNegativeButton(L.t("no"), null)
                .setPositiveButton(L.t("yes"), (d, w) -> {
                    Prefs.clearPin(this);
                    Toast.makeText(this, L.t("pin_removed"), Toast.LENGTH_SHORT).show();
                    refresh();
                }).show();
    }

    private void pickLang() {
        new AlertDialog.Builder(this).setTitle(L.t("language"))
                .setSingleChoiceItems(L.LANG_N, Look.idxd(this, "lang", 3, 0), (d, w) -> { Look.setI(this, "lang", w); d.dismiss(); recreate(); }).show();
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        return e;
    }

    /** Escolha do atalho: atalhos prontos do Holo Locker original ou qualquer app. */
    private void pickApp(final int slot) {
        final String[] pre = Presets.names();
        String[] names = new String[pre.length + 2];
        names[0] = L.t("none");
        for (int i = 0; i < pre.length; i++) names[i + 1] = pre[i];
        names[pre.length + 1] = L.t("choose_app") + "...";
        new AlertDialog.Builder(this).setTitle(L.t("shortcut_presets")).setItems(names, (d, w) -> {
            if (w == 0) { Prefs.setShortcut(this, slot, null); refresh(); }
            else if (w == pre.length + 1) pickAnyApp(slot);
            else {
                String pkg = Presets.resolve(this, w - 1);
                if (pkg == null) Toast.makeText(this, names[w] + ": -", Toast.LENGTH_SHORT).show();
                else { Prefs.setShortcut(this, slot, pkg); refresh(); }
            }
        }).show();
    }

    private void pickAnyApp(final int slot) {
        PackageManager pm = getPackageManager();
        final List<ResolveInfo> l = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
        Collections.sort(l, new ResolveInfo.DisplayNameComparator(pm));
        String[] names = new String[l.size()];
        for (int i = 0; i < l.size(); i++) names[i] = l.get(i).loadLabel(pm).toString();
        new AlertDialog.Builder(this).setTitle(L.t("choose_app")).setItems(names, (d, w) -> {
            Prefs.setShortcut(this, slot, l.get(w).activityInfo.packageName);
            refresh();
        }).show();
    }

    /** Foto personalizada para o atalho (aparece no lugar do ícone do app). */
    private void photoMenu(final int slot) {
        new AlertDialog.Builder(this).setTitle(L.t("shortcut_photo"))
                .setItems(new String[]{L.t("change_photo_short"), L.t("photo_remove")}, (d, w) -> {
                    if (w == 0) startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 10 + slot);
                    else { Prefs.scPhoto(this, slot).delete(); refresh(); }
                }).show();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if ((req == 10 || req == 11) && res == RESULT_OK && data != null && data.getData() != null) {
            try { savePhoto(data.getData(), req - 10); }
            catch (Exception e) { Toast.makeText(this, L.t("photo_fail"), Toast.LENGTH_LONG).show(); }
            refresh();
        }
    }

    private void savePhoto(Uri u, int slot) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 600) s *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = s;
        Bitmap bmp;
        try (InputStream in = getContentResolver().openInputStream(u)) { bmp = BitmapFactory.decodeStream(in, null, o); }
        try (FileOutputStream f = new FileOutputStream(Prefs.scPhoto(this, slot))) { bmp.compress(Bitmap.CompressFormat.PNG, 100, f); }
    }
}
