package com.meu.pinlocker;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.text.InputType;
import android.text.InputFilter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private TextView status;
    private final TextView[] scVal = new TextView[4];
    private TextView permVal, methodVal, secVal;
    private android.widget.Switch enableSw;
    private static final String[] PERM_KEYS = {"perm1", "perm2", "perm3", "perm4", "perm5", "perm6"};
    private static final String[] SC_SHORT = {"sc_left_s", "sc_right_s", "sc_ul_s", "sc_ur_s"};

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        L.init(this);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        LinearLayout col = Ui.page(this);

        // cabeçalho: nome, estado e o interruptor que liga/desliga o bloqueio
        LinearLayout hc = Ui.card(this, col, null);
        LinearLayout hr = new LinearLayout(this);
        hr.setGravity(android.view.Gravity.CENTER_VERTICAL);
        hr.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16));
        LinearLayout hl = new LinearLayout(this);
        hl.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("PIN Locker");
        title.setTextSize(30);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Fonts.date(this));
        hl.addView(title);
        status = new TextView(this);
        status.setTextColor(Ui.SUB);
        status.setTextSize(13);
        status.setPadding(0, Ui.dp(this, 4), 0, 0);
        hl.addView(status);
        hr.addView(hl, new LinearLayout.LayoutParams(0, -2, 1f));
        enableSw = new android.widget.Switch(this);
        hr.addView(enableSw);
        hc.addView(hr);
        enableSw.setOnCheckedChangeListener((v, on) -> {
            if (!v.isPressed()) return;
            Prefs.setEnabled(this, on);
            Prefs.setLocked(this, false);
            if (on) {
                Intent si = new Intent(this, LockService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(si); else startService(si);
                Toast.makeText(this, L.t("enabled_toast") + (Look.hasAuth(this) ? "" : "\n" + L.t("no_pin_warn")), Toast.LENGTH_LONG).show();
            } else stopService(new Intent(this, LockService.class));
            refresh();
        });

        // desbloqueio
        LinearLayout uc = Ui.card(this, col, L.t("m_unlock"));
        methodVal = Ui.item(this, uc, L.t("unlockmode"), "", v -> new AlertDialog.Builder(this).setTitle(L.t("unlockmode")).setItems(Look.unlockN(), (d, w) -> {
            if (w == 1 && !Prefs.hasPattern(this)) { patternDialog(); return; }
            Look.setI(this, "unlockMode", w);
            refresh();
        }).show());
        Ui.actions(this, uc, new String[]{L.t("set_pin"), L.t("remove_pin")}, new View.OnClickListener[]{v -> pinDialog(), v -> removePin()});
        Ui.actions(this, uc, new String[]{L.t("set_pattern"), L.t("remove_pattern")}, new View.OnClickListener[]{v -> patternDialog(), v -> removePattern()});
        final android.widget.CompoundButton[] bp = new android.widget.CompoundButton[1];
        bp[0] = Ui.toggle(this, uc, L.t("block_power"), null, Look.b(this, "blockPower", false), (v, on) -> {
            if (!on) { Look.setB(this, "blockPower", false); return; }
            if (Look.b(this, "blockPower", false)) return;
            bp[0].setChecked(false); // só liga depois do PIN
            if (!Prefs.hasPin(this)) { Toast.makeText(this, L.t("pin_set_first"), Toast.LENGTH_LONG).show(); return; }
            final EditText e = field(L.t("pin_current"));
            LinearLayout box = new LinearLayout(this);
            box.setPadding(dp(20), dp(8), dp(20), 0);
            box.addView(e);
            new AlertDialog.Builder(this).setTitle(L.t("block_power")).setView(box).setNegativeButton(L.t("cancel"), null)
                    .setPositiveButton(L.t("ok"), (d, w) -> {
                        if (Prefs.check(this, e.getText().toString())) { Look.setB(this, "blockPower", true); bp[0].setChecked(true); }
                        else Toast.makeText(this, L.t("pin_wrong"), Toast.LENGTH_SHORT).show();
                    }).show();
        });

        // segurança
        LinearLayout sec = Ui.card(this, col, L.t("sec_title"));
        secVal = Ui.item(this, sec, L.t("sec_attempts"), "", v -> startActivity(new Intent(this, SecurityActivity.class)));
        Ui.item(this, sec, L.t("auto_off"), null, v -> startActivity(new Intent(this, SecurityActivity.class)));

        // atalhos
        LinearLayout sc = Ui.card(this, col, L.t("m_shortcuts"));
        for (int i = 0; i < SC_SHORT.length; i++) {
            final int slot = i;
            scVal[i] = Ui.item(this, sc, L.t(SC_SHORT[i]), "", v -> pickApp(slot), L.t("photo_btn"), v -> photoMenu(slot));
        }

        // aparência
        LinearLayout ac = Ui.card(this, col, L.t("h_bg"));
        Ui.item(this, ac, L.t("appearance"), L.t("appearance_sub"), v -> startActivity(new Intent(this, AppearanceActivity.class)));

        // sistema
        LinearLayout gc = Ui.card(this, col, L.t("m_general"));
        permVal = Ui.item(this, gc, L.t("m_perms"), "", v -> showPerms());
        Ui.item(this, gc, L.t("language"), L.LANG_N[Look.idxd(this, "lang", 3, 0)], v -> pickLang());
        Ui.item(this, gc, L.t("credits"), null, v -> new android.app.AlertDialog.Builder(this)
                .setTitle(L.t("credits")).setMessage(L.t("credits_text")).setPositiveButton(L.t("ok"), null).show());
        Ui.item(this, gc, L.t("howto_btn"), null, v -> new AlertDialog.Builder(this).setTitle(L.t("m_howto")).setMessage(L.t("hint")).setPositiveButton(L.t("ok"), null).show());
    }

    /** Título de seção no estilo Holo: texto azul em caixa alta com fio embaixo. */
    private void head(LinearLayout col, String t) {
        TextView v = new TextView(this);
        v.setText(t.toUpperCase());
        v.setTextColor(0xFF33B5E5);
        v.setTextSize(13);
        v.setPadding(dp(2), dp(20), 0, dp(4));
        col.addView(v);
        View line = new View(this);
        line.setBackgroundColor(0xFF33B5E5);
        col.addView(line, new LinearLayout.LayoutParams(-1, dp(2)));
    }

    private Button btn(LinearLayout col, String t, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(t);
        x.setOnClickListener(l);
        col.addView(x);
        return x;
    }

    /** Botão dentro de uma linha horizontal, com peso. */
    private Button add(LinearLayout row, String t, View.OnClickListener l, float w) {
        Button x = new Button(this);
        x.setText(t);
        x.setOnClickListener(l);
        row.addView(x, new LinearLayout.LayoutParams(0, -2, w));
        return x;
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private String label(String pkg) {
        if (pkg == null) return L.t("none").replace("(", "").replace(")", "");
        try { PackageManager pm = getPackageManager(); return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return pkg; }
    }

    private boolean usageOk() {
        AppOpsManager a = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }

    private void refresh() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        enableSw.setChecked(Prefs.enabled(this));
        status.setText(L.t("lock") + (Prefs.enabled(this) ? L.t("on") : L.t("off")) + "\n" + L.t("p_status") + (Prefs.hasPin(this) ? L.t("defined") : L.t("notdefined"))
                + "   \u00B7   " + L.t("p_pattern") + (Prefs.hasPattern(this) ? L.t("defined") : L.t("notdefined")));
        for (int i = 0; i < SC_SHORT.length; i++) scVal[i].setText(label(Prefs.shortcut(this, i)));
        for (int i = 0; i < SC_SHORT.length; i++) scVal[i].setVisibility(View.VISIBLE);
        boolean[] ok = permOk();
        int nOk = 0;
        for (boolean o : ok) if (o) nOk++;
        permVal.setText(String.format(L.t("perm_btn"), nOk, ok.length));
        permVal.setVisibility(View.VISIBLE);
        methodVal.setText(Look.unlockN()[Look.patternOn(this) ? 1 : 0]);
        methodVal.setVisibility(View.VISIBLE);
        secVal.setText(Attempts.summary(this));
        secVal.setVisibility(View.VISIBLE);
    }

    private boolean[] permOk() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        return new boolean[]{Settings.canDrawOverlays(this), usageOk(), dpm.isAdminActive(new ComponentName(this, AdminReceiver.class)),
                Build.VERSION.SDK_INT < 23 || Build.VERSION.SDK_INT >= 33 || checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED,
                notifOk(), accOk()};
    }

    private void showPerms() {
        boolean[] ok = permOk();
        String[] it = new String[PERM_KEYS.length];
        for (int i = 0; i < it.length; i++) it[i] = L.t(PERM_KEYS[i]) + (ok[i] ? "   \u2714" : "   \u2716");
        new AlertDialog.Builder(this).setTitle(L.t("m_perms")).setItems(it, (d, w) -> permAction(w)).setNegativeButton(L.t("cancel"), null).show();
    }

    private void permAction(int i) {
        switch (i) {
            case 0: startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); break;
            case 1: startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); break;
            case 2: startActivity(new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(this, AdminReceiver.class))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, L.t("admin_expl"))); break;
            case 3: if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 2); break;
            case 4: startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); break;
            case 5: startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); break;
        }
    }

    private boolean accOk() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(getPackageName());
    }

    private boolean notifOk() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private void pinDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText a = field(L.t("new_pin")), c = field(L.t("repeat_pin"));
        l.addView(a);
        l.addView(c);
        new AlertDialog.Builder(this).setTitle("PIN").setView(l).setNegativeButton(L.t("cancel"), null)
                .setPositiveButton(L.t("save"), (d, w) -> {
                    String p = a.getText().toString();
                    if (p.length() < 4 || !p.equals(c.getText().toString())) {
                        Toast.makeText(this, L.t("pin_invalid"), Toast.LENGTH_LONG).show();
                        return;
                    }
                    Prefs.setPin(this, p);
                    refresh();
                }).show();
    }

    /** Define o padrão: desenha duas vezes (mínimo 4 pontos), na própria grade do 4.0.4. */
    private void patternDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(0xFF1A1A1A);
        l.setPadding(dp(16), dp(16), dp(16), dp(8));
        final TextView m = new TextView(this);
        m.setTextColor(Color.WHITE);
        m.setTextSize(16);
        m.setGravity(android.view.Gravity.CENTER);
        m.setText(L.t("pat_new"));
        l.addView(m, new LinearLayout.LayoutParams(-1, -2));
        final PatternView pv = new PatternView(this);
        int s = Math.min(dp(300), getResources().getDisplayMetrics().widthPixels - dp(72));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(s, s);
        pl.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        pl.topMargin = dp(12);
        l.addView(pv, pl);
        final String[] first = new String[1];
        final AlertDialog dlg = new AlertDialog.Builder(this).setView(l).setNegativeButton(L.t("cancel"), null).create();
        pv.setListener(seq -> {
            if (seq.length() < 4) { m.setText(L.t("pat_short")); pv.showWrong(); return; }
            if (first[0] == null) { first[0] = seq; m.setText(L.t("pat_confirm")); pv.clearAfter(600); return; }
            if (first[0].equals(seq)) {
                Prefs.setPattern(this, seq);
                Look.setI(this, "unlockMode", 1);
                dlg.dismiss();
                Toast.makeText(this, L.t("pat_saved"), Toast.LENGTH_SHORT).show();
                refresh();
            } else { first[0] = null; m.setText(L.t("pat_mismatch")); pv.showWrong(); }
        });
        dlg.show();
    }

    private void removePattern() {
        new AlertDialog.Builder(this).setMessage(L.t("remove_pattern_q")).setNegativeButton(L.t("no"), null)
                .setPositiveButton(L.t("yes"), (d, w) -> {
                    Prefs.clearPattern(this);
                    Look.setI(this, "unlockMode", 0);
                    Toast.makeText(this, L.t("pat_removed"), Toast.LENGTH_SHORT).show();
                    refresh();
                }).show();
    }

    private void removePin() {
        new AlertDialog.Builder(this).setMessage(L.t("remove_pin_q")).setNegativeButton(L.t("no"), null)
                .setPositiveButton(L.t("yes"), (d, w) -> {
                    Prefs.clearPin(this);
                    Toast.makeText(this, L.t("pin_removed"), Toast.LENGTH_SHORT).show();
                    refresh();
                }).show();
    }

    private void pickLang() {
        new AlertDialog.Builder(this).setTitle(L.t("language"))
                .setSingleChoiceItems(L.LANG_N, Look.idxd(this, "lang", 3, 0), (d, w) -> { Look.setI(this, "lang", w); d.dismiss(); recreate(); }).show();
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        return e;
    }

    /** Escolha do atalho: atalhos prontos do Holo Locker original ou qualquer app. */
    private void pickApp(final int slot) {
        final String[] pre = Presets.names();
        String[] names = new String[pre.length + 2];
        names[0] = L.t("none");
        for (int i = 0; i < pre.length; i++) names[i + 1] = pre[i];
        names[pre.length + 1] = L.t("choose_app") + "...";
        new AlertDialog.Builder(this).setTitle(L.t("shortcut_presets")).setItems(names, (d, w) -> {
            if (w == 0) { Prefs.setShortcut(this, slot, null); refresh(); }
            else if (w == pre.length + 1) pickAnyApp(slot);
            else {
                String pkg = Presets.resolve(this, w - 1);
                if (pkg == null) Toast.makeText(this, names[w] + ": -", Toast.LENGTH_SHORT).show();
                else { Prefs.setShortcut(this, slot, pkg); refresh(); }
            }
        }).show();
    }

    private void pickAnyApp(final int slot) {
        PackageManager pm = getPackageManager();
        final List<ResolveInfo> l = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
        Collections.sort(l, new ResolveInfo.DisplayNameComparator(pm));
        String[] names = new String[l.size()];
        for (int i = 0; i < l.size(); i++) names[i] = l.get(i).loadLabel(pm).toString();
        new AlertDialog.Builder(this).setTitle(L.t("choose_app")).setItems(names, (d, w) -> {
            Prefs.setShortcut(this, slot, l.get(w).activityInfo.packageName);
            refresh();
        }).show();
    }

    /** Foto personalizada para o atalho (aparece no lugar do ícone do app). */
    private void photoMenu(final int slot) {
        new AlertDialog.Builder(this).setTitle(L.t("shortcut_photo"))
                .setItems(new String[]{L.t("change_photo_short"), L.t("photo_remove")}, (d, w) -> {
                    if (w == 0) startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 10 + slot);
                    else { Prefs.scPhoto(this, slot).delete(); refresh(); }
                }).show();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req >= 10 && req <= 13 && res == RESULT_OK && data != null && data.getData() != null) {
            try { savePhoto(data.getData(), req - 10); }
            catch (Exception e) { Toast.makeText(this, L.t("photo_fail"), Toast.LENGTH_LONG).show(); }
            refresh();
        }
    }

    private void savePhoto(Uri u, int slot) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= 600) s *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = s;
        Bitmap bmp;
        try (InputStream in = getContentResolver().openInputStream(u)) { bmp = BitmapFactory.decodeStream(in, null, o); }
        try (FileOutputStream f = new FileOutputStream(Prefs.scPhoto(this, slot))) { bmp.compress(Bitmap.CompressFormat.PNG, 100, f); }
    }
}
