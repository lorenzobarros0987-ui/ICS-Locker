package com.meu.pinlocker;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AppOpsManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.text.InputType;
import android.text.InputFilter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private TextView status;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(16), dp(16), dp(16));
        sv.addView(col);

        TextView hint = new TextView(this);
        hint.setText("PIN Locker\n\nAntes de ativar: em Configurações > Tela de bloqueio, deixe \"Nenhum\" ou \"Deslizar\" (o bloqueio do sistema não pode ficar com PIN junto). "
                + "Se der problema, reinicie em modo de segurança e desinstale o app.");
        col.addView(hint);
        status = new TextView(this);
        status.setPadding(0, dp(12), 0, dp(12));
        col.addView(status);

        btn(col, "Definir / trocar PIN", v -> pinDialog());
        btn(col, "Atalho da esquerda", v -> pickApp(0));
        btn(col, "Atalho da direita", v -> pickApp(1));
        btn(col, "Aparência (fundo, cores, relógio, teclado)", v -> startActivity(new Intent(this, AppearanceActivity.class)));
        btn(col, "1. Permitir sobrepor outros apps", v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        btn(col, "2. Permitir acesso ao uso", v -> startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
        btn(col, "3. Administrador do dispositivo", v -> startActivity(new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(this, AdminReceiver.class))
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Dificulta desinstalar o PIN Locker sem o PIN.")));
        btn(col, "ATIVAR bloqueio", v -> {
            if (!Prefs.hasPin(this)) { Toast.makeText(this, "Defina um PIN primeiro", Toast.LENGTH_SHORT).show(); return; }
            Prefs.setEnabled(this, true);
            Prefs.setLocked(this, false);
            Intent s = new Intent(this, LockService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
            Toast.makeText(this, "Ativo. Apague a tela para testar.", Toast.LENGTH_SHORT).show();
        });
        btn(col, "DESATIVAR bloqueio", v -> {
            Prefs.setEnabled(this, false);
            Prefs.setLocked(this, false);
            stopService(new Intent(this, LockService.class));
        });
        setContentView(sv);
    }

    private void btn(LinearLayout col, String t, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(t);
        x.setOnClickListener(l);
        col.addView(x);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private String label(String pkg) {
        if (pkg == null) return "nenhum";
        try { PackageManager pm = getPackageManager(); return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return pkg; }
    }

    private boolean usageOk() {
        AppOpsManager a = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName()) == AppOpsManager.MODE_ALLOWED;
    }

    private void refresh() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        status.setText("PIN: " + (Prefs.hasPin(this) ? "definido" : "NÃO definido")
                + "\nSobrepor apps: " + (Settings.canDrawOverlays(this) ? "ok" : "falta")
                + "\nAcesso ao uso: " + (usageOk() ? "ok" : "falta")
                + "\nAdministrador: " + (dpm.isAdminActive(new ComponentName(this, AdminReceiver.class)) ? "ativo" : "inativo")
                + "\nAtalho esquerda: " + label(Prefs.shortcut(this, 0))
                + "\nAtalho direita: " + label(Prefs.shortcut(this, 1))
                + "\nFonte do relógio: " + Fonts.NAMES[Fonts.index(this)]
                + "\nBloqueio: " + (Prefs.enabled(this) ? "ATIVADO" : "desativado"));
    }

    private void pinDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText a = field("Novo PIN (4 a 8 números)"), c = field("Repita o PIN");
        l.addView(a);
        l.addView(c);
        new AlertDialog.Builder(this).setTitle("PIN").setView(l).setNegativeButton("Cancelar", null)
                .setPositiveButton("Salvar", (d, w) -> {
                    String p = a.getText().toString();
                    if (p.length() < 4 || !p.equals(c.getText().toString())) {
                        Toast.makeText(this, "PIN inválido ou diferente", Toast.LENGTH_LONG).show();
                        return;
                    }
                    Prefs.setPin(this, p);
                    refresh();
                }).show();
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        return e;
    }

    private void pickFont() {
        String[] items = new String[Fonts.NAMES.length];
        for (int i = 0; i < items.length; i++) items[i] = "12:34  " + Fonts.NAMES[i];
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice, items) {
            @Override public View getView(int p, View cv, ViewGroup parent) {
                TextView v = (TextView) super.getView(p, cv, parent);
                v.setTypeface(Fonts.at(MainActivity.this, p));
                v.setTextSize(20);
                return v;
            }
        };
        new AlertDialog.Builder(this).setTitle("Fonte do relógio")
                .setSingleChoiceItems(ad, Fonts.index(this), (d, w) -> { Fonts.set(this, w); d.dismiss(); refresh(); }).show();
    }

    private void pickApp(final int slot) {
        PackageManager pm = getPackageManager();
        final List<ResolveInfo> l = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0);
        Collections.sort(l, new ResolveInfo.DisplayNameComparator(pm));
        String[] names = new String[l.size() + 1];
        names[0] = "(nenhum)";
        for (int i = 0; i < l.size(); i++) names[i + 1] = l.get(i).loadLabel(pm).toString();
        new AlertDialog.Builder(this).setTitle("Escolha o app").setItems(names, (d, w) -> {
            Prefs.setShortcut(this, slot, w == 0 ? null : l.get(w - 1).activityInfo.packageName);
            refresh();
        }).show();
    }
}
