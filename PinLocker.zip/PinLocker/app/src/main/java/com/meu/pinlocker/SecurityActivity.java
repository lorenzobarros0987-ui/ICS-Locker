package com.meu.pinlocker;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.util.function.IntConsumer;

/** Segurança: bloqueio por tentativas erradas (3 níveis) e desligar a tela sozinha. */
public class SecurityActivity extends Activity {
    private LinearLayout col;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        L.init(this);
        setTitle(L.t("sec_title"));
        col = Ui.page(this);
        build();
    }

    private void build() {
        col.removeAllViews();
        LinearLayout c = Ui.card(this, col, L.t("sec_attempts"));
        Ui.toggle(this, c, L.t("at_on"), L.t("at_on_sub"), Attempts.on(this), (v, on) -> {
            Attempts.setOn(this, on);
            col.post(this::build);
        });
        if (Attempts.on(this)) {
            for (int i = 0; i < 3; i++) {
                final int lvl = i;
                LinearLayout lc = Ui.card(this, col, String.format(L.t("at_level"), i + 1));
                Ui.item(this, lc, L.t("at_after"), String.format(L.t("at_n"), Attempts.n(this, i)), v -> {
                    String[] names = new String[Attempts.COUNTS.length];
                    int cur = 0;
                    for (int k = 0; k < names.length; k++) { names[k] = String.format(L.t("at_n"), Attempts.COUNTS[k]); if (Attempts.COUNTS[k] == Attempts.n(this, lvl)) cur = k; }
                    pick(L.t("at_after"), names, cur, w -> Attempts.setN(this, lvl, Attempts.COUNTS[w]));
                });
                Ui.item(this, lc, L.t("at_for"), Attempts.secs(Attempts.t(this, i)), v -> {
                    String[] names = new String[Attempts.SECS.length];
                    int cur = 0;
                    for (int k = 0; k < names.length; k++) { names[k] = Attempts.secs(Attempts.SECS[k]); if (Attempts.SECS[k] == Attempts.t(this, lvl)) cur = k; }
                    pick(L.t("at_for"), names, cur, w -> Attempts.setT(this, lvl, Attempts.SECS[w]));
                });
            }
            LinearLayout nc = Ui.card(this, col, null);
            Ui.item(this, nc, L.t("at_note"), null, null);
            Ui.action(this, nc, L.t("at_defaults"), v -> { Attempts.defaults(this); build(); });
        }

        LinearLayout sc = Ui.card(this, col, L.t("sec_screen"));
        int cur = Look.idxd(this, "autoOff", Attempts.AUTO_OFF.length, 0);
        String[] names = new String[Attempts.AUTO_OFF.length];
        for (int k = 0; k < names.length; k++) names[k] = Attempts.AUTO_OFF[k] == 0 ? L.t("at_off") : Attempts.secs(Attempts.AUTO_OFF[k]);
        Ui.item(this, sc, L.t("auto_off"), names[cur], v -> pick(L.t("auto_off"), names, cur, w -> {
            Look.setI(this, "autoOff", w);
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            if (w > 0 && !dpm.isAdminActive(new ComponentName(this, AdminReceiver.class))) Toast.makeText(this, L.t("auto_off_admin"), Toast.LENGTH_LONG).show();
        }));
        Ui.item(this, sc, L.t("auto_off_note"), null, null);
    }

    private void pick(String title, String[] names, int cur, IntConsumer on) {
        new AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(names, cur, (d, w) -> { d.dismiss(); on.accept(w); build(); }).show();
    }
}
