package com.meu.pinlocker;

import android.content.Context;
import android.graphics.Typeface;

final class Fonts {
    static final String[] NAMES = {"Original do Holo Locker", "Fina", "Leve", "Normal", "Condensada", "Serifada", "Monoespaçada", "Casual", "Cursiva"};
    private static final String[] SYS = {null, "sans-serif-thin", "sans-serif-light", "sans-serif", "sans-serif-condensed", "serif", "monospace", "casual", "cursive"};

    static int index(Context c) {
        int i = c.getSharedPreferences("pl", Context.MODE_PRIVATE).getInt("font", 0);
        return i < 0 || i >= NAMES.length ? 0 : i;
    }

    static void set(Context c, int i) { c.getSharedPreferences("pl", Context.MODE_PRIVATE).edit().putInt("font", i).apply(); }

    /** Fonte da hora. O índice 0 é a AndroidClock.ttf tirada do APK original. */
    static Typeface at(Context c, int i) {
        if (i <= 0) {
            try { return Typeface.createFromAsset(c.getAssets(), "AndroidClock.ttf"); }
            catch (Exception e) { return Typeface.create("sans-serif-light", Typeface.NORMAL); }
        }
        return Typeface.create(SYS[i], Typeface.NORMAL);
    }

    static Typeface time(Context c) { return at(c, index(c)); }

    /** Data usa a mesma fonte, mas no "Original" (só tem números) cai para a leve do sistema. */
    static Typeface date(Context c) {
        int i = index(c);
        return i <= 0 ? Typeface.create("sans-serif-light", Typeface.NORMAL) : at(c, i);
    }
}
