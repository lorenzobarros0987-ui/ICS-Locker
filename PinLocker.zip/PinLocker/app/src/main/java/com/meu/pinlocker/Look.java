package com.meu.pinlocker;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.File;

/** Opções de aparência (guardadas junto com as outras preferências). */
final class Look {
    static final String[] ACCENT_N = {"Azul Holo", "Verde Holo", "Roxo Holo", "Laranja Holo", "Vermelho Holo"};
    static final int[] ACCENT = {0xFF33B5E5, 0xFF99CC00, 0xFFAA66CC, 0xFFFFBB33, 0xFFFF4444};
    static final String[] BG_N = {"Holo azul", "Preto", "Cinza escuro", "Azul noite", "Roxo escuro", "Verde escuro", "Vinho", "Foto da galeria"};
    static final int[][] BG = {{0xFF001A26, 0xFF000000}, {0xFF000000, 0xFF000000}, {0xFF333333, 0xFF111111}, {0xFF0B1B3A, 0xFF02040A},
            {0xFF2A0F3A, 0xFF0A0310}, {0xFF0F2A14, 0xFF020A04}, {0xFF3A0F18, 0xFF0A0305}, {0xFF001A26, 0xFF000000}};
    static final String[] CCOL_N = {"Branco", "Cor de destaque", "Cinza claro", "Amarelo"};
    static final String[] CPOS_N = {"Topo", "Mais embaixo"};
    static final String[] HMODE_N = {"Seguir o sistema", "Sempre 24h", "Sempre 12h"};
    static final String[] DFMT_N = {"sábado, 14 de novembro", "14/11/2026", "sáb, 14 nov", "14 de novembro de 2026"};
    static final String[] DFMT = {"EEEE, d 'de' MMMM", "dd/MM/yyyy", "EEE, d MMM", "d 'de' MMMM 'de' yyyy"};
    private static final String[] KEYS = {"accent", "bg", "dim", "csize", "ccol", "cpos", "hmode", "showDate", "dfmt", "ringTint",
            "pinLetters", "pinShuffle", "pinHaptic", "pinShow", "font"};

    private static SharedPreferences p(Context c) { return c.getSharedPreferences("pl", Context.MODE_PRIVATE); }
    static int i(Context c, String k, int d) { return p(c).getInt(k, d); }
    static void setI(Context c, String k, int v) { p(c).edit().putInt(k, v).apply(); }
    static boolean b(Context c, String k, boolean d) { return p(c).getBoolean(k, d); }
    static void setB(Context c, String k, boolean v) { p(c).edit().putBoolean(k, v).apply(); }
    static int idx(Context c, String k, int len) { int v = i(c, k, 0); return v < 0 || v >= len ? 0 : v; }
    static int accent(Context c) { return ACCENT[idx(c, "accent", ACCENT.length)]; }

    static File photoFile(Context c) { return new File(c.getFilesDir(), "bg.jpg"); }
    static Bitmap photo(Context c) { File f = photoFile(c); return f.exists() ? BitmapFactory.decodeFile(f.getPath()) : null; }

    static void reset(Context c) {
        SharedPreferences.Editor e = p(c).edit();
        for (String k : KEYS) e.remove(k);
        e.apply();
        photoFile(c).delete();
    }
}
