package com.meu.pinlocker;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.File;

/** Opções de aparência (guardadas junto com as outras preferências). */
final class Look {
    static final int ACCENT_COUNT = 5;
    static final int[] ACCENT = {0xFF33B5E5, 0xFF99CC00, 0xFFAA66CC, 0xFFFFBB33, 0xFFFF4444};
    // índices estáveis: 0-6 cores, 7 foto, 8 fundo do celular (padrão), 9 papel de parede da tela de bloqueio, 10 papel de parede ao vivo (tela inicial)
    static final int BG_PHOTO = 7, BG_WALL = 8, BG_LOCKWP = 9, BG_LIVE = 10;
    static final int[][] BG = {{0xFF001A26, 0xFF000000}, {0xFF000000, 0xFF000000}, {0xFF333333, 0xFF111111}, {0xFF0B1B3A, 0xFF02040A},
            {0xFF2A0F3A, 0xFF0A0310}, {0xFF0F2A14, 0xFF020A04}, {0xFF3A0F18, 0xFF0A0305}, {0xFF001A26, 0xFF000000}, {0xFF001A26, 0xFF000000}, {0xFF001A26, 0xFF000000}, {0xFF001A26, 0xFF000000}};
    static final String[] DFMT = {"EEEE, d 'de' MMMM", "dd/MM/yyyy", "EEE, d MMM", "d 'de' MMMM 'de' yyyy"};
    static final String[] DFMT_EN = {"EEEE, MMMM d", "MM/dd/yyyy", "EEE, MMM d", "MMMM d, yyyy"};
    private static final String[] KEYS = {"accent", "bg", "dim", "csize", "ccol", "cpos", "hmode", "showDate", "dfmt", "ringTint",
            "pinLetters", "pinShuffle", "pinHaptic", "pinShow", "font", "pinStyle", "scShape", "scNeedUnlock", "visual", "btm", "label", "calign", "holoBar", "pinCircles", "wpTouch", "skin", "lockMode", "muteBg", "unlockMode"};

    /** Papel de parede ao vivo: escolhido explicitamente, ou o fundo do celular quando ele já é animado. */
    static boolean isLive(Context c) {
        int bg = idxd(c, "bg", BG.length, BG_WALL);
        if (bg == BG_LIVE) return true;
        if (bg != BG_WALL) return false;
        try { return android.app.WallpaperManager.getInstance(c.getApplicationContext()).getWallpaperInfo() != null; }
        catch (Throwable t) { return false; }
    }

    private static String[] pe(String pt, String en) { return (L.isEn() ? en : pt).split("\\|"); }
    static String[] accentN() { return pe("Azul Holo|Verde Holo|Roxo Holo|Laranja Holo|Vermelho Holo", "Holo blue|Holo green|Holo purple|Holo orange|Holo red"); }
    static String[] bgN() { return pe("Holo azul|Preto|Cinza escuro|Azul noite|Roxo escuro|Verde escuro|Vinho|Foto da galeria|Fundo do celular (padrão)|Papel de parede da tela de bloqueio|Papel de parede animado (tela inicial / ao vivo)",
            "Holo blue|Black|Dark gray|Night blue|Dark purple|Dark green|Wine|Gallery photo|Phone wallpaper (default)|Lock screen wallpaper|Live wallpaper (home screen / animated)"); }
    static String[] ccolN() { return pe("Branco|Cor de destaque|Cinza claro|Amarelo", "White|Accent color|Light gray|Yellow"); }
    static String[] cposN() { return pe("Topo|Médio|Mais embaixo", "Top|Middle|Lower"); }
    static String[] hmodeN() { return pe("Seguir o sistema|Sempre 24h|Sempre 12h", "Follow system|Always 24h|Always 12h"); }
    static String[] dfmtN() { return pe("sábado, 14 de novembro|14/11/2026|sáb, 14 nov|14 de novembro de 2026", "Saturday, November 14|11/14/2026|Sat, Nov 14|November 14, 2026"); }
    static String[] calignN() { return pe("Direita|Centro|Esquerda", "Right|Center|Left"); }
    static String[] btmN() { return pe("Nome da operadora|Etiqueta personalizada|Nenhum", "Carrier name|Custom label|None"); }
    static String[] visualN() { return pe("Original (Holo Locker)|Estendido (efeitos extras)", "Original (Holo Locker)|Extended (extra effects)"); }
    static String[] scShapeN() { return pe("Redonda|Quadrado arredondado|Original (sem recorte)", "Round|Rounded square|Original (no crop)"); }
    static String[] pinStyleN() { return pe("Teclado Holo na tela|Página inteira com o teclado do celular", "Holo keypad on screen|Full page with the phone keyboard"); }
    static String[] skinN() { return pe("Holo Locker (igual ao original)|Android 4.0 (recursos do sistema)", "Holo Locker (same as the original)|Android 4.0 (system resources)"); }
    static String[] lockModeN() { return pe("Normal: bloqueia ao apagar a tela, desbloqueia com PIN|Só deslizar: bloqueia ao apagar a tela, desbloqueia só deslizando (sem PIN)|PIN direto: ao ligar a tela já mostra o teclado do PIN, antes de deslizar",
            "Normal: locks when the screen turns off, unlock with PIN|Swipe only: locks when the screen turns off, unlock by swiping (no PIN)|PIN first: when the screen turns on it shows the PIN pad right away, before swiping"); }
    static String[] unlockN() { return pe("PIN|Padrão (Android 4.0.4)", "PIN|Pattern (Android 4.0.4)"); }
    /** Desbloqueio por padrão: escolhido e já definido. */
    static boolean patternOn(Context c) { return idxd(c, "unlockMode", 2, 0) == 1 && Prefs.hasPattern(c); }
    /** Tem PIN ou padrão para pedir ao desbloquear. */
    static boolean hasAuth(Context c) { return patternOn(c) || Prefs.hasPin(c); }
    /** 0 = Holo Locker (padrão), 1 = Android 4.0. */
    static boolean ics(Context c) { return idxd(c, "skin", 2, 0) == 1; }
    /** 0 = normal, 1 = só deslizar (sem PIN), 2 = PIN direto ao ligar a tela. */
    static int lockMode(Context c) { return idxd(c, "lockMode", 3, 0); }
    static boolean muteBg(Context c) { return b(c, "muteBg", true); }
    static String dfmt(Context c) { int k = idxd(c, "dfmt", DFMT.length, 0); return L.isEn() ? DFMT_EN[k] : DFMT[k]; }

    private static SharedPreferences p(Context c) { return c.getSharedPreferences("pl", Context.MODE_PRIVATE); }
    static int i(Context c, String k, int d) { return p(c).getInt(k, d); }
    static void setI(Context c, String k, int v) { p(c).edit().putInt(k, v).apply(); }
    static boolean b(Context c, String k, boolean d) { return p(c).getBoolean(k, d); }
    static String s(Context c, String k, String d) { return p(c).getString(k, d); }
    static void setS(Context c, String k, String v) { p(c).edit().putString(k, v).apply(); }
    static void setB(Context c, String k, boolean v) { p(c).edit().putBoolean(k, v).apply(); }
    /** Lê um índice guardado, com valor padrão d; se estiver fora da lista volta para d. */
    static int idxd(Context c, String k, int len, int d) { int v = i(c, k, d); return v < 0 || v >= len ? d : v; }
    static int accent(Context c) { return ACCENT[idxd(c, "accent", ACCENT.length, 0)]; }

    static File photoFile(Context c) { return new File(c.getFilesDir(), "bg.jpg"); }
    private static Bitmap photoCache;
    private static long photoStamp = -1;

    /** Foto de fundo: decodificada uma vez, já reduzida ao tamanho da tela, e reaproveitada (não decodifica a cada bloqueio). */
    static synchronized Bitmap photo(Context c) {
        File f = photoFile(c);
        if (!f.exists()) { photoCache = null; photoStamp = -1; return null; }
        long st = f.lastModified() ^ f.length();
        if (photoCache != null && st == photoStamp) return photoCache;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getPath(), o);
        android.util.DisplayMetrics m = c.getResources().getDisplayMetrics();
        int ss = 1;
        while (o.outWidth / (ss * 2) >= m.widthPixels && o.outHeight / (ss * 2) >= m.heightPixels) ss *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = ss;
        photoCache = BitmapFactory.decodeFile(f.getPath(), o);
        photoStamp = st;
        return photoCache;
    }

    static void reset(Context c) {
        SharedPreferences.Editor e = p(c).edit();
        for (String k : KEYS) e.remove(k);
        e.apply();
        photoFile(c).delete();
    }
}
