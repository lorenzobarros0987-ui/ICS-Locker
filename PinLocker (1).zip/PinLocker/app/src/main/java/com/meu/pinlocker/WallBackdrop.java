package com.meu.pinlocker;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

/**
 * Pano de fundo da tela de bloqueio com papel de parede animado. Janelas de sobreposição NÃO recebem o papel de parede
 * do sistema (por isso aparecia o app que estava aberto); uma Activity com o tema de papel de parede recebe. Ela fica
 * por baixo da tela de bloqueio (que é transparente quando esta camada está pronta).
 */
public class WallBackdrop extends Activity {
    private static WallBackdrop inst;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        inst = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams wa = getWindow().getAttributes();
            wa.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(wa);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (!Prefs.enabled(this) || !Prefs.locked(this)) { finish(); return; }
        // dá um instante para o papel de parede desenhar e só então a tela de bloqueio fica transparente
        getWindow().getDecorView().postDelayed(() -> { if (inst == this && !isFinishing()) LockService.backdrop(true); }, 200);
    }

    @Override protected void onDestroy() {
        if (inst == this) { inst = null; LockService.backdrop(false); }
        super.onDestroy();
    }

    @Override public void onBackPressed() { }

    /** Tira o pano de fundo (desbloqueou ou serviço parou). */
    static void close() {
        LockService.backdropUp = false;
        WallBackdrop a = inst;
        inst = null;
        if (a != null) { a.finish(); a.overridePendingTransition(0, 0); }
    }
}
